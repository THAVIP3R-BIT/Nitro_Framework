# Migrating from QBCore to Nitro_Framework

This guide takes an existing QBCore server and moves it onto Nitro_Framework.
It covers the database, the `server.cfg`, the permissions and the code of the
resources that build on top of the framework.

> Nitro_Framework is an **original framework**, not a reskin of QBCore. The
> catalogue data (items, weapons, vehicles, jobs, organisations and locations)
> is redistributed under the terms of the GNU GPL v3, everything else is
> original work. See [LICENSES.md](../LICENSES.md) for the full inventory.

---

## 1. Requirements

| Requirement | Version |
| --- | --- |
| FiveM server | A current `server build` with `lua54` support |
| Database | MySQL 8.0.4 or newer (the legacy inventory import needs `JSON_TABLE`) |
| Database driver | [oxmysql](https://github.com/overextended/oxmysql) |
| Node.js | 18 or newer, only for the tooling in `tools/` (optional) |

Nitro_Framework uses `oxmysql` exclusively. It does not support `mysql-async`
and it does not use `oxmysql`'s legacy `MySQL.*` helpers either, it talks to
the driver through a small wrapper of its own.

---

## 2. Back up first

```bash
mysqldump -u USERNAME -p --single-transaction --routines --triggers DATABASE > nitro_backup_$(date +%F).sql
```

Stop the server while the import runs. The importer only reads from the legacy
tables, but a running server keeps writing to them.

---

## 3. Install the resources

Copy the `resources/nitro_*` folders into the `resources` directory of your
server. The repository layout is:

```
Nitro_Framework/
├── migrations/          the canonical SQL migrations
├── resources/           the twelve Nitro resources
├── docs/                this documentation
├── tools/               the Node tooling (lint, tests, migration sync)
└── tests/               the unit tests
```

Only the `resources` folder has to be deployed. The rest is for development.

---

## 4. Configure the database

The connection string is never stored in the repository. Set it in the
`server.cfg`, the same way you set it for oxmysql:

```cfg
set mysql_connection_string "mysql://user:password@127.0.0.1:3306/nitro?charset=utf8mb4"
```

Everything else lives in `resources/nitro_database/config.lua`. The setting you
are most likely to change is `AutoMigrate`:

```lua
AutoMigrate = true,   -- run the migrations when the resource starts
```

---

## 5. Start order

The resources depend on each other and have to be started in this order:

```cfg
ensure oxmysql

ensure nitro_shared
ensure nitro_database
ensure nitro_core
ensure nitro_players
ensure nitro_characters
ensure nitro_inventory
ensure nitro_banking
ensure nitro_jobs
ensure nitro_vehicles
ensure nitro_housing
ensure nitro_admin
ensure nitro_ui
```

The migrations run when `nitro_database` starts. The console prints one line
per migration, and the framework only lets players connect once the migrations
are done.

---

## 6. Import the legacy data

The importer is **not** applied automatically. Apply the Nitro schema first
(start the server once), then run
`migrations/legacy/100_qbcore_import.sql` by hand.

The detailed guide, including the identifier mapping, the MariaDB workaround
and the rollback, is in
[the legacy import readme](../migrations/legacy/README.md).

---

## 7. Permissions

Nitro_Framework uses ace permissions. The permission `admin` is the ace object
`nitro.admin`:

```cfg
add_ace group.admin nitro.admin allow
add_ace group.superadmin nitro.superadmin allow
```

Assign the groups to the identifiers of your staff members:

```cfg
add_principal identifier.license:xxxxxxxxxxxx nitro.admin
```

The full list is in the [API reference](api-reference.md#permissions).

---

## 8. Replace the old resources

Remove the QBCore resources from the `server.cfg` and delete their folders
after the import worked:

| QBCore | Nitro |
| --- | --- |
| `qb-core` | `nitro_core`, `nitro_players`, `nitro_characters` |
| `qb-inventory` | `nitro_inventory` |
| `qb-banking` | `nitro_banking` |
| `qb-jobs` | `nitro_jobs` |
| `qb-vehicles` | `nitro_vehicles` |
| `qb-housing` | `nitro_housing` |
| `qb-admin` | `nitro_admin` |

A resource that was written for QBCore will not work on Nitro without
changes, the API is different. The table below maps the calls that most
resources use.

---

## 9. API mapping

| QBCore | Nitro |
| --- | --- |
| `QBCore.Functions.GetPlayer(src)` | `exports['nitro_players']:GetPlayerData(src)` |
| `QBCore.Functions.SetPlayerData(src, key, value)` | `exports['nitro_core']:SetPlayerData(src, { [key] = value })` |
| `QBCore.Functions.GetPlayerData(src)` | `exports['nitro_core']:GetPlayerData(src)` |
| `QBCore.Functions.GetMoney(src, kind)` | `exports['nitro_banking']:GetCash(characterId)` / `GetBalance(characterId)` |
| `QBCore.Functions.AddMoney(src, kind, amount, reason)` | `exports['nitro_banking']:AddCash(characterId, amount, reason)` / `AddBank(...)` |
| `QBCore.Functions.RemoveMoney(src, kind, amount, reason)` | `exports['nitro_banking']:RemoveCash(...)` / `RemoveBank(...)` |
| `QBCore.Functions.GetItem(src, item)` | `exports['nitro_inventory']:GetItemCount('character', characterId, item)` |
| `QBCore.Functions.AddItem(src, item, amount, slot, info)` | `exports['nitro_inventory']:AddItem('character', characterId, item, amount, info)` |
| `QBCore.Functions.RemoveItem(src, item, amount, slot)` | `exports['nitro_inventory']:RemoveItem('character', characterId, item, amount)` |
| `QBCore.Functions.GetJob(src)` | `exports['nitro_jobs']:GetJob(characterId)` |
| `QBCore.Functions.SetJob(src, job, grade)` | `exports['nitro_jobs']:SetJob(src, job, grade)` |
| `QBCore.Functions.GetGang(src)` | `exports['nitro_jobs']:GetOrganisation(characterId)` |
| `QBCore.Functions.SetGang(src, gang, grade)` | `exports['nitro_jobs']:SetOrganisation(src, gang, grade)` |
| `QBCore.Functions.GetLicense(src, license)` | `exports['nitro_core']:GetPlayerIdentifiers(src).license` |
| `QBCore.Functions.HasPermission(src, permission)` | `exports['nitro_core']:HasPermission(src, permission)` |
| `QBCore.Functions.TriggerCallback(name, cb, ...)` | `exports['nitro_core']:TriggerCallback(name, cb, ...)` (client) |
| `TriggerClientEvent(name, src, ...)` | `TriggerClientEvent('nitro:client:...', src, ...)` |
| `RegisterNetEvent(name)` | `RegisterNetEvent('nitro:client:...')` |
| `QBCore.Shared.Items[name]` | `exports['nitro_shared']:GetItem(name)` |
| `QBCore.Shared.Vehicles[model]` | `exports['nitro_shared']:GetVehicle(model)` |
| `QBCore.Shared.Jobs[name]` | `exports['nitro_shared']:GetJob(name)` |

### Callbacks

A callback in QBCore is registered with `QBCore.Functions.CreateCallback` and
called with `QBCore.Functions.TriggerCallback`. In Nitro the server registers a
callback and the client triggers it:

```lua
-- server
exports['nitro_core']:RegisterCallback('myresource:doThing', function(src, id)
    return true, { id = id }
end)

-- client
exports['nitro_core']:TriggerCallback('myresource:doThing', function(ok, result)
    if not ok then return end
    print(result.id)
end, 1)
```

The handler of a server callback receives the server id of the caller as its
first argument, so a callback can never be triggered for somebody else by
accident.

---

## 10. Commands

| QBCore | Nitro |
| --- | --- |
| `/character` | `/characters` |
| `/duty` | `/duty` |
| `/car` | `/storevehicle`, `/deletevehicle` |
| `/admin` | `/admin` |
| `/ban`, `/unban` | `/ban`, `/unban` |
| `/tp` | `/tp` |
| `/setjob` | `/setjob` |
| `/givecash` | `/givecash` |
| `/givemoney` | `/givecash` (physical cash), `/givebank` (bank) |

---

## 11. Checklist

* [ ] The database is backed up.
* [ ] `set mysql_connection_string` points at the right database.
* [ ] `oxmysql` starts before `nitro_database`.
* [ ] The Nitro resources start in the documented order.
* [ ] The migrations ran without an error in the console.
* [ ] The legacy import was applied and verified.
* [ ] The ace permissions were granted to the staff members.
* [ ] The QBCore resources were removed from the `server.cfg`.
* [ ] The scripts of the server were ported to the Nitro API.
* [ ] A test player connected, created a character, received the starting money
      and could store a vehicle.

---

## 12. Troubleshooting

**"the database is not available"** — the connection string is wrong, the
database is not reachable or the server is not started yet. The framework
retries three times and then keeps the server closed.

**"a migration failed"** — the console prints the statement and the error of
the driver. The migration that failed is not recorded, so it runs again after
the problem is fixed. The migrations are idempotent.

**"the players are not in the character selection"** — the import was not
applied. Run `migrations/legacy/100_qbcore_import.sql` and check the result
with the queries of the legacy readme.

**"the inventory of the players is empty"** — the inventory block of the
import needs MySQL 8.0.4 or newer, on MariaDB use the alternative statement
of the legacy readme.

**"the money of the players is wrong"** — the cash of a character is stored in
`nitro_characters.cash` and the money on the bank in
`nitro_banking_accounts.balance`. A resource that writes to one of the two
columns directly breaks the ledger of the framework. Use
`exports['nitro_banking']` instead.
