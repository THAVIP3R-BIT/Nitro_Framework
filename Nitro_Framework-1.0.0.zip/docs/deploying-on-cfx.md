# Deploying Nitro_Framework on a Cfx.re server

This is the complete procedure to run Nitro_Framework on a real Cfx.re
(FiveM) server: a stock FXServer, a txAdmin deployment, or a game host panel
such as Pterodactyl.

The framework needs **no** client side script, no modified game files and no
external framework. It replaces QBCore/es_extended entirely.

---

## 1. What the server needs

| Requirement | Notes |
| --- | --- |
| FXServer artifact | A current recommended build, `lua54` support is mandatory. |
| MySQL | MySQL 8.0.4 or newer (recommended), or MariaDB 10.2 or newer. |
| [oxmysql](https://github.com/overextended/oxmysql) | The only supported database driver. Version 2.7 or newer. |
| OneSync | `onesync on`; the vehicle state bags use it. |
| `sv_licenseKey` | Required by Cfx.re for every public server. |

> The bundled migrations only need the JSON column type (MySQL 5.7 /
> MariaDB 10.2). The optional QBCore import in `migrations/legacy/` needs
> MySQL 8.0.4+ / MariaDB 10.6+ because it uses `JSON_TABLE`.

---

## 2. Create the database

The framework creates its own tables on the first start, so this is the only
SQL that is needed:

```sql
CREATE DATABASE nitro CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER 'nitro'@'127.0.0.1' IDENTIFIED BY 'a-strong-password';
GRANT ALL PRIVILEGES ON nitro.* TO 'nitro'@'127.0.0.1';
FLUSH PRIVILEGES;
```

`utf8mb4` is not optional: character names and descriptions may contain
emojis.

Do **not** expose port 3306 to the internet. If the database runs on another
machine, restrict the user to the server IP and use a firewall.

---

## 3. Install oxmysql

1. Download the latest release of
   [oxmysql](https://github.com/overextended/oxmysql/releases).
2. Put the `oxmysql` folder into the `resources` directory of the server.
3. Make sure `ensure oxmysql` appears **before** the nitro resources (section 5).

oxmysql reads the connection string from the convar, you never edit its files
for a standard installation.

---

## 4. Install Nitro_Framework

Build the archive that contains only the deployable files:

```bash
npm install
npm run package
```

That writes `dist/Nitro_Framework-<version>.zip`. It contains:

```
resources/nitro_shared/ ... resources/nitro_ui/   the twelve resources
migrations/                                      the canonical SQL
docs/deploying-on-cfx.md                         this guide
README.md, LICENSES.md, server.cfg.example
```

Extract the archive at the **root of the server** (the folder that contains
`server.cfg`), so the resources end up in `resources/nitro_*`.

Without Node.js, copy the twelve `resources/nitro_*` folders from the
repository into the server's `resources` directory by hand. Nothing else from
the repository is needed at runtime.

Rules:

* Do not rename the resources. The names are part of the export protocol.
* Do not move files between the resources. The manifests are exact.
* Keep the whole folder, including `nitro_database/sql/`. Those are the copies
  of the migrations that `nitro_database` applies at startup.

---

## 5. Configure `server.cfg`

The framework is a normal resource set: it uses no convars of its own. Use
[`server.cfg.example`](../server.cfg.example) as a starting point and copy
these blocks:

```cfg
# --- database ---------------------------------------------------------------
set mysql_connection_string "mysql://nitro:PASSWORD@127.0.0.1:3306/nitro?charset=utf8mb4"

# --- resources (the order matters) -----------------------------------------
ensure oxmysql

ensure nitro_shared
ensure nitro_database
ensure nitro_core
ensure nitro_players
ensure nitro_characters
ensure nitro_inventory
ensure nitro_banking
ensure nitro_jobs
ensure nitro_vehicles
ensure nitro_housing
ensure nitro_admin
ensure nitro_ui
```

The order is not cosmetic. Every resource calls the exports of the resources
above it:

* `nitro_shared` must be first: it provides the catalogue and the config.
* `nitro_database` needs oxmysql and must be ready before anything saves.
* `nitro_core` needs both and provides sessions and permissions.
* `nitro_players` and the domain resources come after the core.
* `nitro_ui` is last because it reacts to the events of the other resources.

A wrong order shows up on the first start as `No such export ... in
resource nitro_*`.

---

## 6. Staff permissions

Permissions are ACE permissions. A Nitro permission is a plain name and the
ace object is `nitro.<name>`, so the permission `admin` is granted with:

```cfg
add_ace group.admin nitro.admin allow
add_ace group.superadmin nitro.superadmin allow

# superadmins also need the admin permissions for /ban, /kick, ...
add_principal group.superadmin group.admin
```

Then put your staff into the groups. The identifier is the `license:` of the
player, which is printed in the server log when they connect:

```cfg
add_principal identifier.license:XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX group.admin
```

`moderator` is a staff marker (it opens the admin menu) but it does not
include the moderation commands. Grant `nitro.admin` as well if your
moderators may ban and kick.

Verify in game: a staff member can run `/nitro` and `/admin`, everybody else
gets "You do not have permission to use this command."

---

## 7. First start

Watch the server console. A healthy first start prints, in this order:

```
[nitro_database][INFO] database connection established
[nitro_database][INFO] applied migration 001_core.sql (core)
[nitro_database][INFO] applied migration 002_inventory.sql (inventory)
...
[nitro_database][INFO] migrations complete (6 applied, 0 already present)
[Nitro] Nitro_Framework 1.0.0 "Ignition" started.
```

Then check the framework with the console commands:

```
nitro                 # version, sessions, callbacks, uptime
nitro db              # database readiness, server version, query counters
nitro version
```

`nitro db` must report `ready: true`. If it reports `ready: false`, the
connection string is wrong or oxmysql is not started.

Finally join the server. You should see the character selection screen; the
first character is created with the character creator.

---

## 8. Optional: import an existing QBCore database

This is a one-off and it is never applied automatically. Read
[`migrations/legacy/README.md`](../migrations/legacy/README.md) and
[`docs/migrating-from-qbcore.md`](migrating-from-qbcore.md) first, take a full
backup, then run `migrations/legacy/100_qbcore_import.sql` by hand.

---

## 9. Updating

1. Take a database backup (section 10).
2. Replace the twelve `resources/nitro_*` folders with the new version.
3. Keep your `server.cfg` and any local changes to `config.lua` files.
4. Restart the server. New migrations are applied automatically and recorded
   in `nitro_migrations`.

If a migration was edited after it was applied, the runner reports a checksum
drift instead of re-applying it. Add a new migration file in that case.

---

## 10. Backups

```bash
mysqldump --single-transaction --routines --triggers nitro > nitro-backup.sql
```

Run this before every update. The framework never drops or truncates a table,
but a backup is still the only way back if a manual change goes wrong.

---

## 11. Troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| `Could not find dependency oxmysql for resource nitro_database` | oxmysql is missing or not started; `ensure oxmysql` must come first. |
| `No such export GetShared in resource nitro_shared` | Start order is wrong, or `nitro_shared` failed to load. Check its console output. |
| `no database connection - check your mysql_connection_string` | Wrong convar, wrong password, or MySQL not reachable. Verify with `mysql -u nitro -p nitro`. |
| No tables in the database | `AutoMigrate` was set to `false`, or the database user lacks `CREATE`/`ALTER`. |
| `Access denied for user` | The user was created for `localhost` but the server connects to `127.0.0.1` (or the reverse). Match the host. |
| Mojibake / `?` in names | The database or the tables are not `utf8mb4`. Recreate the database with section 2. |
| `JSON_TABLE` / syntax error during the legacy import | MySQL older than 8.0.4 or MariaDB older than 10.6. The framework itself does not need it. |
| txAdmin: `Cannot start() deployer due to a Recipe Error: invalid yaml` | The recipe is not valid YAML, or the deployer URL does not point at the recipe. Run `npm run lint:recipe` (it reports the exact line) and use the raw URL of `txadmin/recipe.yaml`. |
| The UI does not open | `nitro_ui` is not started, or the folder was renamed. Check `ensure nitro_ui` and the resource name. |
| Players load but no character appears | Check the `nitro_players` console lines; a failed character query is logged with the SQL error. |
| Staff commands say "no permission" | The ace is not granted, or the player reconnected before it was added. Restart the server; ACE changes are not hot reloaded for connected players. |
| `attempt to index a nil value (global 'Nitro')` in a custom resource | Nitro globals are per resource. Custom resources must use `exports`, see [the API reference](api-reference.md). |
| Server is stuck on "Initializing session manager" | The license key is invalid, or the server cannot reach the keymaster. |

Logs: the server log is the first place to look, every failure of the
framework is printed there with the resource name as a prefix
(`[nitro_database]`, `[nitro_players]`, ...).

---

## 12. Hosting notes

### txAdmin

There are two ways to deploy with txAdmin.

**A. With the recipe (recommended once the repository is published)**

txAdmin can only download a recipe from a URL, so the recipe needs the
framework to be reachable over HTTPS. There are two recipe files:

| Recipe | Use it when |
| --- | --- |
| `txadmin/recipe.yaml` | The repository contains the framework source (all folders). |
| `txadmin/recipe-zip.yaml` | Only `dist/Nitro_Framework-<version>.zip` and the recipe are uploaded. |

**A1. Upload everything with Git**

1. Publish this repository on GitHub (public) and make sure the folder that
   contains `resources/` is the repository root.
2. Edit `txadmin/recipe.yaml` and replace the placeholders:

   ```yaml
   - action: download_github
     src: https://github.com/<you>/Nitro_Framework
     ref: main
   ```

3. Validate it before uploading it anywhere:

   ```bash
   npm run lint:recipe
   ```

4. In txAdmin use *Deployer → Custom Recipe* and paste the raw URL of
   `txadmin/recipe.yaml`, for example
   `https://raw.githubusercontent.com/<you>/Nitro_Framework/main/txadmin/recipe.yaml`.

**A2. Upload two files with the GitHub web interface (no Git needed)**

GitHub's web uploader accepts 100 files per commit, which is less than the
framework has, so upload the release archive instead:

1. Create an empty public repository on GitHub.
2. *Add file → Upload files*: drag in
   `dist/Nitro_Framework-1.0.0.zip` and `txadmin/recipe-zip.yaml`, commit.
3. Edit `txadmin/recipe-zip.yaml` in the browser and replace the URL:

   ```yaml
   url: https://raw.githubusercontent.com/<you>/Nitro_Framework/main/dist/Nitro_Framework-1.0.0.zip
   ```

4. Paste the raw URL of the recipe into *Deployer → Custom Recipe*:

   ```
   https://raw.githubusercontent.com/<you>/Nitro_Framework/main/txadmin/recipe-zip.yaml
   ```

**B. Without publishing at all**

The deployer cannot read local files. Upload and extract
`dist/Nitro_Framework-<version>.zip` (section 4) into the txAdmin server data
folder with the *File Manager* or SFTP, then paste the blocks of section 5 into
the `server.cfg` tab.

### Pterodactyl and other panels

Upload the zip with the file manager, extract it at `/home/container`, then
restart. Linux servers need the files to be readable by the container user:

```bash
chown -R container:container /home/container/resources/nitro_*
chmod -R u+rwX,go+rX /home/container/resources/nitro_*
```

Windows servers: make sure the resources are not inside a folder that is
redirected by OneDrive; FXServer cannot watch those reliably.

---

## 13. Security checklist

* [ ] `sv_licenseKey` set, `sv_scriptHookAllowed 0`
* [ ] MySQL listens on `127.0.0.1` only, strong password
* [ ] `sv_maxclients` matches the OneSync slot count
* [ ] Staff groups contain only real staff
* [ ] `logs/` on the server is writable so the built-in log lines reach it
* [ ] The database is backed up on a schedule
