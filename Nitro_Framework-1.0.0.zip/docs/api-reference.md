# Nitro_Framework API reference

This document describes the public interface of every Nitro resource. Everything
that is listed here is part of the contract between the framework and the
resources that build on it. Anything that is not listed here is internal and may
change between releases.

* [Conventions](#conventions)
* [Resource order](#resource-order)
* [nitro_shared](#nitro_shared)
* [nitro_database](#nitro_database)
* [nitro_core](#nitro_core)
* [nitro_players](#nitro_players)
* [nitro_characters](#nitro_characters)
* [nitro_inventory](#nitro_inventory)
* [nitro_banking](#nitro_banking)
* [nitro_jobs](#nitro_jobs)
* [nitro_vehicles](#nitro_vehicles)
* [nitro_housing](#nitro_housing)
* [nitro_admin](#nitro_admin)
* [nitro_ui](#nitro_ui)
* [Events](#events)
* [Callbacks](#callbacks)
* [Commands](#commands)
* [Permissions](#permissions)

---

## Conventions

* Every export is called with the `exports` syntax of FiveM:

  ```lua
  local job = exports['nitro_jobs']:GetJob(characterId)
  ```

  The bracket syntax is used in the documentation because it never breaks when
  a resource name is used as a variable name.

* Server exports that mutate state return `boolean ok, string? error`. The
  error is a stable, machine readable identifier (`'no_character'`,
  `'not_enough_money'`, `'unknown_item'`, ...) so that a caller can translate it
  into a message of its own.

* Server exports that read state return the value, or `nil` when there is none.
  A missing record is never an error.

* Client exports never touch the database. They read the local copy of the
  state that the server pushed to the client.

* The framework never trusts the client. Every value that a client sends is
  validated on the server before it is used.

## Resource order

The resources have to be started in this order:

```
nitro_shared
nitro_database
nitro_core
nitro_players
nitro_characters
nitro_inventory
nitro_banking
nitro_jobs
nitro_vehicles
nitro_housing
nitro_admin
nitro_ui
```

---

## nitro_shared

The catalogue and the configuration. Everything in here is read only at runtime
except for the `Register*` calls, which exist so that other resources can add
their own items, weapons, vehicles, jobs, organisations and locations.

### Server and client exports

| Export | Description |
| --- | --- |
| `GetShared()` | The whole catalogue table. The returned table is live. |
| `GetSharedNamespace(namespace, key?)` | A single namespace: `Items`, `Weapons`, `Vehicles`, `VehicleHashes`, `Locations`, `Jobs`, `Organisations`. |
| `GetConfig(path?)` | The framework configuration. `path` is a dotted path, e.g. `'Server.Whitelist'`. |
| `GetVersion()` | The framework version string. |
| `GetItem(name)` | The definition of an item. |
| `RegisterItem(name, definition)` | Register or replace an item. Returns `boolean ok, string? reason`. |
| `RemoveItem(name)` | Remove an item. |
| `GetWeapon(name)` | The definition of a weapon. |
| `RegisterWeapon(name, definition)` | Register or replace a weapon. |
| `GetVehicle(model)` | The definition of a vehicle, by model name. |
| `GetVehicleByModel(model)` | Alias of `GetVehicle`. |
| `GetVehicleHash(hash)` | The definition of a vehicle, by its joaat hash. |
| `RegisterVehicle(model, definition)` | Register or replace a vehicle. |
| `GetJob(name)` | The definition of a job. |
| `RegisterJob(name, definition)` | Register or replace a job. |
| `RemoveJob(name)` | Remove a job. |
| `GetOrganisation(name)` | The definition of an organisation. |
| `RegisterOrganisation(name, definition)` | Register or replace an organisation. |
| `RemoveOrganisation(name)` | Remove an organisation. |
| `GetLocation(name)` | The vector4 of a location. |
| `RegisterLocation(name, definition)` | Register or replace a location. |
| `Translate(key, substitutions?)` | Translate a phrase with the active locale. |
| `SetLocale(code)` | Switch the locale at runtime. |
| `GetLocale()` | The active locale code. |

### Utility exports

`Round(value, decimals?)`, `Trim(value)`, `Split(value, delimiter?)`,
`RandomString(length)`, `RandomNumber(length)`, `DeepCopy(value)`,
`IsFunction(value)`, `Sanitize(value, maxLength?)` and `Count(value)` are
exported as well, so that other resources do not have to copy them.

---

## nitro_database

The only resource that talks to the database. Every other resource goes
through `exports['nitro_database']`, which means that there is exactly one
place where SQL is written.

| Export | Description |
| --- | --- |
| `Query(statement, params?)` | Run a statement and return every row. |
| `Single(statement, params?)` | Run a statement and return the first row. |
| `Scalar(statement, params?)` | Run a statement and return the first column of the first row. |
| `Insert(statement, params?)` | Run an insert and return the new id. |
| `Update(statement, params?)` | Run an update and return the number of affected rows. |
| `Prepare(statement, params?)` | Run a prepared statement. |
| `Transaction(queries)` | Run a list of statements inside one transaction. Returns `boolean ok, any results`. |
| `Raw(statement)` | Run a statement without parameters. |
| `RunMigrations(options?)` | Run the pending migrations. Returns `boolean ok, table result`. |
| `GetMigrationStatus()` | The state of every migration. |
| `GetDiagnostics()` | Driver information, pool statistics and error counters. |
| `IsReady()` | Is the driver connected? |
| `WaitForReady()` | Wait until the driver is connected. |
| `GetServerVersion()` | The version of the database server. |
| `GetVersion()` | The version of the resource. |

### Parameters

Parameters are always a list of values, the placeholders in the statement are
always `?`:

```lua
exports['nitro_database']:Single(
    'SELECT * FROM nitro_characters WHERE character_id = ?',
    { characterId }
)
```

Values are escaped by the driver, a value is never concatenated into the
statement. A statement that contains a value that is not a parameter is a bug.

---

## nitro_core

The session registry, the permission system, the callback system and the
connection gateway.

| Export | Description |
| --- | --- |
| `GetVersion()` | The framework version. |
| `IsPlayerLoaded(src)` | Does the player have a character loaded? |
| `GetPlayerData(src)` | The live data of a player. |
| `SetPlayerData(src, data)` | Merge data into the session of a player. |
| `ClearPlayerData(src)` | Remove the session of a player. |
| `GetOnlinePlayers()` | Every connected player as `{ src, id, name, loaded }`. |
| `GetPlayerIdentifiers(src)` | The normalised identifiers of a player. |
| `HasPermission(src, permission)` | Does the player hold the permission? |
| `IsPlayerAdmin(src)` | Does the player hold any admin permission? |
| `GetPermissions(src)` | Every permission of the player. |
| `RegisterCallback(name, handler)` | Register a server callback. The handler receives `src` first. |
| `CallCallback(name, src, ...)` | Run a server callback from the server side. |
| `TriggerClientCallback(src, name, callback, ...)` | Run a client callback on a player. |
| `GetDiagnostics()` | Session and permission statistics. |

Client side: `GetVersion()`, `IsPlayerLoaded()`, `GetPlayerData()`,
`HasPermission(permission)`, `TriggerCallback(name, callback, ...)` and
`RegisterClientCallback(name, handler)`.

---

## nitro_players

Accounts, characters, the selection screen and the persistence of a character.

| Export | Description |
| --- | --- |
| `GetAccount(src)` | The account row of a player. |
| `GetCharacters(src)` | Every character of the account of a player. |
| `CreateCharacter(src, data)` | Create a character. Returns `boolean ok, table? character, string? error`. |
| `DeleteCharacter(src, characterId)` | Delete a character. |
| `LoadCharacter(src, characterId)` | Load a character into the session of a player. |
| `UnloadCharacter(src)` | Unload the character of a player. |
| `SaveCharacter(src)` | Write the character of a player to the database. |
| `GetCharacter(characterId)` | Look a character up by its identifier. |
| `IsLoaded(src)` | Does the player have a character loaded? |
| `GetPlayerData(src)` | The live data of a player. |
| `GetSrcByCharacterId(characterId)` | The server id of the player that plays a character. |
| `SetPosition(src, position)` | Move a player. |
| `GetPosition(src)` | The position of a player. |

Client side: `GetPlayerData()`, `IsLoaded()`, `GetPosition()` and
`OpenCharacterSelection()`.

---

## nitro_characters

The profile and the appearance of a character.

| Export | Description |
| --- | --- |
| `GetProfile(src)` | The profile of the character of a player. |
| `UpdateProfile(src, changes)` | Update the profile of a character. |
| `GetAppearance(src)` | The appearance of a character. |
| `SetAppearance(src, appearance)` | Replace the appearance of a character. |
| `ApplyAppearance(src, appearance)` | Apply an appearance to a player. |

Client side: `GetAppearance()`, `ApplyAppearance(appearance)` and
`GetProfile()`.

---

## nitro_inventory

Containers, items, weight and slot handling.

| Export | Description |
| --- | --- |
| `CreateInventory(ownerType, ownerId, label?, capacity?, slots?)` | Create the container of an owner. Returns the container id. |
| `DeleteInventory(ownerType, ownerId)` | Delete the container of an owner. |
| `GetInventory(ownerType, ownerId)` | The container of an owner. |
| `GetItems(ownerType, ownerId)` | Every item of a container. |
| `AddItem(ownerType, ownerId, item, amount?, metadata?, slot?)` | Add an item. |
| `RemoveItem(ownerType, ownerId, item, amount?, serial?)` | Remove an item. |
| `HasItem(ownerType, ownerId, item, amount?)` | Does the container hold enough of an item? |
| `GetItemCount(ownerType, ownerId, item)` | The amount of an item inside a container. |
| `GetWeight(ownerType, ownerId)` | The total weight of a container, in grams. |
| `GetFreeSlot(ownerType, ownerId)` | The lowest free slot of a container. |
| `TransferItem(fromType, fromId, toType, toId, item, amount?, serial?)` | Move an item between two containers. |
| `UseItem(src, item, slot)` | Use an item. |
| `SetItemMetadata(ownerType, ownerId, slot, metadata)` | Replace the metadata of an item. |

The owner type is `'character'`, `'vehicle'`, `'property'` or `'organisation'`.

Client side: `GetItems()`, `GetWeight()` and `Refresh()`.

---

## nitro_banking

Cash, bank accounts, transfers and the transaction ledger.

| Export | Description |
| --- | --- |
| `GetAccount(characterId)` | The bank account of a character. |
| `GetBalance(characterId)` | The bank balance of a character. |
| `GetCash(characterId)` | The cash a character carries. |
| `GetTotal(characterId)` | Cash plus bank. |
| `GetBalances()` | The cash and the bank balance of the client. |
| `AddCash(characterId, amount, description?, reference?)` | Add cash. |
| `RemoveCash(characterId, amount, description?, reference?)` | Remove cash. |
| `AddBank(ownerType, ownerId, amount, description?, reference?)` | Add money to an account. |
| `RemoveBank(ownerType, ownerId, amount, description?, reference?)` | Remove money from an account. |
| `Transfer(fromType, fromId, toType, toId, amount, description?, actor?)` | Transfer money between two owners. |
| `Deposit(characterId, amount, description?)` | Move cash into the bank account. |
| `Withdraw(characterId, amount, description?)` | Move money from the bank account into the cash. |
| `GetTransactions(accountNumber, limit?)` | The ledger of an account. |
| `CreateOrganisationAccount(organisationName, label?, openingBalance?)` | Create the shared account of an organisation. |
| `Refresh()` | Refresh the local copy of the balances. |

A `reference` is an idempotency key. When the same reference is used twice,
the second call is rejected with `'duplicate_reference'` and no money moves.

---

## nitro_jobs

Jobs, grades, duty and payroll.

| Export | Description |
| --- | --- |
| `GetJob(characterId)` | The job of a character. |
| `GetGrades(jobName)` | The grades of a job as a map of level to definition. |
| `GetGrade(jobName, level)` | A single grade of a job. |
| `SetJob(src, jobName, grade?)` | Set the job and the grade of a player. |
| `SetGrade(src, grade)` | Set the grade of a player. |
| `SetDuty(src, duty)` | Toggle the duty state of a player. |
| `IsOnDuty(characterId)` | Is the character on duty? |
| `HasGradePermission(src, permission)` | Does the job of a player hold a grade permission? |
| `GetOrganisation(characterId)` | The organisation of a character. |
| `SetOrganisation(src, organisationName, grade?)` | Set the organisation of a player. |
| `SyncCatalogue()` | Write the shared job catalogue into the database. |
| `RunPayroll()` | Run the payroll now. |

Client side: `GetJob()` and `GetOrganisation()`.

---

## nitro_vehicles

Garages, impounds and the vehicles of a character.

| Export | Description |
| --- | --- |
| `GetVehicle(id)` | A vehicle row by its identifier. |
| `GetVehicles(characterId)` | Every vehicle of a character. |
| `GetVehicleByPlate(plate)` | A vehicle row by its plate. |
| `StoreVehicle(src, plate, model, garage?, properties?)` | Store a vehicle. |
| `StoreInGarage(src, plate, garageName)` | Store a vehicle in a garage. |
| `DeleteVehicle(plate)` | Delete a vehicle. |
| `SetGarage(plate, garage?)` | Move a vehicle into a garage or take it out. |
| `SetFuel(plate, fuel)` | Set the fuel level of a vehicle. |
| `GetProperties(plate)` | The state bag properties of a vehicle. |
| `SetProperties(plate, properties)` | Replace the state bag properties of a vehicle. |
| `CreateGarage(name, label, vehicleType?, coordinates?)` | Create a garage. |
| `CreateImpound(name, label, fee?, coordinates?)` | Create an impound. |
| `GetGarages()` | Every garage. |
| `GetImpounds()` | Every impound. |
| `SpawnVehicle(plate, coordinates, heading?)` | Spawn a stored vehicle. Returns the network id. |
| `RetrieveVehicle(src, plate, garageName)` | Retrieve a vehicle from a garage. |

Client side: `GetCurrentVehicle()`, `StoreVehicle(garage?)` and
`DeleteVehicle()`.

---

## nitro_housing

Properties, ownership and access.

| Export | Description |
| --- | --- |
| `GetProperties()` | Every property. |
| `GetProperty(propertyKey)` | A property by its key. |
| `GetOwnedProperties(characterId)` | Every property of a character. |
| `CreateProperty(propertyKey, label, tier?, metadata?)` | Register a property. |
| `BuyProperty(src, propertyKey)` | Buy a property. |
| `SellProperty(src, propertyKey)` | Sell a property. |
| `GetAccess(propertyKey)` | The characters that have access to a property. |
| `GrantAccess(src, propertyKey, characterId, accessLevel?)` | Give access to a property. |
| `RevokeAccess(src, propertyKey, characterId)` | Take access away. |
| `CanAccess(characterId, propertyKey)` | May the character enter the property? |
| `EnterProperty(src, propertyKey)` | Let a player enter a property. |

Client side: `EnterProperty(propertyKey)`.

---

## nitro_admin

Moderation and the audit trail.

| Export | Description |
| --- | --- |
| `IsAdmin(src)` | Is the player staff? |
| `HasPermission(src, permission)` | Does the player hold the permission? |
| `Ban(src, targetSrc?, reason?, hours?, license?)` | Ban a player. |
| `Unban(src, license)` | Remove a ban. |
| `Kick(src, targetSrc, reason?)` | Kick a player. |
| `Warn(src, targetSrc, reason?)` | Warn a player. |
| `GetBans()` | Every active ban. |
| `IsBanned(license)` | Is the licence banned? Returns `boolean banned, table? ban`. |
| `GetLog(limit?, action?)` | The most recent log entries. |
| `WriteLog(actorId, action, target?, details?)` | Write a log entry. |
| `Teleport(src, targetSrc)` | Teleport a player to another player. |
| `SetJob(src, targetSrc, jobName, grade?)` | Set the job of a player. |
| `GiveMoney(src, targetSrc, amount, kind?)` | Give money to a player. |
| `Revive(src, targetSrc)` | Revive a player. |

---

## nitro_ui

The NUI layer. Every export is a client export.

| Export | Description |
| --- | --- |
| `Notify(kind, message, duration?)` | Show a notification. `kind` is `info`, `success`, `warning` or `error`. |
| `ShowError(message)` | Show an error notification. |
| `OpenCharacterSelector(characters)` | Open the character selection. |
| `OpenCharacterCreator()` | Open the character creator. |
| `OpenInventory()` | Open the inventory. |
| `OpenBanking()` | Open the banking panel. |
| `OpenAdminMenu()` | Open the admin menu. |
| `Close()` | Close the interface. |
| `IsOpen()` | Is a panel open? |

---

## Events

### Server events

| Event | Description |
| --- | --- |
| `nitro:server:databaseReady` | The database is connected and the migrations are done. |
| `nitro:server:migrationsComplete` | The migrations finished. |
| `nitro:server:playerLoaded` | A player loaded a character. |
| `nitro:server:playerUnloaded` | A player unloaded a character. |
| `nitro:server:playerRemoved` | A player left the server. |
| `nitro:server:characterCreated` | A character was created. |
| `nitro:server:characterDeleted` | A character was deleted. |
| `nitro:server:characterUnloaded` | A character was unloaded. |
| `nitro:server:characterProfileUpdated` | The profile of a character changed. |
| `nitro:server:dutyChanged` | The duty state of a player changed. |
| `nitro:server:jobUpdated` | The job of a player changed. |
| `nitro:server:organisationUpdated` | The organisation of a player changed. |
| `nitro:server:itemUsed` | A player used an item. |
| `nitro:server:moneyTransferred` | Money moved between two owners. |
| `nitro:server:payrollCompleted` | The payroll finished. |
| `nitro:server:propertyBought` | A property was bought. |
| `nitro:server:propertySold` | A property was sold. |
| `nitro:server:propertyEntered` | A player entered a property. |
| `nitro:server:vehicleStored` | A vehicle was stored. |
| `nitro:server:vehicleDeleted` | A vehicle was deleted. |
| `nitro:server:vehicleRetrieved` | A vehicle was retrieved from a garage. |
| `nitro:server:sharedUpdate` | The shared catalogue changed. |
| `nitro:server:reloadShared` | The shared catalogue should be reloaded. |

### Client events

| Event | Description |
| --- | --- |
| `nitro:client:playerData` | The server pushed the session data. |
| `nitro:client:playerDataUpdated` | The session data changed. |
| `nitro:client:playerLoaded` | The character of the player was loaded. |
| `nitro:client:playerUnloaded` | The character of the player was unloaded. |
| `nitro:client:characterCreated` | A character was created. |
| `nitro:client:characterSelected` | A character was selected. |
| `nitro:client:characterLoaded` | The character was loaded. |
| `nitro:client:characterUnloaded` | The character was unloaded. |
| `nitro:client:readyForSelection` | The selection screen may open. |
| `nitro:client:permissions` | The permissions of the player. |
| `nitro:client:permissionsUpdated` | The permissions changed. |
| `nitro:client:inventoryUpdate` | The inventory changed. |
| `nitro:client:inventoryUpdated` | The inventory changed. |
| `nitro:client:balancesChanged` | The balances changed. |
| `nitro:client:balancesUpdated` | The balances changed. |
| `nitro:client:jobUpdated` | The job changed. |
| `nitro:client:organisationUpdated` | The organisation changed. |
| `nitro:client:payday` | The player was paid. |
| `nitro:client:useItem` | An item was used. |
| `nitro:client:applyAppearance` | An appearance must be applied. |
| `nitro:client:appearanceApplied` | The appearance was applied. |
| `nitro:client:enterProperty` | The player must enter a property. |
| `nitro:client:propertyEntered` | The player entered a property. |
| `nitro:client:vehicleStored` | The vehicle was stored. |
| `nitro:client:vehicleDeleted` | The vehicle was deleted. |
| `nitro:client:teleportToPlayer` | Teleport the player. |
| `nitro:client:revive` | Revive the player. |
| `nitro:client:adminWarning` | A staff member warned the player. |
| `nitro:client:notification` | Show a notification. |
| `nitro:client:sharedUpdate` | The shared catalogue changed. |

### UI events

`nitro:ui:notification`, `nitro:ui:showError`,
`nitro:ui:openCharacterSelector`, `nitro:ui:openCharacterCreator`,
`nitro:ui:openInventory`, `nitro:ui:openBanking`, `nitro:ui:openAdminMenu`,
`nitro:ui:updateInventory`, `nitro:ui:updateBalances`, `nitro:ui:updateJob`,
`nitro:ui:updateOrganisation` and `nitro:ui:updateProperties`.

---

## Callbacks

A callback is a request that expects an answer. The server side registers it
with `exports['nitro_core']:RegisterCallback`, the client side asks for it
through `exports['nitro_core']:TriggerCallback`.

```lua
-- server
exports['nitro_core']:RegisterCallback('nitro:example:get', function(src, id)
    return exports['nitro_database']:Single('SELECT * FROM t WHERE id = ?', { id })
end)

-- client
exports['nitro_core']:TriggerCallback('nitro:example:get', function(ok, result)
    if not ok then return end
    print(result)
end, 1)
```

The registered callbacks of the framework are:

| Callback | Description |
| --- | --- |
| `nitro:players:getCharacters` | The characters of the account of the player. |
| `nitro:players:createCharacter` | Create a character. |
| `nitro:players:deleteCharacter` | Delete a character. |
| `nitro:players:loadCharacter` | Load a character. |
| `nitro:players:isLoaded` | Does the player have a character loaded? |
| `nitro:players:getPlayerData` | The session data of the player. |
| `nitro:characters:getProfile` | The profile of the character. |
| `nitro:characters:updateProfile` | Update the profile of the character. |
| `nitro:inventory:getItems` | The items of the container of the player. |
| `nitro:inventory:useItem` | Use an item. |
| `nitro:banking:getBalances` | The balances of the player. |
| `nitro:banking:getTransactions` | The ledger of the account of the player. |
| `nitro:banking:deposit` | Deposit cash. |
| `nitro:banking:withdraw` | Withdraw cash. |
| `nitro:banking:transfer` | Transfer money. |
| `nitro:jobs:getJob` | The job of the player. |
| `nitro:jobs:toggleDuty` | Toggle the duty state. |
| `nitro:vehicles:getVehicles` | The vehicles of the character of the player. |
| `nitro:vehicles:storeVehicle` | Store a vehicle. |
| `nitro:housing:getProperties` | The properties of the server. |
| `nitro:housing:buyProperty` | Buy a property. |
| `nitro:housing:sellProperty` | Sell a property. |
| `nitro:admin:getBans` | The active bans. |
| `nitro:admin:getLog` | The audit trail. |
| `nitro:core:getPermissions` | The permissions of the player. |

---

## Commands

| Command | Resource | Description |
| --- | --- | --- |
| `/nitro` | nitro_core | Print the state of the framework. In game it requires a staff permission, in the console it always works. |
| `/nitro version` | nitro_core | Print the version of the framework (console). |
| `/nitro players` | nitro_core | List the tracked sessions (console). |
| `/nitro perms <id>` | nitro_core | List the cached permissions of a player (console). |
| `/nitro db` | nitro_core | Print the diagnostics of `nitro_database` (console). |
| `/nitro reload` | nitro_core | Request a reload of the shared catalogues (console). |
| `/characters` | nitro_players | Open the character selection again. |
| `/duty` | nitro_jobs | Toggle the duty state. |
| `/storevehicle` | nitro_vehicles | Store the vehicle the player is in. |
| `/deletevehicle` | nitro_vehicles | Delete the vehicle the player is in. |
| `/admin` | nitro_admin | Open the admin menu. |
| `/ban`, `/unban`, `/kick`, `/warn` | nitro_admin | Moderation. |
| `/tp`, `/setjob`, `/givecash`, `/givebank`, `/revive` | nitro_admin | Staff actions. |

---

## Permissions

The permissions of the framework are ACE permissions. A permission is a plain
name, the ace object of a permission is `nitro.<permission>`, so the permission
`admin` is the ace object `nitro.admin`. They are granted in the `server.cfg`
without touching any Lua code:

```
add_ace group.admin nitro.admin allow
add_ace group.superadmin nitro.superadmin allow
```

| Permission | Ace object | Description |
| --- | --- | --- |
| `admin` | `nitro.admin` | Every moderation action of the admin resource. |
| `superadmin` | `nitro.superadmin` | The powerful actions: setting a job, giving money. |
| `moderator` | `nitro.moderator` | A staff member without the moderation actions. |

The commands of the admin resource are mapped to a permission in
`resources/nitro_admin/config.lua`:

| Command | Required permission |
| --- | --- |
| `/admin`, `/ban`, `/unban`, `/kick`, `/warn`, `/tp`, `/revive` | `admin` |
| `/setjob`, `/givecash`, `/givebank` | `superadmin` |

A player that holds any of the three permissions counts as staff, which is what
`exports['nitro_core']:IsAdmin(src)` reports.
