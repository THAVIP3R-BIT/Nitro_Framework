--[[
    nitro_vehicles :: client/vehicles.lua

    Client side vehicle handling: reading the state of the vehicle a player
    is in, reporting fuel consumption and the commands that store or delete
    a vehicle.

    Original Nitro_Framework work. Licensed GPL-1.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Vehicles = Nitro.Vehicles or {}

Nitro.Vehicles.Client = {}

local Client = Nitro.Vehicles.Client

local currentVehicle = nil
local lastPosition = nil

--- The plate of a vehicle.
--- @param vehicle number
--- @return string
local function getPlate(vehicle)
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) then return '' end
    return GetVehicleNumberPlateText(vehicle) or ''
end

--- The model name of a vehicle.
--- @param vehicle number
--- @return string
local function getModel(vehicle)
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) then return '' end
    local model = GetEntityModel(vehicle)
    local vehicles = exports.nitro_shared:GetSharedNamespace('Vehicles') or {}
    for name in pairs(vehicles) do
        local hash = joaat(name)
        if hash and (hash & 0xFFFFFFFF) == (model & 0xFFFFFFFF) then
            return name
        end
    end
    local display = GetDisplayNameFromVehicleModel(model)
    if display == 'CARNOTFOUND' then return '' end
    return display
end

--- The vehicle the player is currently in.
--- @return number?
function Client.GetCurrentVehicle()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then return nil end
    return vehicle
end

--- Report the state of the vehicle the player is in.
local function reportVehicle()
    local vehicle = Client.GetCurrentVehicle()
    if not vehicle then
        currentVehicle = nil
        lastPosition = nil
        return
    end

    local plate = getPlate(vehicle)
    local state = Entity(vehicle).state
    local fuel = state and state.fuel or nil

    currentVehicle = {
        plate = plate,
        model = getModel(vehicle),
        networkId = NetworkGetNetworkIdFromEntity(vehicle),
        fuel = fuel,
    }
    lastPosition = GetEntityCoords(vehicle)
end

-- Consume fuel while driving.
CreateThread(function()
    while true do
        Wait(2000)
        if Nitro.Vehicles.Config.FuelEnabled then
            local vehicle = Client.GetCurrentVehicle()
            if vehicle then
                local position = GetEntityCoords(vehicle)
                if lastPosition then
                    local distance = #(position - lastPosition)
                    local consumption = distance * (Nitro.Vehicles.Config.FuelPerDistance or 0.02)
                    if consumption > 0 then
                        local state = Entity(vehicle).state
                        local fuel = state.fuel or Nitro.Vehicles.Config.DefaultFuel
                        fuel = math.max(0, fuel - consumption)
                        state:set('fuel', fuel, true)
                        TriggerServerEvent('nitro:net:req:vehicleFuel', getPlate(vehicle), fuel)
                    end
                end
                lastPosition = position
            else
                lastPosition = nil
            end
        end
    end
end)

--- The vehicle the player is in.
--- @return table?
exports('GetCurrentVehicle', function()
    reportVehicle()
    return currentVehicle
end)

--- Store the vehicle the player is in.
--- @param garage string?
--- @return boolean started
exports('StoreVehicle', function(garage)
    reportVehicle()
    if not currentVehicle then return false end
    TriggerServerEvent('nitro:net:req:storeVehicle', currentVehicle.plate, currentVehicle.model, garage)
    return true
end)

--- Delete the vehicle the player is in.
--- @return boolean started
exports('DeleteVehicle', function()
    reportVehicle()
    if not currentVehicle then return false end
    TriggerServerEvent('nitro:net:req:deleteVehicle', currentVehicle.plate)
    return true
end)

RegisterNetEvent('nitro:client:vehicleStored', function(plate)
    TriggerEvent('nitro:ui:notification', {
        type = 'success',
        message = ('Vehicle %s was stored.'):format(plate),
    })
end)

RegisterNetEvent('nitro:client:vehicleDeleted', function(plate)
    TriggerEvent('nitro:ui:notification', {
        type = 'success',
        message = ('Vehicle %s was deleted.'):format(plate),
    })
end)

-- Store the vehicle the player is in.
RegisterCommand('storevehicle', function()
    reportVehicle()
    if not currentVehicle then
        TriggerEvent('nitro:ui:showError', 'You are not in a vehicle.')
        return
    end
    TriggerServerEvent('nitro:net:req:storeVehicle', currentVehicle.plate, currentVehicle.model, nil)
end, false)

-- Delete the vehicle the player is in.
RegisterCommand('deletevehicle', function()
    reportVehicle()
    if not currentVehicle then
        TriggerEvent('nitro:ui:showError', 'You are not in a vehicle.')
        return
    end
    TriggerServerEvent('nitro:net:req:deleteVehicle', currentVehicle.plate)
end, false)
