--[[
    nitro_vehicles :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Vehicles = Nitro.Vehicles or {}

Nitro.Vehicles.Config = {
    -- Vehicles are created server side (OneSync) so every player sees them.
    UseServerSideVehicles = true,

    -- Fuel is stored per vehicle and decreases while driving.
    FuelEnabled = true,
    MaxFuel = 100,
    FuelPerDistance = 0.02,

    -- When a vehicle is stored it is moved to the garage of the player.
    AutoGarage = 'none',

    -- Maximum distance (in metres) a player may be from a garage to store a
    -- vehicle there.
    GarageRadius = 100,

    -- Default fuel of a freshly stored vehicle.
    DefaultFuel = 100,
}
