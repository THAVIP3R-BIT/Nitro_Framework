--[[
    nitro_vehicles :: server/events.lua

    Server side handlers for the client requests of nitro_vehicles.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Vehicles = Nitro.Vehicles or {}

local Core = Nitro.Vehicles.Core

--- Store the vehicle a player is in.
RegisterNetEvent('nitro:net:req:storeVehicle', function(plate, model, garage)
    local src = source
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return end

    local ok, vehicle, err = Core.Store(src, plate, model, garage)
    if not ok then
        TriggerClientEvent('nitro:ui:showError', src, err or 'The vehicle could not be stored.')
        return
    end

    TriggerClientEvent('nitro:client:vehicleStored', src, plate)
    TriggerEvent('nitro:server:vehicleStored', src, vehicle)
end)

--- Delete a vehicle.
RegisterNetEvent('nitro:net:req:deleteVehicle', function(plate)
    local src = source
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return end

    local vehicle = Core.GetByPlate(plate)
    if not vehicle then return end
    if vehicle.character_id and vehicle.character_id ~= data.characterId then
        TriggerClientEvent('nitro:ui:showError', src, 'You do not own this vehicle.')
        return
    end

    local ok = Core.Delete(plate)
    if not ok then return end

    TriggerClientEvent('nitro:client:vehicleDeleted', src, plate)
    TriggerEvent('nitro:server:vehicleDeleted', src, plate)
end)

--- Report the fuel level of a vehicle.
RegisterNetEvent('nitro:net:req:vehicleFuel', function(plate, fuel)
    local src = source
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return end

    local vehicle = Core.GetByPlate(plate)
    if not vehicle then return end
    if vehicle.character_id and vehicle.character_id ~= data.characterId then return end

    Core.SetFuel(plate, fuel)
end)

--- Store a vehicle in a garage.
exports('StoreInGarage', function(src, plate, garageName)
    local garage = Nitro.Vehicles.Garages.Get(garageName)
    if not garage then return false, 'unknown_garage' end

    local position = GetEntityCoords(GetPlayerPed(src))
    if not Nitro.Vehicles.Garages.IsInside(garage, { x = position.x, y = position.y, z = position.z }) then
        return false, 'too_far_away'
    end

    local ok, err = Core.SetGarage(plate, garageName)
    if not ok then return false, err end
    return true, nil
end)
