--[[
    nitro_vehicles :: server/vehicles.lua

    The vehicle store.

    A vehicle row holds everything that survives a restart: the owner, the
    plate, the model, the garage it is stored in, the fuel level and the
    applied modifications.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Vehicles = Nitro.Vehicles or {}

Nitro.Vehicles.Core = {}

local Core = Nitro.Vehicles.Core

--- A vehicle row by its plate.
--- @param plate string
--- @return table?
function Core.GetByPlate(plate)
    if type(plate) ~= 'string' then return nil end
    return exports.nitro_database:Single(
        'SELECT * FROM nitro_vehicles WHERE plate = ?',
        { plate }
    )
end

--- A vehicle row by its identifier.
--- @param id number
--- @return table?
function Core.Get(id)
    if not id then return nil end
    return exports.nitro_database:Single('SELECT * FROM nitro_vehicles WHERE id = ?', { id })
end

--- Every vehicle of a character.
--- @param characterId string
--- @return table[]
function Core.GetByOwner(characterId)
    if type(characterId) ~= 'string' then return {} end
    return exports.nitro_database:Query(
        'SELECT * FROM nitro_vehicles WHERE character_id = ? ORDER BY id ASC',
        { characterId }
    ) or {}
end

--- Store a vehicle in the database.
--- @param src number
--- @param plate string
--- @param model string
--- @param garage string?
--- @param properties table?
--- @return boolean ok, table? vehicle, string? error
function Core.Store(src, plate, model, garage, properties)
    if type(plate) ~= 'string' or plate == '' then return false, nil, 'invalid_plate' end
    if type(model) ~= 'string' or model == '' then return false, nil, 'invalid_model' end

    local data = exports.nitro_players:GetPlayerData(src)
    local characterId = data and data.characterId or nil

    local existing = Core.GetByPlate(plate)
    if existing then
        exports.nitro_database:Update(
            'UPDATE nitro_vehicles SET character_id = ?, model = ?, garage = ?, state = ?, fuel = ?, properties = ?, updated_at = NOW() WHERE plate = ?',
            {
                characterId,
                model,
                garage,
                garage and 'garaged' or 'out',
                existing.fuel or Nitro.Vehicles.Config.DefaultFuel,
                properties and json.encode(properties) or existing.properties,
                plate,
            }
        )
        return true, Core.GetByPlate(plate), nil
    end

    local insertId = exports.nitro_database:Insert(
        'INSERT INTO nitro_vehicles (character_id, plate, model, garage, state, fuel, properties) VALUES (?, ?, ?, ?, ?, ?, ?)',
        {
            characterId,
            plate,
            model,
            garage,
            garage and 'garaged' or 'out',
            Nitro.Vehicles.Config.DefaultFuel,
            properties and json.encode(properties) or json.encode({}),
        }
    )

    if not insertId or insertId == 0 then return false, nil, 'insert_failed' end
    return true, Core.GetByPlate(plate), nil
end

--- Delete a vehicle.
--- @param plate string
--- @return boolean ok, string? error
function Core.Delete(plate)
    local affected = exports.nitro_database:Update(
        'DELETE FROM nitro_vehicles WHERE plate = ?',
        { plate }
    )
    return affected > 0, affected > 0 and nil or 'not_found'
end

--- Move a vehicle to a garage.
--- @param plate string
--- @param garage string?
--- @return boolean ok, string? error
function Core.SetGarage(plate, garage)
    local affected = exports.nitro_database:Update(
        'UPDATE nitro_vehicles SET garage = ?, state = ? WHERE plate = ?',
        { garage, garage and 'garaged' or 'out', plate }
    )
    return affected > 0, affected > 0 and nil or 'not_found'
end

--- Set the fuel level of a vehicle.
--- @param plate string
--- @param fuel number
--- @return boolean ok, string? error
function Core.SetFuel(plate, fuel)
    fuel = math.max(0, math.min(Nitro.Vehicles.Config.MaxFuel or 100, tonumber(fuel) or 0))
    local affected = exports.nitro_database:Update(
        'UPDATE nitro_vehicles SET fuel = ? WHERE plate = ?',
        { fuel, plate }
    )
    return affected > 0, affected > 0 and nil or 'not_found'
end

--- The modifications of a vehicle.
--- @param plate string
--- @return table
function Core.GetProperties(plate)
    local vehicle = Core.GetByPlate(plate)
    if not vehicle or not vehicle.properties then return {} end
    local properties = json.decode(vehicle.properties)
    return type(properties) == 'table' and properties or {}
end

--- Replace the modifications of a vehicle.
--- @param plate string
--- @param properties table
--- @return boolean ok, string? error
function Core.SetProperties(plate, properties)
    if type(properties) ~= 'table' then return false, 'invalid_properties' end
    local affected = exports.nitro_database:Update(
        'UPDATE nitro_vehicles SET properties = ? WHERE plate = ?',
        { json.encode(properties), plate }
    )
    return affected > 0, affected > 0 and nil or 'not_found'
end

--- Create a server side vehicle and apply the stored state.
--- @param plate string
--- @param coordinates table
--- @param heading number?
--- @return number? network id
function Core.Spawn(plate, coordinates, heading)
    local vehicle = Core.GetByPlate(plate)
    if not vehicle then return nil end

    local model = vehicle.model
    local hash = type(model) == 'string' and joaat(model) or tonumber(model)
    if not hash or hash == 0 then return nil end

    local networkId
    if Nitro.Vehicles.Config.UseServerSideVehicles then
        networkId = CreateVehicleServerSetter(hash, 'automobile', coordinates.x, coordinates.y, coordinates.z, heading or 0.0, 0.0, true, false)
        if networkId and networkId ~= 0 then
            SetEntityRotation(networkId, 0.0, 0.0, heading or 0.0, 1, 1)
            SetVehicleNumberPlateText(networkId, plate)
            SetVehicleOnGroundProperly(networkId)
            local state = Entity(networkId).state
            state:set('plate', plate, true)
            state:set('fuel', vehicle.fuel, true)
            state:set('nitroVehicle', true, true)
        end
    end

    return networkId
end

--- Delete the network entity of a vehicle.
--- @param networkId number
function Core.Despawn(networkId)
    if not networkId or networkId == 0 then return end
    if DoesEntityExist(networkId) then
        DeleteEntity(networkId)
    end
end
