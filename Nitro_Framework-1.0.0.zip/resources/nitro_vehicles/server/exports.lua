--[[
    nitro_vehicles :: server/exports.lua

    Public server API of nitro_vehicles.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Vehicles = Nitro.Vehicles or {}

local Core = Nitro.Vehicles.Core
local Garages = Nitro.Vehicles.Garages

--- A vehicle row by its plate.
--- @param plate string
--- @return table?
exports('GetVehicleByPlate', function(plate)
    return Core.GetByPlate(plate)
end)

--- A vehicle row by its identifier.
--- @param id number
--- @return table?
exports('GetVehicle', function(id)
    return Core.Get(id)
end)

--- Every vehicle of a character.
--- @param characterId string
--- @return table[]
exports('GetVehicles', function(characterId)
    return Core.GetByOwner(characterId)
end)

--- Store a vehicle.
--- @param src number
--- @param plate string
--- @param model string
--- @param garage string?
--- @param properties table?
--- @return boolean ok, table? vehicle, string? error
exports('StoreVehicle', function(src, plate, model, garage, properties)
    return Core.Store(src, plate, model, garage, properties)
end)

--- Delete a vehicle.
--- @param plate string
--- @return boolean ok, string? error
exports('DeleteVehicle', function(plate)
    return Core.Delete(plate)
end)

--- Move a vehicle to a garage.
--- @param plate string
--- @param garage string?
--- @return boolean ok, string? error
exports('SetGarage', function(plate, garage)
    return Core.SetGarage(plate, garage)
end)

--- @param plate string
--- @param fuel number
--- @return boolean ok, string? error
exports('SetFuel', function(plate, fuel)
    return Core.SetFuel(plate, fuel)
end)

--- @param plate string
--- @return table
exports('GetProperties', function(plate)
    return Core.GetProperties(plate)
end)

--- @param plate string
--- @param properties table
--- @return boolean ok, string? error
exports('SetProperties', function(plate, properties)
    return Core.SetProperties(plate, properties)
end)

--- Create a garage.
--- @param name string
--- @param label string
--- @param vehicleType string?
--- @param coordinates table?
--- @return boolean ok, string? error
exports('CreateGarage', function(name, label, vehicleType, coordinates)
    return Garages.Create(name, label, vehicleType, coordinates)
end)

--- Create an impound.
--- @param name string
--- @param label string
--- @param fee number?
--- @param coordinates table?
--- @return boolean ok, string? error
exports('CreateImpound', function(name, label, fee, coordinates)
    return Garages.CreateImpound(name, label, fee, coordinates)
end)

--- @return table[]
exports('GetGarages', function()
    return Garages.GetAll()
end)

--- @return table[]
exports('GetImpounds', function()
    return Garages.GetAllImpounds()
end)

--- Spawn a stored vehicle.
--- @param plate string
--- @param coordinates table
--- @param heading number?
--- @return number? network id
exports('SpawnVehicle', function(plate, coordinates, heading)
    return Core.Spawn(plate, coordinates, heading)
end)

--- Retrieve a vehicle from a garage.
--- @param src number
--- @param plate string
--- @param garageName string
--- @return boolean ok, string? error
exports('RetrieveVehicle', function(src, plate, garageName)
    local vehicle = Core.GetByPlate(plate)
    if not vehicle then return false, 'not_found' end

    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end
    if vehicle.character_id and vehicle.character_id ~= data.characterId then
        return false, 'not_owner'
    end

    local garage = Garages.Get(garageName)
    if not garage then return false, 'unknown_garage' end

    local coordinates = garage.coordinates and json.decode(garage.coordinates) or nil
    if not coordinates then return false, 'garage_without_position' end

    local networkId = Core.Spawn(plate, coordinates)
    if not networkId then return false, 'spawn_failed' end

    Core.SetGarage(plate, nil)
    TriggerEvent('nitro:server:vehicleRetrieved', src, plate, networkId)
    return true, nil
end)

-- ── Callbacks ────────────────────────────────────────────────────────────────

exports.nitro_core:RegisterCallback('nitro:vehicles:getVehicles', function(src)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return {} end
    return Core.GetByOwner(data.characterId)
end)

exports.nitro_core:RegisterCallback('nitro:vehicles:storeVehicle', function(src, plate, model, garage, properties)
    local ok, vehicle, err = Core.Store(src, plate, model, garage, properties)
    if not ok then return false, err end
    return true, vehicle
end)
