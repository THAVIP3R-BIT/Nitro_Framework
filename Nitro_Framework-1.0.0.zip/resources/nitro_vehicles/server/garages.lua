--[[
    nitro_vehicles :: server/garages.lua

    Garages and impounds.

    A garage is a place where vehicles can be stored and retrieved. An
    impound is a special garage where a fee has to be paid.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Vehicles = Nitro.Vehicles or {}

Nitro.Vehicles.Garages = {}

local Garages = Nitro.Vehicles.Garages

--- Create a garage.
--- @param name string
--- @param label string
--- @param vehicleType string
--- @param coordinates table?
--- @return boolean ok, string? error
function Garages.Create(name, label, vehicleType, coordinates)
    if type(name) ~= 'string' or name == '' then return false, 'invalid_name' end
    exports.nitro_database:Insert(
        'INSERT INTO nitro_garages (name, label, vehicle_type, coordinates) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), vehicle_type = VALUES(vehicle_type), coordinates = VALUES(coordinates)',
        { name, label or name, vehicleType or 'automobile', coordinates and json.encode(coordinates) or nil }
    )
    return true, nil
end

--- Create an impound.
--- @param name string
--- @param label string
--- @param fee number
--- @param coordinates table?
--- @return boolean ok, string? error
function Garages.CreateImpound(name, label, fee, coordinates)
    if type(name) ~= 'string' or name == '' then return false, 'invalid_name' end
    exports.nitro_database:Insert(
        'INSERT INTO nitro_impounds (name, label, fee, coordinates) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), fee = VALUES(fee), coordinates = VALUES(coordinates)',
        { name, label or name, tonumber(fee) or 500, coordinates and json.encode(coordinates) or nil }
    )
    return true, nil
end

--- Every garage.
--- @return table[]
function Garages.GetAll()
    return exports.nitro_database:Query('SELECT * FROM nitro_garages ORDER BY name ASC', {}) or {}
end

--- Every impound.
--- @return table[]
function Garages.GetAllImpounds()
    return exports.nitro_database:Query('SELECT * FROM nitro_impounds ORDER BY name ASC', {}) or {}
end

--- A single garage.
--- @param name string
--- @return table?
function Garages.Get(name)
    if type(name) ~= 'string' then return nil end
    return exports.nitro_database:Single('SELECT * FROM nitro_garages WHERE name = ?', { name })
end

--- A single impound.
--- @param name string
--- @return table?
function Garages.GetImpound(name)
    if type(name) ~= 'string' then return nil end
    return exports.nitro_database:Single('SELECT * FROM nitro_impounds WHERE name = ?', { name })
end

--- Is a position inside the radius of a garage?
--- @param garage table
--- @param coordinates table { x = number, y = number, z = number }
--- @return boolean
function Garages.IsInside(garage, coordinates)
    if type(garage) ~= 'table' or type(garage.coordinates) ~= 'string' then return false end
    local stored = json.decode(garage.coordinates)
    if type(stored) ~= 'table' or not stored.x then return false end
    if type(coordinates) ~= 'table' or not coordinates.x then return false end

    local dx = stored.x - coordinates.x
    local dy = stored.y - coordinates.y
    local dz = stored.z - coordinates.z
    local distance = math.sqrt(dx * dx + dy * dy + dz * dz)
    return distance <= (Nitro.Vehicles.Config.GarageRadius or 100)
end
