fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_vehicles'
author 'Nitro_Framework'
description 'Nitro_Framework vehicles: garages, impounds, plates and vehicle state.'
version '1.0.0'

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/garages.lua',
    'server/vehicles.lua',
    'server/events.lua',
    'server/exports.lua',
}

client_scripts {
    'client/vehicles.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'
dependency 'nitro_core'
dependency 'nitro_players'

exports {
    'GetVehicle',
    'GetVehicles',
    'GetVehicleByPlate',
    'GetCurrentVehicle',
    'StoreVehicle',
    'StoreInGarage',
    'DeleteVehicle',
    'SetGarage',
    'SetFuel',
    'SetProperties',
    'GetProperties',
    'CreateGarage',
    'CreateImpound',
    'GetGarages',
    'GetImpounds',
    'SpawnVehicle',
    'RetrieveVehicle',
}
