--[[
    nitro_core :: server/callbacks.lua

    Client <-> server callback bridge.

    A callback is a request that expects an answer. The client asks the
    server, the server answers on the same request id. The reverse direction
    (the server asking the client) uses a separate pair of events so the two
    flows can never be confused.

        client -> server   nitro:net:req:callback
        server -> client   nitro:net:res:callback
        server -> client   nitro:net:req:clientCallback
        client -> server   nitro:net:res:clientCallback

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

Nitro.Core.Callbacks = {}
Nitro.Core.ClientCallbacks = {}

local registry = Nitro.Core.Callbacks
local clientRegistry = Nitro.Core.ClientCallbacks

--- Registered server side callbacks, name -> function(src, ...).
local handlers = {}
--- Pending server -> client callbacks, requestId -> function(ok, result).
local pending = {}
--- Last request timestamp per player, used for rate limiting.
local lastRequest = {}

local sharedConfigCache = {}

--- Read a shared configuration value with a cached fallback.
--- @param path string
--- @param default any
--- @return any
local function sharedConfig(path, default)
    local cached = sharedConfigCache[path]
    if cached ~= nil then return cached end
    local ok, value = pcall(function()
        return exports.nitro_shared:GetConfig(path)
    end)
    if ok and value ~= nil then
        sharedConfigCache[path] = value
        return value
    end
    return default
end

--- Rate limit a player.
--- @param src number
--- @param kind string 'normal' | 'money'
--- @return boolean allowed
local function allowRequest(src, kind)
    local limit = sharedConfig('Security.RateLimit', 750)
    if kind == 'money' then
        limit = sharedConfig('Security.MoneyRateLimit', 1500)
    end
    local now = GetGameTimer()
    local previous = lastRequest[src]
    if previous and (now - previous) < limit then return false end
    lastRequest[src] = now
    return true
end

--- Register a server side callback.
--- @param name string
--- @param handler function(src, ...)
--- @return boolean ok, string? reason
function Nitro.Core.RegisterCallback(name, handler)
    if type(name) ~= 'string' or name == '' then return false, 'invalid_name' end
    if type(handler) ~= 'function' then return false, 'invalid_handler' end
    handlers[name] = handler
    return true
end

--- Remove a server side callback.
--- @param name string
--- @return boolean
function Nitro.Core.RemoveCallback(name)
    if type(name) ~= 'string' then return false end
    handlers[name] = nil
    return true
end

--- @return number amount of registered server side callbacks
function Nitro.Core.CallbackCount()
    local count = 0
    for _ in pairs(handlers) do count = count + 1 end
    return count
end

--- Call a registered server side callback.
--- @param name string
--- @param src number
--- @param ... any
--- @return boolean ok, any result
function Nitro.Core.CallCallback(name, src, ...)
    if type(name) ~= 'string' then return false, 'unknown_callback' end
    local handler = handlers[name]
    if not handler then return false, 'unknown_callback' end
    local ok, result = pcall(handler, src, ...)
    if not ok then
        print(('^1[nitro_core] callback "%s" failed: %s^0'):format(name, tostring(result)))
        return false, 'callback_error'
    end
    return true, result
end

--- Ask a client to run one of its registered callbacks.
--- @param src number
--- @param name string
--- @param callback function(ok, result)
--- @param ... any
--- @return boolean started
function Nitro.Core.TriggerClientCallback(src, name, callback, ...)
    if type(src) ~= 'number' or src <= 0 then return false end
    if type(name) ~= 'string' or name == '' then return false end
    if type(callback) ~= 'function' then return false end

    local requestId = ('%d-%d'):format(GetGameTimer(), math.random(100000, 999999))
    pending[requestId] = callback

    TriggerClientEvent('nitro:net:req:clientCallback', src, requestId, name, { ... })
    return true
end

-- ── Client -> server callbacks ───────────────────────────────────────────────

RegisterNetEvent('nitro:net:req:callback', function(requestId, name, args)
    local src = source
    if type(requestId) ~= 'string' or type(name) ~= 'string' then return end
    if not allowRequest(src, 'normal') then
        TriggerClientEvent('nitro:net:res:callback', src, requestId, false, 'rate_limited')
        return
    end

    local handler = handlers[name]
    if not handler then
        TriggerClientEvent('nitro:net:res:callback', src, requestId, false, 'unknown_callback')
        return
    end

    args = type(args) == 'table' and args or {}
    -- Multiple return values are preserved so a callback can answer with
    -- (false, reason) as well as a single value.
    local packed = table.pack(pcall(handler, src, table.unpack(args)))
    local succeeded = packed[1]
    if not succeeded then
        print(('^1[nitro_core] callback "%s" failed: %s^0'):format(name, tostring(packed[2])))
        TriggerClientEvent('nitro:net:res:callback', src, requestId, false, 'callback_error')
        return
    end
    local results = table.pack(table.unpack(packed, 2, packed.n))
    TriggerClientEvent('nitro:net:res:callback', src, requestId, true, table.unpack(results, 1, results.n))
end)

-- ── Server -> client callbacks ───────────────────────────────────────────────

RegisterNetEvent('nitro:net:res:clientCallback', function(requestId, ok, ...)
    local callback = pending[requestId]
    if not callback then return end
    pending[requestId] = nil
    callback(ok == true, ...)
end)

--- Remove every pending server -> client callback of a player.
--- @param src number
function Nitro.Core.ClearPendingCallbacks(src)
    for requestId, callback in pairs(pending) do
        if type(callback) == 'function' then
            -- Callbacks are anonymous, so they are dropped by the timeout in
            -- server/server.lua instead. Nothing to do here.
        end
        pending[requestId] = nil
    end
end

--- Drop cached rate limit state for a player.
--- @param src number
function Nitro.Core.ForgetPlayer(src)
    lastRequest[src] = nil
    Nitro.Core.Permissions.Forget(src)
end
