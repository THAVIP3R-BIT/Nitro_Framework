--[[
    nitro_core :: server/server.lua

    The public server API of nitro_core.

    Everything another Nitro resource needs is exposed here as an export so
    the framework has a single, documented entry point.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

--- @return string framework version
exports('GetVersion', function()
    return Nitro.GetVersionString()
end)

-- ── Sessions ─────────────────────────────────────────────────────────────────

--- @param src number
--- @return boolean
exports('IsPlayerLoaded', function(src)
    return Nitro.Core.Sessions.IsLoaded(src)
end)

--- @param src number
--- @return table
exports('GetPlayerData', function(src)
    return Nitro.Core.Sessions.GetData(src)
end)

--- @param src number
--- @param data table
exports('SetPlayerData', function(src, data)
    Nitro.Core.Sessions.SetData(src, data)
end)

--- @param src number
exports('ClearPlayerData', function(src)
    Nitro.Core.Sessions.RemoveValue(src, 'characterId')
    Nitro.Core.Sessions.MarkUnloaded(src)
end)

--- Every connected player.
--- @return table[] list of { src = number, id = string, name = string, loaded = boolean }
exports('GetOnlinePlayers', function()
    local players = GetPlayers()
    local result = {}
    for _, playerId in ipairs(players) do
        local src = tonumber(playerId)
        if src then
            local identity = GetPlayerIdentifiers(src)
            result[#result + 1] = {
                src = src,
                id = identity.license or identity.steam or identity.discord or playerId,
                name = GetPlayerName(src) or 'unknown',
                loaded = Nitro.Core.Sessions.IsLoaded(src),
            }
        end
    end
    return result
end)

--- Normalised identifiers of a player.
--- @param src number
--- @return table { license = string?, steam = string?, discord = string?, xbl = string?, live = string?, fivem = string?, ip = string? }
exports('GetPlayerIdentifiers', function(src)
    local identifiers = {}
    for _, identifier in ipairs(GetPlayerIdentifiers(src) or {}) do
        local prefix, value = identifier:match('^([^:]+):(.+)$')
        if prefix then
            if prefix == 'license2' then
                prefix = 'license'
            end
            identifiers[prefix] = value
        end
    end
    return identifiers
end)

-- ── Permissions ──────────────────────────────────────────────────────────────

--- @param src number
--- @param permission string
--- @return boolean
exports('HasPermission', function(src, permission)
    return Nitro.Core.Permissions.Has(src, permission)
end)

--- @param src number
--- @return boolean
exports('IsPlayerAdmin', function(src)
    return Nitro.Core.Permissions.IsAdmin(src)
end)

--- @param src number
--- @return table
exports('GetPermissions', function(src)
    return Nitro.Core.Permissions.List(src)
end)

-- ── Callbacks ────────────────────────────────────────────────────────────────

--- @param name string
--- @param handler function(src, ...)
--- @return boolean ok, string? reason
exports('RegisterCallback', function(name, handler)
    return Nitro.Core.RegisterCallback(name, handler)
end)

--- @param name string
--- @param src number
--- @param ... any
--- @return boolean ok, any result
exports('CallCallback', function(name, src, ...)
    return Nitro.Core.CallCallback(name, src, ...)
end)

--- @param src number
--- @param name string
--- @param callback function(ok, result)
--- @param ... any
exports('TriggerClientCallback', function(src, name, callback, ...)
    return Nitro.Core.TriggerClientCallback(src, name, callback, ...)
end)

-- ── Diagnostics ──────────────────────────────────────────────────────────────

--- @return table
exports('GetDiagnostics', function()
    return {
        version = Nitro.GetVersionString(),
        sessions = Nitro.Core.Sessions.Count(),
        callbacks = Nitro.Core.CallbackCount(),
        uptime = math.floor(GetGameTimer() / 1000),
    }
end)

-- ── Lifecycle ────────────────────────────────────────────────────────────────

--- Permissions the player currently holds, as a lookup table.
Nitro.Core.RegisterCallback('nitro:core:getPermissions', function(src)
    local list = Nitro.Core.Permissions.List(src)
    local result = {}
    for _, permission in ipairs(list) do
        result[permission] = true
    end
    -- The admin groups are always reported so the client can show the menu.
    for group in pairs(Nitro.Core.Config.AdminGroups or {}) do
        if Nitro.Core.Permissions.Has(src, group) then
            result[group] = true
        end
    end
    TriggerClientEvent('nitro:client:permissions', src, result)
    return result
end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    Nitro.Core.ForgetPlayer(src)
    Nitro.Core.Sessions.Remove(src)
end)

CreateThread(function()
    if Nitro.Core.Config.StartupBanner then
        print(('^2[Nitro]^7 Nitro_Framework %s "%s" started.'):format(
            Nitro.GetVersionString(),
            Nitro.Version.codename or 'core'
        ))
    end
end)
