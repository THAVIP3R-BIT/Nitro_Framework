--[[
    nitro_core :: server/permissions.lua

    Ace based permission handling.

    Every permission is a plain string. Staff permissions are registered as ace
    objects (`add_ace group.admin nitro.admin allow`) and can therefore be
    granted per resource in server.cfg without touching any Lua code.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

Nitro.Core.Permissions = {}

local Permissions = Nitro.Core.Permissions

--- Permissions that are cached per player. Ace objects are resolved by the
--- server and can change at runtime, so the cache is short lived.
local cache = {}
local cacheExpiry = {}
local CACHE_TTL = 5000

--- Resolve the ace object name for a permission.
--- @param permission string
--- @return string
local function aceObject(permission)
    return ('nitro.%s'):format(permission)
end

--- Clear the cached permission lookup for a player.
--- @param src number
function Permissions.Forget(src)
    cache[src] = nil
    cacheExpiry[src] = nil
end

--- Clear every cached permission lookup.
function Permissions.ForgetAll()
    cache = {}
    cacheExpiry = {}
end

--- Check whether a player holds a permission.
--- @param src number
--- @param permission string
--- @return boolean
function Permissions.Has(src, permission)
    if type(src) ~= 'number' or src <= 0 then return false end
    if type(permission) ~= 'string' or permission == '' then return false end

    local now = GetGameTimer()
    local cached = cache[src]
    if cached and cacheExpiry[src] and cacheExpiry[src] > now then
        return cached[permission] == true
    end

    local resolved = IsPlayerAceAllowed(src, aceObject(permission)) == true
    local playerCache = cache[src] or {}
    playerCache[permission] = resolved
    cache[src] = playerCache
    cacheExpiry[src] = now + CACHE_TTL
    return resolved
end

--- Check whether a player is staff (any of the configured admin groups).
--- @param src number
--- @return boolean
function Permissions.IsAdmin(src)
    if type(src) ~= 'number' or src <= 0 then return false end
    for group in pairs(Nitro.Core.Config.AdminGroups or {}) do
        if Permissions.Has(src, group) then return true end
    end
    return false
end

--- List every permission a player holds.
--- Only permissions that were explicitly checked are known; the framework
--- additionally reports the ace objects the player is allowed to use.
--- @param src number
--- @return table
function Permissions.List(src)
    local result = {}
    local playerCache = cache[src] or {}
    for permission, allowed in pairs(playerCache) do
        if allowed then result[#result + 1] = permission end
    end
    table.sort(result)
    return result
end

--- Build the ace objects a player is allowed to use.
--- Used by the admin resource to show the current access level.
--- @param src number
--- @return table
function Permissions.GetAceObjects(src)
    local objects = {}
    for group in pairs(Nitro.Core.Config.AdminGroups or {}) do
        objects[#objects + 1] = aceObject(group)
    end
    table.sort(objects)
    return objects
end
