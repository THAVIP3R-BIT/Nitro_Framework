--[[
    nitro_core :: server/sessions.lua

    The in-memory session registry.

    A "session" is the server side representation of a connected player. It
    holds the data that other resources push to the core (character id, job,
    money, ...) so that every resource can read it without owning it.

    The registry never talks to the database. Persistence is the job of
    nitro_players; the core only remembers what it was told.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

Nitro.Core.Sessions = {}

local Sessions = Nitro.Core.Sessions

--- src -> session table
local sessions = {}

--- Create (or fetch) the session of a player.
--- @param src number
--- @return table
function Sessions.Get(src)
    if type(src) ~= 'number' or src <= 0 then return {} end
    local session = sessions[src]
    if not session then
        session = {
            src = src,
            loaded = false,
            loadedAt = nil,
            data = {},
        }
        sessions[src] = session
    end
    return session
end

--- Mark a player as fully loaded.
--- @param src number
--- @param data table? initial data
function Sessions.MarkLoaded(src, data)
    local session = Sessions.Get(src)
    session.loaded = true
    session.loadedAt = GetGameTimer()
    if type(data) == 'table' then
        for key, value in pairs(data) do
            session.data[key] = value
        end
    end
    TriggerEvent('nitro:server:playerLoaded', src, session.data)
end

--- Mark a player as no longer loaded.
--- @param src number
function Sessions.MarkUnloaded(src)
    local session = sessions[src]
    if not session then return end
    session.loaded = false
    TriggerEvent('nitro:server:playerUnloaded', src, session.data)
end

--- Remove a player from the registry.
--- @param src number
function Sessions.Remove(src)
    local session = sessions[src]
    sessions[src] = nil
    if session then
        TriggerEvent('nitro:server:playerRemoved', src, session.data)
    end
end

--- @param src number
--- @return boolean
function Sessions.IsLoaded(src)
    local session = sessions[src]
    return session ~= nil and session.loaded == true
end

--- @param src number
--- @return table
function Sessions.GetData(src)
    return Sessions.Get(src).data or {}
end

--- @param src number
--- @param key string
--- @return any
function Sessions.GetValue(src, key)
    return Sessions.GetData(src)[key]
end

--- Store a single value on a player session.
--- @param src number
--- @param key string
--- @param value any
function Sessions.SetValue(src, key, value)
    if type(src) ~= 'number' or src <= 0 then return end
    if type(key) ~= 'string' or key == '' then return end
    Sessions.Get(src).data[key] = value
end

--- Merge a table into a player session.
--- @param src number
--- @param data table
function Sessions.SetData(src, data)
    if type(src) ~= 'number' or src <= 0 then return end
    if type(data) ~= 'table' then return end
    local session = Sessions.Get(src)
    for key, value in pairs(data) do
        session.data[key] = value
    end
end

--- Remove a key from a player session.
--- @param src number
--- @param key string
function Sessions.RemoveValue(src, key)
    if type(src) ~= 'number' or src <= 0 then return end
    local session = sessions[src]
    if session then session.data[key] = nil end
end

--- Every connected player with a session.
--- @return table[] list of { src = number, data = table, loaded = boolean }
function Sessions.GetAll()
    local list = {}
    for src, session in pairs(sessions) do
        list[#list + 1] = {
            src = src,
            loaded = session.loaded,
            loadedAt = session.loadedAt,
            data = session.data,
        }
    end
    table.sort(list, function(a, b) return a.src < b.src end)
    return list
end

--- @return number amount of tracked sessions
function Sessions.Count()
    local count = 0
    for _ in pairs(sessions) do count = count + 1 end
    return count
end
