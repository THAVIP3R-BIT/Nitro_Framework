--[[
    nitro_core :: server/commands.lua

    Server console commands for framework operators.

        /nitro              print a short status report
        /nitro version      print version information
        /nitro players      list the tracked sessions
        /nitro perms [id]   list the permissions of a player
        /nitro db           print the database diagnostics
        /nitro reload       reload the shared catalogues

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

local function printLine(text)
    print(('^3[nitro_core]^0 %s'):format(tostring(text)))
end

local function statusReport()
    local sessions = Nitro.Core.Sessions.GetAll()
    local loaded = 0
    for _, session in ipairs(sessions) do
        if session.loaded then loaded = loaded + 1 end
    end

    printLine('Nitro_Framework status')
    printLine(('  version      : %s'):format(Nitro.GetVersionString()))
    printLine(('  sessions     : %d (%d loaded)'):format(#sessions, loaded))
    printLine(('  callbacks    : %d'):format(Nitro.Core.CallbackCount()))
    printLine(('  uptime       : %d minutes'):format(math.floor((GetGameTimer() / 1000) / 60)))
end

if Nitro.Core.Config.Commands then
    RegisterCommand('nitro', function(source, args)
        if source == 0 then
            local command = args[1] or 'status'
            if command == 'version' then
                printLine(('Nitro_Framework %s'):format(Nitro.GetVersionString()))
            elseif command == 'players' then
                for _, session in ipairs(Nitro.Core.Sessions.GetAll()) do
                    local name = session.data.characterId or session.data.name or 'unknown'
                    printLine(('  [%d] %s (loaded: %s)'):format(session.src, tostring(name), tostring(session.loaded)))
                end
            elseif command == 'perms' then
                local target = tonumber(args[2]) or 0
                if target <= 0 then
                    printLine('usage: /nitro perms <server id>')
                else
                    local permissions = Nitro.Core.Permissions.List(target)
                    if #permissions == 0 then
                        printLine(('no cached permissions for %d'):format(target))
                    else
                        printLine(('permissions for %d: %s'):format(target, table.concat(permissions, ', ')))
                    end
                end
            elseif command == 'reload' then
                TriggerEvent('nitro:server:reloadShared')
                printLine('shared catalogue reload requested')
            elseif command == 'db' then
                local ok, diagnostics = pcall(function()
                    return exports.nitro_database:GetDiagnostics()
                end)
                if not ok or type(diagnostics) ~= 'table' then
                    printLine('database diagnostics are not available')
                else
                    printLine('Nitro_Framework database')
                    printLine(('  ready        : %s'):format(tostring(diagnostics.ready)))
                    printLine(('  server       : %s'):format(tostring(diagnostics.serverVersion or 'unknown')))
                    printLine(('  queries      : %d'):format(tonumber(diagnostics.queries) or 0))
                    printLine(('  errors       : %d'):format(tonumber(diagnostics.errors) or 0))
                    printLine(('  transactions : %d'):format(tonumber(diagnostics.transactions) or 0))
                    if diagnostics.lastError then
                        printLine(('  last error   : %s'):format(diagnostics.lastError))
                    end
                end
            else
                statusReport()
            end
            return
        end
        -- In game the command is only available to staff.
        if not Nitro.Core.Permissions.IsAdmin(source) then
            TriggerClientEvent('nitro:client:notification', source, {
                type = 'error',
                message = 'You do not have permission to use this command.',
            })
            return
        end
        statusReport()
    end, false)
end
