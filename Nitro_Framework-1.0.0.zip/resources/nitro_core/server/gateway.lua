--[[
    nitro_core :: server/gateway.lua

    Connection gate.

    Runs before a player is allowed into the server and checks the rules that
    are defined in the shared configuration:

        * the server can be closed temporarily
        * a whitelist can require a permission
        * the same Rockstar licence may only be connected once

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

Nitro.Core.Gateway = {}

local Gateway = Nitro.Core.Gateway

--- Connected licences, used to reject duplicate sessions.
local activeLicenses = {}

--- Read a shared configuration value.
--- @param path string
--- @param default any
--- @return any
local function sharedConfig(path, default)
    local ok, value = pcall(function()
        return exports.nitro_shared:GetConfig(path)
    end)
    if ok and value ~= nil then return value end
    return default
end

--- The licence of a connecting player.
--- @param src number
--- @return string?
local function getLicense(src)
    for _, identifier in ipairs(GetPlayerIdentifiers(src) or {}) do
        local prefix, value = identifier:match('^([^:]+):(.+)$')
        if prefix == 'license' or prefix == 'license2' then
            return value
        end
    end
    return nil
end

--- Check whether a licence is already connected.
--- @param license string
--- @return boolean
function Gateway.IsLicenseActive(license)
    return activeLicenses[license] == true
end

--- Register a licence as connected.
--- @param license string
function Gateway.AddLicense(license)
    if type(license) == 'string' and license ~= '' then
        activeLicenses[license] = true
    end
end

--- Remove a licence from the connected list.
--- @param license string
function Gateway.RemoveLicense(license)
    if type(license) == 'string' then
        activeLicenses[license] = nil
    end
end

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source

    deferrals.defer()
    Wait(0)

    local config = sharedConfig('Server', {})
    local license = getLicense(src)

    if config.Closed and not Nitro.Core.Permissions.Has(src, config.ClosedPermission or 'admin') then
        deferrals.done(('%s'):format(config.ClosedReason or 'The server is closed.'))
        return
    end

    if config.Whitelist and not Nitro.Core.Permissions.Has(src, config.WhitelistPermission or 'admin') then
        deferrals.done('This server is whitelisted and your account is not on the list.')
        return
    end

    if config.CheckDuplicateLicense and license and Gateway.IsLicenseActive(license) then
        deferrals.done('Your account is already connected to this server.')
        return
    end

    Gateway.AddLicense(license)
    deferrals.done()
end)

AddEventHandler('playerDropped', function()
    Gateway.RemoveLicense(getLicense(source))
end)
