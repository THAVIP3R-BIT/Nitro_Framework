--[[
    nitro_core :: client/callbacks.lua

    Client side half of the callback bridge.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

Nitro.Core.ClientCallbacks = {}

local registry = Nitro.Core.ClientCallbacks
local pending = {}

--- Register a callback the server can trigger.
--- @param name string
--- @param handler function(...)
--- @return boolean ok, string? reason
function Nitro.Core.RegisterClientCallback(name, handler)
    if type(name) ~= 'string' or name == '' then return false, 'invalid_name' end
    if type(handler) ~= 'function' then return false, 'invalid_handler' end
    registry[name] = handler
    return true
end

--- Remove a registered client callback.
--- @param name string
--- @return boolean
function Nitro.Core.RemoveClientCallback(name)
    if type(name) ~= 'string' then return false end
    registry[name] = nil
    return true
end

--- Ask the server to run a callback.
--- @param name string
--- @param callback function(ok, result)
--- @param ... any
--- @return string requestId
function Nitro.Core.TriggerCallback(name, callback, ...)
    local requestId = ('%d-%d'):format(GetGameTimer(), math.random(100000, 999999))
    local args = { ... }
    if type(callback) == 'function' then
        pending[requestId] = callback
    end
    TriggerServerEvent('nitro:net:req:callback', requestId, name, args)
    return requestId
end

--- Run a callback registered on this client.
--- @param requestId string
--- @param name string
--- @param args table
function Nitro.Core.RunClientCallback(requestId, name, args)
    local handler = registry[name]
    if not handler then
        TriggerServerEvent('nitro:net:res:clientCallback', requestId, false, 'unknown_callback')
        return
    end
    args = type(args) == 'table' and args or {}
    local packed = table.pack(pcall(handler, table.unpack(args)))
    local succeeded = packed[1]
    if not succeeded then
        print(('^1[nitro_core] client callback "%s" failed: %s^0'):format(name, tostring(packed[2])))
        TriggerServerEvent('nitro:net:res:clientCallback', requestId, false, 'callback_error')
        return
    end
    local results = table.pack(table.unpack(packed, 2, packed.n))
    TriggerServerEvent('nitro:net:res:clientCallback', requestId, true, table.unpack(results, 1, results.n))
end

RegisterNetEvent('nitro:net:res:callback', function(requestId, ok, ...)
    local callback = pending[requestId]
    if not callback then return end
    pending[requestId] = nil
    callback(ok == true, ...)
end)

RegisterNetEvent('nitro:net:req:clientCallback', function(requestId, name, args)
    if type(requestId) ~= 'string' or type(name) ~= 'string' then return end
    Nitro.Core.RunClientCallback(requestId, name, args)
end)
