--[[
    nitro_core :: client/client.lua

    Public client API of nitro_core.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

local playerData = {}
local permissions = {}
local loaded = false

--- @return string framework version
exports('GetVersion', function()
    return Nitro.GetVersionString()
end)

--- Ask the server to run one of its callbacks.
--- @param name string
--- @param callback function(ok, result)
--- @param ... any
--- @return string requestId
exports('TriggerCallback', function(name, callback, ...)
    return Nitro.Core.TriggerCallback(name, callback, ...)
end)

--- Register a callback the server is allowed to trigger.
--- @param name string
--- @param handler function(...)
--- @return boolean ok, string? reason
exports('RegisterClientCallback', function(name, handler)
    return Nitro.Core.RegisterClientCallback(name, handler)
end)

--- Check a permission locally. The server is always authoritative; this is a
--- convenience for hiding UI elements.
--- @param permission string
--- @return boolean
exports('HasPermission', function(permission)
    return permissions[permission] == true
end)

--- The session data the server pushed to this client.
--- @return table
exports('GetPlayerData', function()
    return playerData
end)

--- @return boolean
exports('IsPlayerLoaded', function()
    return loaded
end)

RegisterNetEvent('nitro:client:playerData', function(data)
    playerData = type(data) == 'table' and data or {}
    TriggerEvent('nitro:client:playerDataUpdated', playerData)
end)

RegisterNetEvent('nitro:client:playerLoaded', function(data)
    playerData = type(data) == 'table' and data or {}
    loaded = true
    TriggerEvent('nitro:client:playerLoaded', playerData)
end)

RegisterNetEvent('nitro:client:playerUnloaded', function()
    loaded = false
    playerData = {}
    TriggerEvent('nitro:client:playerUnloaded')
end)

RegisterNetEvent('nitro:client:permissions', function(list)
    permissions = type(list) == 'table' and list or {}
    TriggerEvent('nitro:client:permissionsUpdated', permissions)
end)

-- Ask the server for the initial permission set as soon as the session is
-- ready. The server pushes an update whenever the set changes.
CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(250) end
    Nitro.Core.TriggerCallback('nitro:core:getPermissions', function(ok, result)
        if ok and type(result) == 'table' then
            permissions = result
            TriggerEvent('nitro:client:permissionsUpdated', permissions)
        end
    end)
end)
