--[[
    nitro_core :: config.lua

    Core configuration. Settings that the whole framework agrees on live in
    nitro_shared/shared/config.lua and are read at runtime through
    exports.nitro_shared:GetConfig().

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Core = Nitro.Core or {}

Nitro.Core.Config = {
    -- Print a startup banner.
    StartupBanner = true,

    -- Ace permission groups that are considered "staff".
    -- A permission is mapped to the ace object "nitro.<permission>", so the
    -- group "admin" is granted with `add_ace group.admin nitro.admin allow`.
    AdminGroups = {
        admin = true,
        superadmin = true,
        moderator = true,
    },

    -- Register the server console commands (/nitro ...).
    Commands = true,

    -- Interval (milliseconds) used by the session heartbeat.
    -- The heartbeat only refreshes the "last seen" marker, it is not a save.
    Heartbeat = 300000,

    -- Amount of time (milliseconds) a player stays "loaded" after their
    -- session ended. Useful to avoid double-loading during reconnects.
    GracePeriod = 30000,
}
