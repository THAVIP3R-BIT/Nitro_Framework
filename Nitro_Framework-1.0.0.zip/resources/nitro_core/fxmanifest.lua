fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_core'
author 'Nitro_Framework'
description 'Nitro_Framework core: sessions, permissions, callbacks and the developer API.'
version '1.0.0'

shared_scripts {
    'config.lua',
    'shared/protocol.lua',
}

server_scripts {
    'server/permissions.lua',
    'server/callbacks.lua',
    'server/sessions.lua',
    'server/gateway.lua',
    'server/commands.lua',
    'server/server.lua',
}

client_scripts {
    'client/callbacks.lua',
    'client/client.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'

exports {
    'GetVersion',
    'IsPlayerLoaded',
    'GetPlayerData',
    'SetPlayerData',
    'ClearPlayerData',
    'GetPlayerIdentifiers',
    'GetOnlinePlayers',
    'HasPermission',
    'IsPlayerAdmin',
    'RegisterCallback',
    'CallCallback',
    'TriggerCallback',
    'TriggerClientCallback',
    'RegisterClientCallback',
    'GetPermissions',
    'GetDiagnostics',
}
