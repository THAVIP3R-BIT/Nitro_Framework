--[[
    nitro_core :: shared/protocol.lua

    The Nitro wire protocol. Every Nitro resource that talks to a client uses
    these event names so the traffic is predictable and greppable.

        client -> server   nitro:net:req:<name>
        server -> client   nitro:net:res:<name>
        server -> client   nitro:client:<name>
        server side hook   nitro:server:<name>

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Protocol = {}

--- Build the name of a client -> server request event.
--- @param name string
--- @return string
function Nitro.Protocol.Request(name)
    return ('nitro:net:req:%s'):format(tostring(name))
end

--- Build the name of a server -> client response event.
--- @param name string
--- @return string
function Nitro.Protocol.Response(name)
    return ('nitro:net:res:%s'):format(tostring(name))
end

--- Build the name of a server -> client push event.
--- @param name string
--- @return string
function Nitro.Protocol.Client(name)
    return ('nitro:client:%s'):format(tostring(name))
end

--- Build the name of a server side hook.
--- @param name string
--- @return string
function Nitro.Protocol.Server(name)
    return ('nitro:server:%s'):format(tostring(name))
end

--- The event used by the client -> server callback bridge.
Nitro.Protocol.CallbackEvent = 'nitro:net:req:callback'
--- The event used by the server -> client callback bridge.
Nitro.Protocol.CallbackResultEvent = 'nitro:net:res:callback'
