/* =============================================================================
   Nitro_Framework :: nitro.js

   The behaviour of the Nitro interface.

   Original Nitro_Framework work. Licensed GPL-3.0-or-later.
   ========================================================================== */

(function () {
    'use strict';

    const NUI = {
        post: (endpoint, data) =>
            fetch(`https://${GetParentResourceName()}/${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json; charset=UTF-8' },
                body: JSON.stringify(data || {}),
            }).then((response) => response.json()),
    };

    const state = {
        panel: null,
        characters: [],
        balances: { cash: 0, bank: 0 },
    };

    const panels = {
        characters: 'panel-characters',
        creator: 'panel-creator',
        inventory: 'panel-inventory',
        banking: 'panel-banking',
        admin: 'panel-admin',
    };

    /* ── Helpers ──────────────────────────────────────────────────────────── */

    const $ = (selector) => document.querySelector(selector);

    const formatMoney = (value) => `$${Number(value || 0).toLocaleString('en-US')}`;

    const formatWeight = (value) => `${Number(value || 0).toLocaleString('en-US')} g`;

    const escapeHtml = (value) =>
        String(value === null || value === undefined ? '' : value).replace(/[&<>"']/g, (character) => {
            const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
            return entities[character];
        });

    const setActivePanel = (name) => {
        Object.entries(panels).forEach(([key, id]) => {
            const element = document.getElementById(id);
            if (!element) return;
            element.classList.toggle('is-active', key === name);
        });
        document.body.classList.toggle('is-open', Boolean(name));
        state.panel = name || null;
    };

    /* ── Notifications ────────────────────────────────────────────────────── */

    const notify = (type, message, duration) => {
        const container = $('#notifications');
        if (!container) return;

        const element = document.createElement('div');
        element.className = `notification notification--${type || 'info'}`;
        element.innerHTML = `
            <div class="notification__title">${escapeHtml(type || 'info')}</div>
            <div class="notification__message">${escapeHtml(message)}</div>
            <div class="notification__progress"></div>
        `;
        container.appendChild(element);

        requestAnimationFrame(() => element.classList.add('is-visible'));

        const lifetime = Number(duration) > 0 ? Number(duration) : 5000;
        const progress = element.querySelector('.notification__progress');
        progress.animate([{ transform: 'scaleX(1)' }, { transform: 'scaleX(0)' }], {
            duration: lifetime,
            easing: 'linear',
        });

        window.setTimeout(() => {
            element.classList.remove('is-visible');
            window.setTimeout(() => element.remove(), 260);
        }, lifetime);
    };

    /* ── Character selection ──────────────────────────────────────────────── */

    const renderCharacters = (characters) => {
        const list = $('#character-list');
        if (!list) return;

        state.characters = Array.isArray(characters) ? characters : [];
        list.innerHTML = '';

        state.characters.forEach((character) => {
            const element = document.createElement('div');
            element.className = 'character';
            element.innerHTML = `
                <div class="character__name">${escapeHtml(character.firstName)} ${escapeHtml(character.lastName)}</div>
                <div class="character__meta">
                    ${escapeHtml(character.characterId)} &middot; ${escapeHtml(character.jobName || 'unemployed')}
                </div>
                <div class="character__actions">
                    <button class="button button--primary" data-select="${escapeHtml(character.characterId)}">Play</button>
                    <button class="button" data-delete="${escapeHtml(character.characterId)}">Delete</button>
                </div>
            `;
            list.appendChild(element);
        });
    };

    /* ── Inventory ────────────────────────────────────────────────────────── */

    const renderInventory = (items, weight, capacity) => {
        const list = $('#inventory-list');
        if (!list) return;

        list.innerHTML = '';
        (items || []).forEach((item) => {
            const element = document.createElement('div');
            element.className = 'item';
            element.innerHTML = `
                <div class="item__name">${escapeHtml(item.item)}</div>
                <div class="item__meta">
                    x${escapeHtml(item.amount)} &middot; slot ${escapeHtml(item.slot)}
                    ${item.serial ? ` &middot; ${escapeHtml(item.serial)}` : ''}
                </div>
            `;
            list.appendChild(element);
        });

        const label = $('#inventory-weight');
        if (label) label.textContent = `${formatWeight(weight)} / ${formatWeight(capacity)}`;

        const fill = $('#inventory-bar-fill');
        if (fill) {
            const ratio = capacity > 0 ? Math.min(100, (weight / capacity) * 100) : 0;
            fill.style.width = `${ratio}%`;
        }
    };

    /* ── Banking ──────────────────────────────────────────────────────────── */

    const renderBalances = (balances) => {
        state.balances = balances || { cash: 0, bank: 0 };
        const cash = $('#balance-cash');
        const bank = $('#balance-bank');
        if (cash) cash.textContent = formatMoney(state.balances.cash);
        if (bank) bank.textContent = formatMoney(state.balances.bank);
    };

    /* ── Admin log ────────────────────────────────────────────────────────── */

    const renderAdminLog = (entries) => {
        const body = $('#admin-log');
        if (!body) return;

        body.innerHTML = '';
        (entries || []).forEach((entry) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${escapeHtml(entry.created_at || '')}</td>
                <td>${escapeHtml(entry.actor_id || '-')}</td>
                <td>${escapeHtml(entry.action || '')}</td>
                <td>${escapeHtml(entry.target || '-')}</td>
            `;
            body.appendChild(row);
        });
    };

    /* ── Event wiring ─────────────────────────────────────────────────────── */

    document.addEventListener('click', (event) => {
        const target = event.target;

        if (target.dataset && target.dataset.action === 'close') {
            NUI.post('close');
            return;
        }

        if (target.dataset && target.dataset.select) {
            NUI.post('selectCharacter', { characterId: target.dataset.select });
            return;
        }

        if (target.dataset && target.dataset.delete) {
            NUI.post('deleteCharacter', { characterId: target.dataset.delete });
            return;
        }

        if (target.dataset && target.dataset.banking) {
            const action = target.dataset.banking;
            const amount = Number(($('#banking-amount') || {}).value || 0);
            const characterId = ($('#banking-target') || {}).value;

            if (action === 'transfer') {
                NUI.post('transfer', { target: characterId, amount, description: 'Transfer' });
            } else {
                NUI.post(action, { amount });
            }
        }
    });

    const creatorForm = $('#creator-form');
    if (creatorForm) {
        creatorForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const form = new FormData(creatorForm);
            NUI.post('createCharacter', {
                firstName: form.get('firstName'),
                lastName: form.get('lastName'),
                dateOfBirth: form.get('dateOfBirth'),
                gender: Number(form.get('gender') || 0),
                nationality: form.get('nationality'),
                phone: form.get('phone'),
            });
        });
    }

    const createButton = $('#create-character');
    if (createButton) {
        createButton.addEventListener('click', () => setActivePanel('creator'));
    }

    /* ── Messages from the game ───────────────────────────────────────────── */

    window.addEventListener('message', (event) => {
        const message = event.data || {};
        const data = message.data || {};

        switch (message.action) {
            case 'open':
                setActivePanel(data.panel);
                if (data.panel === 'characters') renderCharacters(data.data && data.data.characters);
                if (data.panel === 'admin') NUI.post('adminAction', {});
                break;
            case 'close':
                setActivePanel(null);
                break;
            case 'notify':
                notify(data.type, data.message, data.duration);
                break;
            case 'inventory':
                renderInventory(data.items, data.weight, data.capacity);
                break;
            case 'balances':
                renderBalances(data.balances);
                break;
            case 'adminLog':
                renderAdminLog(data.log);
                break;
            default:
                break;
        }
    });

    window.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            NUI.post('close');
        }
    });
})();
