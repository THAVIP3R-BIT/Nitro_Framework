fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_ui'
author 'Nitro_Framework'
description 'Nitro_Framework user interface: notifications, character selection, inventory and admin menu.'
version '1.0.0'

ui_page 'html/index.html'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client/ui.lua',
}

files {
    'html/index.html',
    'html/css/nitro.css',
    'html/js/nitro.js',
}

dependency 'nitro_shared'
dependency 'nitro_core'

exports {
    'Notify',
    'ShowError',
    'OpenCharacterSelector',
    'OpenCharacterCreator',
    'OpenInventory',
    'OpenBanking',
    'OpenAdminMenu',
    'Close',
    'IsOpen',
}
