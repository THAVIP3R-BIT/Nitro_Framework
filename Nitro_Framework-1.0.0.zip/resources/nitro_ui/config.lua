--[[
    nitro_ui :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.UI = Nitro.UI or {}

Nitro.UI.Config = {
    -- Panels that can be opened.
    Panels = {
        characters = true,
        creator = true,
        inventory = true,
        banking = true,
        admin = true,
    },

    -- Show a cursor while a panel is open.
    Cursor = true,

    -- The panels that keep the player frozen while they are open.
    FreezingPanels = {
        characters = true,
        creator = true,
    },
}
