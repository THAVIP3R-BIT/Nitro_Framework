--[[
    nitro_ui :: client/ui.lua

    The bridge between the game and the Nitro interface.

    Every panel is a section of the same NUI page. This file decides which
    section is visible, manages the focus and forwards the actions of the
    interface to the server.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.UI = Nitro.UI or {}

Nitro.UI.Client = {}

local Client = Nitro.UI.Client

local openPanel = nil
local lastFocus = nil

--- Send a message to the interface.
--- @param action string
--- @param data table?
local function send(action, data)
    SendNUIMessage({
        action = action,
        data = data or {},
    })
end

--- Open a panel.
--- @param panel string
--- @param data table?
function Client.Open(panel, data)
    if not Nitro.UI.Config.Panels[panel] then return end

    openPanel = panel
    lastFocus = NUIGetFocus()
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)

    if Nitro.UI.Config.Cursor then
        SetCursorPos(640.0, 360.0)
    end

    if Nitro.UI.Config.FreezingPanels[panel] then
        FreezeEntityPosition(PlayerPedId(), true)
    end

    send('open', { panel = panel, data = data or {} })
end

--- Close the interface.
function Client.Close()
    if not openPanel then return end
    openPanel = nil
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    FreezeEntityPosition(PlayerPedId(), false)
    send('close', {})
end

--- Show a notification.
--- @param kind string 'info' | 'success' | 'warning' | 'error'
--- @param message string
--- @param duration number?
function Client.Notify(kind, message, duration)
    send('notify', {
        type = kind or 'info',
        message = tostring(message),
        duration = duration,
    })
end

-- ── Events from other resources ──────────────────────────────────────────────

RegisterNetEvent('nitro:ui:notification', function(data)
    if type(data) == 'string' then
        Client.Notify('info', data)
        return
    end
    if type(data) ~= 'table' then return end
    Client.Notify(data.type, data.message, data.duration)
end)

RegisterNetEvent('nitro:ui:showError', function(data)
    if type(data) == 'string' then
        Client.Notify('error', data)
        return
    end
    if type(data) ~= 'table' then return end
    Client.Notify('error', data.message or 'Something went wrong.', data.duration)
end)

RegisterNetEvent('nitro:ui:openCharacterSelector', function(characters)
    Client.Open('characters', { characters = characters or {} })
end)

RegisterNetEvent('nitro:ui:openCharacterCreator', function()
    Client.Open('creator', {})
end)

RegisterNetEvent('nitro:ui:updateInventory', function(items, weight, capacity)
    send('inventory', { items = items or {}, weight = weight or 0, capacity = capacity or 0 })
end)

RegisterNetEvent('nitro:ui:updateBalances', function(balances)
    send('balances', { balances = balances or {} })
end)

RegisterNetEvent('nitro:ui:updateJob', function(job)
    send('job', { job = job or {} })
end)

RegisterNetEvent('nitro:ui:updateOrganisation', function(organisation)
    send('organisation', { organisation = organisation or {} })
end)

RegisterNetEvent('nitro:ui:updateProperties', function(properties)
    send('properties', { properties = properties or {} })
end)

RegisterNetEvent('nitro:ui:openAdminMenu', function()
    Client.Open('admin', {})
end)

-- ── NUI callbacks ───────────────────────────────────────────────────────────

RegisterNUICallback('close', function(data, cb)
    Client.Close()
    cb({ ok = true })
end)

RegisterNUICallback('ready', function(data, cb)
    Client.Close()
    cb({ ok = true })
end)

RegisterNUICallback('notify', function(data, cb)
    Client.Notify(data.type, data.message, data.duration)
    cb({ ok = true })
end)

RegisterNUICallback('selectCharacter', function(data, cb)
    Client.Close()
    TriggerEvent('nitro:client:characterSelected', data.characterId)
    cb({ ok = true })
end)

RegisterNUICallback('deleteCharacter', function(data, cb)
    exports.nitro_core:TriggerCallback('nitro:players:deleteCharacter', function(ok, reason)
        if not ok then
            Client.Notify('error', reason or 'The character could not be deleted.')
            return
        end
        Client.Notify('success', 'The character was deleted.')
        Client.Close()
    end, data.characterId)
    cb({ ok = true })
end)

RegisterNUICallback('createCharacter', function(data, cb)
    exports.nitro_core:TriggerCallback('nitro:players:createCharacter', function(ok, result, reason)
        if not ok then
            Client.Notify('error', reason or 'The character could not be created.')
            return
        end
        Client.Close()
        TriggerEvent('nitro:client:characterCreated', result and result.characterId)
    end, {
        firstName = data.firstName,
        lastName = data.lastName,
        dateOfBirth = data.dateOfBirth,
        gender = data.gender,
        nationality = data.nationality,
        phone = data.phone,
    })
    cb({ ok = true })
end)

RegisterNUICallback('useItem', function(data, cb)
    TriggerEvent('nitro:client:useItem', data.item, data.slot)
    cb({ ok = true })
end)

RegisterNUICallback('transfer', function(data, cb)
    exports.nitro_core:TriggerCallback('nitro:banking:transfer', function(ok, reason)
        if not ok then
            Client.Notify('error', reason or 'The transfer failed.')
            return
        end
        Client.Notify('success', 'The money was transferred.')
    end, data.target, tonumber(data.amount) or 0, data.description)
    cb({ ok = true })
end)

RegisterNUICallback('deposit', function(data, cb)
    exports.nitro_core:TriggerCallback('nitro:banking:deposit', function(ok, reason)
        if not ok then
            Client.Notify('error', reason or 'The deposit failed.')
            return
        end
        Client.Notify('success', 'The money was deposited.')
    end, tonumber(data.amount) or 0)
    cb({ ok = true })
end)

RegisterNUICallback('withdraw', function(data, cb)
    exports.nitro_core:TriggerCallback('nitro:banking:withdraw', function(ok, reason)
        if not ok then
            Client.Notify('error', reason or 'The withdrawal failed.')
            return
        end
        Client.Notify('success', 'The money was withdrawn.')
    end, tonumber(data.amount) or 0)
    cb({ ok = true })
end)

RegisterNUICallback('adminAction', function(data, cb)
    exports.nitro_core:TriggerCallback('nitro:admin:getLog', function(ok, log)
        if ok then
            send('adminLog', { log = log or {} })
        end
    end)
    cb({ ok = true })
end)

-- Close the interface when the player leaves the seat of the interface.
CreateThread(function()
    while true do
        Wait(500)
        if openPanel and not NUIGetFocus() then
            -- The player pressed the escape key, the NUI already hid itself.
            openPanel = nil
            FreezeEntityPosition(PlayerPedId(), false)
        end
    end
end)

-- ── Public client API ───────────────────────────────────────────────────────

--- Show a notification.
--- @param kind string
--- @param message string
--- @param duration number?
exports('Notify', function(kind, message, duration)
    Client.Notify(kind, message, duration)
end)

--- Show an error notification.
--- @param message string
exports('ShowError', function(message)
    Client.Notify('error', message)
end)

--- Open the character selection.
--- @param characters table[]
exports('OpenCharacterSelector', function(characters)
    Client.Open('characters', { characters = characters or {} })
end)

--- Open the character creator.
exports('OpenCharacterCreator', function()
    Client.Open('creator', {})
end)

--- Open the inventory.
exports('OpenInventory', function()
    Client.Open('inventory', {})
end)

--- Open the banking panel.
exports('OpenBanking', function()
    Client.Open('banking', {})
end)

--- Open the admin menu.
exports('OpenAdminMenu', function()
    Client.Open('admin', {})
end)

--- Close the interface.
exports('Close', function()
    Client.Close()
end)

--- Is a panel open?
--- @return boolean
exports('IsOpen', function()
    return openPanel ~= nil
end)
