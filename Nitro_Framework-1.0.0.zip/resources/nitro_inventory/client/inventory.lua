--[[
    nitro_inventory :: client/inventory.lua

    A small client side inventory view. The full grid is rendered by
    nitro_ui; this resource keeps the authoritative state on the client and
    forwards player actions to the server.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Inventory = Nitro.Inventory or {}

Nitro.Inventory.Client = {}

local Client = Nitro.Inventory.Client

local items = {}
local weight = 0
local capacity = Nitro.Inventory.Config.PlayerCapacity

--- Refresh the local inventory from the server.
function Client.Refresh()
    exports.nitro_core:TriggerCallback('nitro:inventory:getItems', function(ok, result)
        if not ok or type(result) ~= 'table' then return end
        items = result.items or {}
        weight = result.weight or 0
        capacity = result.capacity or capacity
        TriggerEvent('nitro:client:inventoryUpdated', items, weight, capacity)
        TriggerEvent('nitro:ui:updateInventory', items, weight, capacity)
    end)
end

RegisterNetEvent('nitro:client:inventoryUpdate', function()
    Client.Refresh()
end)

RegisterNetEvent('nitro:client:characterLoaded', function()
    if Nitro.Inventory.Config.SyncOnLoad then
        Client.Refresh()
    end
end)

RegisterNetEvent('nitro:client:characterUnloaded', function()
    items = {}
    weight = 0
end)

-- Ask the server to use an item.
RegisterNetEvent('nitro:client:useItem', function(item, slot)
    exports.nitro_core:TriggerCallback('nitro:inventory:useItem', function(ok, reason)
        if not ok then
            TriggerEvent('nitro:ui:showError', reason or 'The item could not be used.')
        end
    end, item, slot)
end)

--- The items of the player.
--- @return table[]
exports('GetItems', function()
    return items
end)

--- The current weight of the player.
--- @return number
exports('GetWeight', function()
    return weight
end)

--- Refresh the local copy of the inventory.
exports('Refresh', function()
    Client.Refresh()
end)
