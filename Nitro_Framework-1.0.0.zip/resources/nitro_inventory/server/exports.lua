--[[
    nitro_inventory :: server/exports.lua

    Public server API of nitro_inventory.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Inventory = Nitro.Inventory or {}

local Core = Nitro.Inventory.Core

--- Create the container of an owner.
--- @param ownerType string
--- @param ownerId string
--- @param label string?
--- @param capacity number?
--- @param slots number?
--- @return number? container id
exports('CreateInventory', function(ownerType, ownerId, label, capacity, slots)
    return Core.Create(ownerType, ownerId, label, capacity, slots)
end)

--- Delete the container of an owner.
--- @param ownerType string
--- @param ownerId string
--- @return boolean
exports('DeleteInventory', function(ownerType, ownerId)
    return Core.Delete(ownerType, ownerId)
end)

--- The container of an owner.
--- @param ownerType string
--- @param ownerId string
--- @return table?
exports('GetInventory', function(ownerType, ownerId)
    return Core.Get(ownerType, ownerId)
end)

--- Every item of a container.
--- @param ownerType string
--- @param ownerId string
--- @return table[]
exports('GetItems', function(ownerType, ownerId)
    return Core.GetItems(ownerType, ownerId)
end)

--- Add an item to a container.
--- @param ownerType string
--- @param ownerId string
--- @param item string
--- @param amount number?
--- @param metadata table?
--- @param slot number?
--- @return boolean ok, string? reason
exports('AddItem', function(ownerType, ownerId, item, amount, metadata, slot)
    return Core.Add(ownerType, ownerId, item, amount, metadata, slot)
end)

--- Remove an item from a container.
--- @param ownerType string
--- @param ownerId string
--- @param item string
--- @param amount number?
--- @param serial string?
--- @return boolean ok, string? reason
exports('RemoveItem', function(ownerType, ownerId, item, amount, serial)
    return Core.Remove(ownerType, ownerId, item, amount, serial)
end)

--- Check whether a container holds enough of an item.
--- @param ownerType string
--- @param ownerId string
--- @param item string
--- @param amount number?
--- @return boolean
exports('HasItem', function(ownerType, ownerId, item, amount)
    return Core.HasItem(ownerType, ownerId, item, amount)
end)

--- The amount of an item inside a container.
--- @param ownerType string
--- @param ownerId string
--- @param item string
--- @return number
exports('GetItemCount', function(ownerType, ownerId, item)
    return Core.GetItemCount(ownerType, ownerId, item)
end)

--- The total weight of a container, in grams.
--- @param ownerType string
--- @param ownerId string
--- @return number
exports('GetWeight', function(ownerType, ownerId)
    return Core.GetWeight(ownerType, ownerId)
end)

--- The lowest free slot of a container.
--- @param ownerType string
--- @param ownerId string
--- @return number?
exports('GetFreeSlot', function(ownerType, ownerId)
    local container = Core.Get(ownerType, ownerId)
    if not container then return nil end
    return Core.GetFreeSlot(container, Core.GetItems(ownerType, ownerId))
end)

--- Move an item from one container to another.
--- @param fromType string
--- @param fromId string
--- @param toType string
--- @param toId string
--- @param item string
--- @param amount number?
--- @param serial string?
--- @return boolean ok, string? reason
exports('TransferItem', function(fromType, fromId, toType, toId, item, amount, serial)
    return Core.Transfer(fromType, fromId, toType, toId, item, amount, serial)
end)

--- Use an item.
--- @param src number
--- @param item string
--- @param slot number
--- @return boolean ok, string? reason
exports('UseItem', function(src, item, slot)
    return Core.Use(src, item, slot)
end)

--- Replace the metadata of an item.
--- @param ownerType string
--- @param ownerId string
--- @param slot number
--- @param metadata table
--- @return boolean ok, string? reason
exports('SetItemMetadata', function(ownerType, ownerId, slot, metadata)
    return Core.SetMetadata(ownerType, ownerId, slot, metadata)
end)

-- ── Callbacks ────────────────────────────────────────────────────────────────

exports.nitro_core:RegisterCallback('nitro:inventory:getItems', function(src)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return {} end
    local items = Core.GetItems('character', data.characterId)
    local weight = 0
    for _, item in ipairs(items) do
        weight = weight + Core.GetItemWeight(item.item, item.amount)
        item.metadata = item.metadata and json.decode(item.metadata) or nil
    end
    return {
        items = items,
        weight = weight,
        capacity = (Core.Get('character', data.characterId) or {}).capacity or Nitro.Inventory.Config.PlayerCapacity,
    }
end)

exports.nitro_core:RegisterCallback('nitro:inventory:useItem', function(src, item, slot)
    local ok, reason = Core.Use(src, item, slot)
    if not ok then return false, reason end
    return true
end)
