--[[
    nitro_inventory :: server/inventory.lua

    Containers and items.

    A container is identified by an owner (a character, a vehicle, a property,
    an organisation or a stash id). Items are stored one row per stack.

    Rules
      * Weight and slot limits are always checked on the server.
      * Unique items (weapons, key cards) never stack and carry a serial.
      * Every mutation is a single statement so it either happens or it does
        not - there is no half written stack.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Inventory = Nitro.Inventory or {}

Nitro.Inventory.Core = {}

local Core = Nitro.Inventory.Core

--- Look an item definition up in the shared catalogue.
--- @param item string
--- @return table?
local function getItemDefinition(item)
    if type(item) ~= 'string' then return nil end
    local ok, definition = pcall(function()
        return exports.nitro_shared:GetItem(item)
    end)
    if not ok then return nil end
    return definition
end

--- Weight of an item in grams.
--- @param item string
--- @param amount number
--- @return number
function Core.GetItemWeight(item, amount)
    local definition = getItemDefinition(item)
    local weight = definition and tonumber(definition.weight) or 0
    return (weight or 0) * (tonumber(amount) or 1)
end

--- Create the container of an owner if it does not exist yet.
--- @param ownerType string
--- @param ownerId string
--- @param label string?
--- @param capacity number?
--- @param slots number?
--- @return number? container id
function Core.Create(ownerType, ownerId, label, capacity, slots)
    if type(ownerType) ~= 'string' or type(ownerId) ~= 'string' then return nil end

    local existing = exports.nitro_database:Single(
        'SELECT id FROM nitro_inventories WHERE owner_type = ? AND owner_id = ?',
        { ownerType, ownerId }
    )
    if existing then return existing.id end

    exports.nitro_database:Insert(
        'INSERT IGNORE INTO nitro_inventories (owner_type, owner_id, label, capacity, slots) VALUES (?, ?, ?, ?, ?)',
        {
            ownerType,
            ownerId,
            label or 'Container',
            capacity or Nitro.Inventory.Config.DefaultCapacity,
            slots or Nitro.Inventory.Config.DefaultSlots,
        }
    )

    local created = exports.nitro_database:Single(
        'SELECT id FROM nitro_inventories WHERE owner_type = ? AND owner_id = ?',
        { ownerType, ownerId }
    )
    return created and created.id or nil
end

--- The container of an owner.
--- @param ownerType string
--- @param ownerId string
--- @return table? container
function Core.Get(ownerType, ownerId)
    if type(ownerType) ~= 'string' or type(ownerId) ~= 'string' then return nil end
    return exports.nitro_database:Single(
        'SELECT * FROM nitro_inventories WHERE owner_type = ? AND owner_id = ?',
        { ownerType, ownerId }
    )
end

--- Delete the container of an owner.
--- @param ownerType string
--- @param ownerId string
--- @return boolean
function Core.Delete(ownerType, ownerId)
    local affected = exports.nitro_database:Update(
        'DELETE FROM nitro_inventories WHERE owner_type = ? AND owner_id = ?',
        { ownerType, ownerId }
    )
    return affected > 0
end

--- Every item of a container.
--- @param ownerType string
--- @param ownerId string
--- @return table[]
function Core.GetItems(ownerType, ownerId)
    local container = Core.Get(ownerType, ownerId)
    if not container then return {} end
    local rows = exports.nitro_database:Query(
        'SELECT * FROM nitro_inventory_items WHERE inventory_id = ? ORDER BY slot ASC, id ASC',
        { container.id }
    )
    return rows or {}
end

--- The lowest free slot of a container.
--- @param container table
--- @param items table[]
--- @return number?
function Core.GetFreeSlot(container, items)
    if type(container) ~= 'table' then return nil end
    local used = {}
    for _, item in ipairs(items or {}) do
        if item.slot then used[item.slot] = true end
    end
    for slot = 1, (container.slots or Nitro.Inventory.Config.DefaultSlots) do
        if not used[slot] then return slot end
    end
    return nil
end

--- Total weight of a container, in grams.
--- @param ownerType string
--- @param ownerId string
--- @return number
function Core.GetWeight(ownerType, ownerId)
    local total = 0
    for _, item in ipairs(Core.GetItems(ownerType, ownerId)) do
        total = total + Core.GetItemWeight(item.item, item.amount)
    end
    return total
end

--- The amount of an item inside a container.
--- @param ownerType string
--- @param ownerId string
--- @param item string
--- @return number
function Core.GetItemCount(ownerType, ownerId, item)
    local container = Core.Get(ownerType, ownerId)
    if not container then return 0 end
    local total = exports.nitro_database:Scalar(
        'SELECT COALESCE(SUM(amount), 0) FROM nitro_inventory_items WHERE inventory_id = ? AND item = ?',
        { container.id, item }
    )
    return tonumber(total) or 0
end

--- Check whether a container holds enough of an item.
--- @param ownerType string
--- @param ownerId string
--- @param item string
--- @param amount number?
--- @return boolean
function Core.HasItem(ownerType, ownerId, item, amount)
    return Core.GetItemCount(ownerType, ownerId, item) >= (tonumber(amount) or 1)
end

--- Should an item be stored as a unique row instead of a stack?
--- @param item string
--- @param metadata table?
--- @return boolean
local function isUniqueItem(item, metadata)
    if metadata and metadata.serial then return true end
    if Nitro.Inventory.Config.AlwaysStack[item] then return false end
    local definition = getItemDefinition(item)
    if not definition then return false end
    if definition.unique then return true end
    return Nitro.Inventory.Config.SerialisedTypes[definition.type] == true
end

--- Add an item to a container.
--- @param ownerType string
--- @param ownerId string
--- @param item string
--- @param amount number?
--- @param metadata table?
--- @param slot number?
--- @return boolean ok, string? reason
function Core.Add(ownerType, ownerId, item, amount, metadata, slot)
    if type(item) ~= 'string' or item == '' then return false, 'invalid_item' end
    amount = math.floor(tonumber(amount) or 1)
    if amount < 1 then return false, 'invalid_amount' end

    local definition = getItemDefinition(item)
    if not definition then return false, 'unknown_item' end

    local container = Core.Get(ownerType, ownerId)
    if not container then
        local created = Core.Create(ownerType, ownerId)
        if not created then return false, 'container_failed' end
        container = Core.Get(ownerType, ownerId)
    end

    local items = Core.GetItems(ownerType, ownerId)
    local currentWeight = 0
    for _, entry in ipairs(items) do
        currentWeight = currentWeight + Core.GetItemWeight(entry.item, entry.amount)
    end

    local addedWeight = Core.GetItemWeight(item, amount)
    if currentWeight + addedWeight > (container.capacity or Nitro.Inventory.Config.DefaultCapacity) then
        return false, 'too_heavy'
    end

    if not isUniqueItem(item, metadata) then
        -- Stack onto an existing row.
        local existing
        for _, entry in ipairs(items) do
            if entry.item == item and not entry.serial then
                existing = entry
                break
            end
        end
        if existing then
            exports.nitro_database:Update(
                'UPDATE nitro_inventory_items SET amount = amount + ? WHERE id = ?',
                { amount, existing.id }
            )
            Core.NotifyChange(ownerType, ownerId)
            return true, nil
        end
    end

    local targetSlot = slot
    if not targetSlot or targetSlot < 1 or targetSlot > (container.slots or Nitro.Inventory.Config.DefaultSlots) then
        targetSlot = Core.GetFreeSlot(container, items)
    end
    if not targetSlot then return false, 'no_free_slot' end

    local serial = nil
    if isUniqueItem(item, metadata) then
        serial = (metadata and metadata.serial) or ('%s-%d'):format(item, math.random(10000000, 99999999))
    end

    local metadataJson = nil
    if metadata and next(metadata) then metadataJson = json.encode(metadata) end

    local insertId = exports.nitro_database:Insert(
        'INSERT INTO nitro_inventory_items (inventory_id, item, amount, metadata, serial, slot) VALUES (?, ?, ?, ?, ?, ?)',
        { container.id, item, amount, metadataJson, serial, targetSlot }
    )
    if not insertId or insertId == 0 then return false, 'insert_failed' end

    Core.NotifyChange(ownerType, ownerId)
    return true, nil
end

--- Remove an item from a container.
--- @param ownerType string
--- @param ownerId string
--- @param item string
--- @param amount number?
--- @param serial string?
--- @return boolean ok, string? reason
function Core.Remove(ownerType, ownerId, item, amount, serial)
    if type(item) ~= 'string' or item == '' then return false, 'invalid_item' end
    amount = math.floor(tonumber(amount) or 1)
    if amount < 1 then return false, 'invalid_amount' end

    local container = Core.Get(ownerType, ownerId)
    if not container then return false, 'no_container' end

    if serial then
        local row = exports.nitro_database:Single(
            'SELECT * FROM nitro_inventory_items WHERE inventory_id = ? AND serial = ?',
            { container.id, serial }
        )
        if not row then return false, 'not_found' end
        if row.amount > amount then
            exports.nitro_database:Update(
                'UPDATE nitro_inventory_items SET amount = amount - ? WHERE id = ?',
                { amount, row.id }
            )
        else
            exports.nitro_database:Update(
                'DELETE FROM nitro_inventory_items WHERE id = ?',
                { row.id }
            )
        end
        Core.NotifyChange(ownerType, ownerId)
        return true, nil
    end

    local available = Core.GetItemCount(ownerType, ownerId, item)
    if available < amount then return false, 'not_enough_items' end

    local remaining = amount
    local rows = exports.nitro_database:Query(
        'SELECT * FROM nitro_inventory_items WHERE inventory_id = ? AND item = ? ORDER BY id ASC',
        { container.id, item }
    )
    for _, row in ipairs(rows or {}) do
        if remaining <= 0 then break end
        if row.amount <= remaining then
            exports.nitro_database:Update('DELETE FROM nitro_inventory_items WHERE id = ?', { row.id })
            remaining = remaining - row.amount
        else
            exports.nitro_database:Update(
                'UPDATE nitro_inventory_items SET amount = amount - ? WHERE id = ?',
                { remaining, row.id }
            )
            remaining = 0
        end
    end

    Core.NotifyChange(ownerType, ownerId)
    return true, nil
end

--- Move an item from one container to another.
--- @param fromType string
--- @param fromId string
--- @param toType string
--- @param toId string
--- @param item string
--- @param amount number?
--- @param serial string?
--- @return boolean ok, string? reason
function Core.Transfer(fromType, fromId, toType, toId, item, amount, serial)
    if fromType == toType and fromId == toId then return false, 'same_container' end
    amount = math.floor(tonumber(amount) or 1)

    local ok, reason = Core.Remove(fromType, fromId, item, amount, serial)
    if not ok then return false, reason end

    local metadata = nil
    if serial then
        local row = exports.nitro_database:Single(
            'SELECT metadata FROM nitro_inventory_items WHERE serial = ?',
            { serial }
        )
        if row and row.metadata then metadata = json.decode(row.metadata) end
    end

    local added, addReason = Core.Add(toType, toId, item, amount, metadata, nil)
    if not added then
        -- Put the item back so it is never lost.
        Core.Add(fromType, fromId, item, amount, metadata, nil)
        return false, addReason
    end

    return true, nil
end

--- Replace the metadata of an item.
--- @param ownerType string
--- @param ownerId string
--- @param slot number
--- @param metadata table
--- @return boolean ok, string? reason
function Core.SetMetadata(ownerType, ownerId, slot, metadata)
    if type(metadata) ~= 'table' then return false, 'invalid_metadata' end
    local container = Core.Get(ownerType, ownerId)
    if not container then return false, 'no_container' end
    local affected = exports.nitro_database:Update(
        'UPDATE nitro_inventory_items SET metadata = ? WHERE inventory_id = ? AND slot = ?',
        { json.encode(metadata), container.id, slot }
    )
    if affected == 0 then return false, 'not_found' end
    Core.NotifyChange(ownerType, ownerId)
    return true, nil
end

--- Tell the owner of a container that its contents changed.
--- @param ownerType string
--- @param ownerId string
function Core.NotifyChange(ownerType, ownerId)
    if not Nitro.Inventory.Config.NotifyOnChange then return end
    if ownerType ~= 'character' then return end
    local src = exports.nitro_players:GetSrcByCharacterId(ownerId)
    if not src then return end
    TriggerClientEvent('nitro:client:inventoryUpdate', src, {
        ownerType = ownerType,
        ownerId = ownerId,
        weight = Core.GetWeight(ownerType, ownerId),
    })
end

--- Use an item: fires the server side hook so other resources can react.
--- @param src number
--- @param item string
--- @param slot number
--- @return boolean ok, string? reason
function Core.Use(src, item, slot)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end

    local container = Core.Get('character', data.characterId)
    if not container then return false, 'no_container' end

    local row = exports.nitro_database:Single(
        'SELECT * FROM nitro_inventory_items WHERE inventory_id = ? AND slot = ?',
        { container.id, slot }
    )
    if not row then return false, 'not_found' end
    if row.item ~= item then return false, 'item_mismatch' end

    local handled = false
    TriggerEvent('nitro:server:itemUsed', src, row.item, row.amount, row.slot, row.metadata, row.serial)
    handled = true
    return handled, nil
end
