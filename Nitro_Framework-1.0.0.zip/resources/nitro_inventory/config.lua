--[[
    nitro_inventory :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Inventory = Nitro.Inventory or {}

Nitro.Inventory.Config = {
    -- Weight of a new container, in grams.
    DefaultCapacity = 50000,

    -- Amount of slots a new container gets.
    DefaultSlots = 50,

    -- Weight of a new player container.
    PlayerCapacity = 50000,
    PlayerSlots = 50,

    -- Items that always stack, even when they carry a serial number.
    AlwaysStack = {
        money = true,
    },

    -- Item types that receive a unique serial number when they are added.
    SerialisedTypes = {
        weapon = true,
        key = true,
        card = true,
    },

    -- Notify the client when the inventory changes.
    NotifyOnChange = true,

    -- Send the inventory to the client when the character loads.
    SyncOnLoad = true,
}
