fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_inventory'
author 'Nitro_Framework'
description 'Nitro_Framework containers, items, weight and serial numbers.'
version '1.0.0'

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/inventory.lua',
    'server/exports.lua',
}

client_scripts {
    'client/inventory.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'
dependency 'nitro_core'
dependency 'nitro_players'

exports {
    'CreateInventory',
    'DeleteInventory',
    'GetInventory',
    'GetItems',
    'AddItem',
    'RemoveItem',
    'HasItem',
    'GetItemCount',
    'GetWeight',
    'GetFreeSlot',
    'TransferItem',
    'UseItem',
    'SetItemMetadata',
    'Refresh',
}
