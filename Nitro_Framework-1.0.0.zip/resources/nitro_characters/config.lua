--[[
    nitro_characters :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Characters = Nitro.Characters or {}

Nitro.Characters.Config = {
    -- Allow a player to change the first and last name of their character.
    AllowNameChange = false,

    -- Minimum age a character must have.
    MinimumAge = 18,

    -- Profile fields a player is allowed to edit on their own.
    EditableFields = {
        'dateOfBirth',
        'gender',
        'nationality',
        'phone',
        'appearance',
        'notes',
    },

    -- Default appearance when a character has none yet.
    DefaultAppearance = {
        clothing = {
            component = {},
            drawable = {},
            texture = {},
        },
        tattoos = {},
        hair = {},
        accessories = {},
    },
}
