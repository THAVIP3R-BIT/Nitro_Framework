--[[
    nitro_characters :: server/exports.lua

    Public server API of nitro_characters.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Characters = Nitro.Characters or {}

local Profile = Nitro.Characters.Profile

--- The profile of the character a player is playing.
--- @param src number
--- @return table?
exports('GetProfile', function(src)
    return Profile.Get(src)
end)

--- Update the profile of the character a player is playing.
--- @param src number
--- @param changes table
--- @return boolean ok, table? profile, string? error
exports('UpdateProfile', function(src, changes)
    return Profile.Update(src, changes)
end)

--- The appearance of a character.
--- @param src number
--- @return table
exports('GetAppearance', function(src)
    return Profile.GetAppearance(src)
end)

--- Replace the appearance of a character.
--- @param src number
--- @param appearance table
--- @return boolean ok, string? error
exports('SetAppearance', function(src, appearance)
    return Profile.SetAppearance(src, appearance)
end)

--- Apply an appearance to a player (server side helper for the admin menu).
--- @param src number
--- @param appearance table
--- @return boolean
exports('ApplyAppearance', function(src, appearance)
    TriggerClientEvent('nitro:client:applyAppearance', src, appearance)
    return true
end)

exports.nitro_core:RegisterCallback('nitro:characters:getProfile', function(src)
    return Profile.Get(src) or {}
end)

exports.nitro_core:RegisterCallback('nitro:characters:updateProfile', function(src, changes)
    local ok, profile, err = Profile.Update(src, changes)
    if not ok then return false, err end
    return true, profile
end)
