--[[
    nitro_characters :: server/profile.lua

    The character profile: the identity fields of a character plus the
    appearance metadata that nitro_inventory and nitro_ui read.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Characters = Nitro.Characters or {}

Nitro.Characters.Profile = {}

local Profile = Nitro.Characters.Profile

--- The profile of the character a player is playing.
--- @param src number
--- @return table?
function Profile.Get(src)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return nil end
    return {
        characterId = data.characterId,
        firstName = data.firstName,
        lastName = data.lastName,
        dateOfBirth = data.dateOfBirth,
        gender = data.gender,
        nationality = data.nationality,
        phone = data.phone,
        metadata = data.metadata or {},
        appearance = (data.metadata or {}).appearance or Nitro.Characters.Config.DefaultAppearance,
    }
end

--- Age of a character in whole years.
--- @param dateOfBirth string?
--- @return number?
function Profile.GetAge(dateOfBirth)
    if type(dateOfBirth) ~= 'string' then return nil end
    local year, month, day = dateOfBirth:match('^(%d%d%d%d)%-(%d%d)%-(%d%d)$')
    if not year then return nil end
    year, month, day = tonumber(year), tonumber(month), tonumber(day)

    local now = os.date('*t')
    local age = now.year - year
    if now.month < month or (now.month == month and now.day < day) then
        age = age - 1
    end
    return age
end

--- Update the profile of the character a player is playing.
--- @param src number
--- @param changes table
--- @return boolean ok, table? profile, string? error
function Profile.Update(src, changes)
    if type(changes) ~= 'table' then return false, nil, 'invalid_data' end

    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, nil, 'no_character' end

    local Validation = Nitro.Players.Validation
    local update = {}
    local allowed = Nitro.Characters.Config.EditableFields

    for field, value in pairs(changes) do
        if not allowed[field] then
            -- Unknown fields are ignored instead of rejected so clients stay
            -- compatible with newer servers.
        elseif field == 'dateOfBirth' then
            local ok, parsed, err = Validation.ValidateDateOfBirth(value)
            if not ok then return false, nil, err end
            local age = Profile.GetAge(parsed)
            if age and age < Nitro.Characters.Config.MinimumAge then
                return false, nil, ('A character must be at least %d years old'):format(Nitro.Characters.Config.MinimumAge)
            end
            update.dateOfBirth = parsed
        elseif field == 'gender' then
            local ok, parsed, err = Validation.ValidateGender(value)
            if not ok then return false, nil, err end
            update.gender = parsed
        elseif field == 'nationality' then
            local ok, parsed, err = Validation.ValidateNationality(value)
            if not ok then return false, nil, err end
            update.nationality = parsed
        elseif field == 'phone' then
            local ok, parsed, err = Validation.ValidatePhone(value)
            if not ok then return false, nil, err end
            update.phone = parsed
        elseif field == 'appearance' or field == 'notes' then
            update[field] = value
        end
    end

    if next(update) == nil then return false, nil, 'nothing_to_update' end

    if update.dateOfBirth then
        exports.nitro_database:Update(
            'UPDATE nitro_characters SET date_of_birth = ? WHERE character_id = ?',
            { update.dateOfBirth, data.characterId }
        )
    end
    if update.gender then
        exports.nitro_database:Update(
            'UPDATE nitro_characters SET gender = ? WHERE character_id = ?',
            { update.gender, data.characterId }
        )
    end
    if update.nationality then
        exports.nitro_database:Update(
            'UPDATE nitro_characters SET nationality = ? WHERE character_id = ?',
            { update.nationality, data.characterId }
        )
    end
    if update.phone then
        exports.nitro_database:Update(
            'UPDATE nitro_characters SET phone = ? WHERE character_id = ?',
            { update.phone, data.characterId }
        )
    end

    -- Metadata (appearance, notes, ...) is stored as JSON on the character row.
    if update.appearance or update.notes then
        local metadata = data.metadata or {}
        if update.appearance then metadata.appearance = update.appearance end
        if update.notes then metadata.notes = update.notes end
        update.metadata = metadata
    end

    if update.metadata then
        exports.nitro_database:Update(
            'UPDATE nitro_characters SET metadata = ? WHERE character_id = ?',
            { json.encode(update.metadata), data.characterId }
        )
        exports.nitro_core:SetPlayerData(src, { metadata = update.metadata })
        data.metadata = update.metadata
    end

    -- Keep the live session in sync.
    for key, value in pairs(update) do
        if key ~= 'metadata' then
            data[key] = value
        end
    end
    exports.nitro_core:SetPlayerData(src, data)

    TriggerEvent('nitro:server:characterProfileUpdated', src, data)
    return true, Profile.Get(src), nil
end

--- The appearance of a character.
--- @param src number
--- @return table
function Profile.GetAppearance(src)
    local profile = Profile.Get(src)
    if not profile then return Nitro.Characters.Config.DefaultAppearance end
    return profile.appearance or Nitro.Characters.Config.DefaultAppearance
end

--- Replace the appearance of a character.
--- @param src number
--- @param appearance table
--- @return boolean ok, string? error
function Profile.SetAppearance(src, appearance)
    if type(appearance) ~= 'table' then return false, 'invalid_appearance' end
    local ok, _, err = Profile.Update(src, { appearance = appearance })
    if not ok then return false, err end
    return true, nil
end
