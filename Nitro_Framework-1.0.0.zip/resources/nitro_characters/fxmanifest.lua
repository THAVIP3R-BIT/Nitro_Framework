fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_characters'
author 'Nitro_Framework'
description 'Nitro_Framework character profile: identity, appearance and metadata.'
version '1.0.0'

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/profile.lua',
    'server/exports.lua',
}

client_scripts {
    'client/appearance.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'
dependency 'nitro_core'
dependency 'nitro_players'

exports {
    'GetProfile',
    'UpdateProfile',
    'GetAppearance',
    'SetAppearance',
    'ApplyAppearance',
}
