--[[
    nitro_characters :: client/appearance.lua

    Applies the appearance of a character to the local ped.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Characters = Nitro.Characters or {}

Nitro.Characters.Appearance = {}

local Appearance = Nitro.Characters.Appearance

--- Apply a clothing set to a ped.
--- @param ped number
--- @param clothing table
local function applyClothing(ped, clothing)
    if type(clothing) ~= 'table' then return end

    local components = clothing.component or {}
    local drawables = clothing.drawable or {}
    local textures = clothing.texture or {}

    for componentId = 0, 20 do
        if type(components[componentId]) == 'number' then
            local texture = textures[componentId]
            if type(texture) == 'number' then
                SetPedComponentVariation(ped, componentId, components[componentId], texture, 0)
            else
                SetPedComponentVariation(ped, componentId, components[componentId], 0, 0)
            end
        end
    end

    for propId = 0, 10 do
        if type(drawables[propId]) == 'number' then
            SetPedPropIndex(ped, propId, drawables[propId], textures[propId] or 0, true)
        end
    end
end

--- Apply a complete appearance definition.
--- @param appearance table
function Appearance.Apply(appearance)
    if type(appearance) ~= 'table' then return end
    local ped = PlayerPedId()
    if appearance.clothing then
        applyClothing(ped, appearance.clothing)
    end
    if type(appearance.model) == 'string' and appearance.model ~= '' then
        local hash = joaat(appearance.model)
        if hash and hash ~= 0 then
            SetPlayerModel(PlayerId(), hash)
            SetEntityCoords(ped, GetEntityCoords(ped), true, true)
        end
    end
    TriggerEvent('nitro:client:appearanceApplied', appearance)
end

RegisterNetEvent('nitro:client:applyAppearance', function(appearance)
    Appearance.Apply(appearance)
end)

RegisterNetEvent('nitro:client:characterLoaded', function(data)
    if type(data) ~= 'table' then return end
    local appearance = (data.metadata or {}).appearance
    if appearance then
        Appearance.Apply(appearance)
    end
end)

--- Apply an appearance locally.
--- @param appearance table
exports('ApplyAppearance', function(appearance)
    Appearance.Apply(appearance)
end)

--- The appearance of the character that is playing.
--- @return table
exports('GetAppearance', function()
    local data = exports.nitro_players:GetPlayerData()
    return (data and (data.metadata or {}).appearance) or Nitro.Characters.Config.DefaultAppearance
end)
