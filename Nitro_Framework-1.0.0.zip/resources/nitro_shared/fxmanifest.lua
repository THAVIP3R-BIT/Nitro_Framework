fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_shared'
author 'Nitro_Framework'
description 'Nitro_Framework shared configuration, localisation, catalogues and utility layer.'
version '1.0.0'

shared_scripts {
    'shared/init.lua',
    'shared/config.lua',
    'shared/utils.lua',
    'shared/logging.lua',
    'shared/data/items.lua',
    'shared/data/weapons.lua',
    'shared/data/vehicles.lua',
    'shared/data/locations.lua',
    'shared/data/jobs.lua',
    'shared/data/organisations.lua',
    'shared/locale.lua',
    'locale/*.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

exports {
    'GetShared',
    'GetSharedNamespace',
    'GetConfig',
    'GetVersion',
    'GetItem',
    'RegisterItem',
    'RemoveItem',
    'GetWeapon',
    'RegisterWeapon',
    'GetVehicle',
    'GetVehicleByModel',
    'GetVehicleHash',
    'RegisterVehicle',
    'GetJob',
    'RegisterJob',
    'RemoveJob',
    'GetOrganisation',
    'RegisterOrganisation',
    'RemoveOrganisation',
    'GetLocation',
    'RegisterLocation',
    'Round',
    'Trim',
    'Split',
    'RandomString',
    'RandomNumber',
    'DeepCopy',
    'IsFunction',
    'Sanitize',
    'Count',
    'Translate',
    'SetLocale',
    'GetLocale'
}
