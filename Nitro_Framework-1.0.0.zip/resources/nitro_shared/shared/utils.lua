--[[
    nitro_shared :: shared/utils.lua

    Pure-Lua helpers with no FiveM or database dependencies. Every function
    here is safe to call from both the client and the server and is unit
    tested in tests/specs/utils_spec.lua.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro.Utils = {}

local U = Nitro.Utils

-- ── Numbers ─────────────────────────────────────────────────────────────────

--- Round a number to a fixed number of decimals.
--- @param value number
--- @param decimals number? number of decimals (default 0)
--- @return number
function U.Round(value, decimals)
    local number = tonumber(value)
    if not number then return 0 end
    if not decimals then return math.floor(number + 0.5) end
    local power = 10 ^ decimals
    return math.floor((number * power) + 0.5) / power
end

--- Clamp a number between two bounds.
--- @param value number
--- @param minimum number
--- @param maximum number
--- @return number
function U.Clamp(value, minimum, maximum)
    local number = tonumber(value) or 0
    if number < minimum then return minimum end
    if number > maximum then return maximum end
    return number
end

-- ── Strings ─────────────────────────────────────────────────────────────────

--- Remove leading and trailing whitespace.
--- @param value string?
--- @return string?
function U.Trim(value)
    if type(value) ~= 'string' then return nil end
    return (value:gsub('^%s*(.-)%s*$', '%1'))
end

--- Split a string on a literal delimiter.
--- @param value string
--- @param delimiter string
--- @return string[]
function U.Split(value, delimiter)
    local result = {}
    if type(value) ~= 'string' then return result end
    delimiter = delimiter or ','
    local from = 1
    local delimFrom, delimTo = value:find(delimiter, from, true)
    while delimFrom do
        result[#result + 1] = value:sub(from, delimFrom - 1)
        from = delimTo + 1
        delimFrom, delimTo = value:find(delimiter, from, true)
    end
    result[#result + 1] = value:sub(from)
    return result
end

--- Uppercase the first character of a string.
--- @param value string?
--- @return string?
function U.Capitalise(value)
    if type(value) ~= 'string' then return nil end
    return (value:gsub('^%l', string.upper))
end

--- Strip characters that have no business being inside a display name.
--- Keeps letters, digits, spaces, dashes, apostrophes and underscores.
--- @param value string?
--- @return string?
function U.SanitiseName(value)
    if type(value) ~= 'string' then return nil end
    local cleaned = value:gsub('[^%w%s%-_\']', '')
    cleaned = U.Trim(cleaned)
    if #cleaned == 0 then return nil end
    return cleaned
end

--- Generic input sanitiser used before persisting client supplied strings.
--- Removes control characters, trims whitespace and truncates to maxLength.
--- @param value any
--- @param maxLength number?
--- @return string
function U.Sanitise(value, maxLength)
    if value == nil then return '' end
    if type(value) == 'number' then value = tostring(value) end
    if type(value) ~= 'string' then return '' end
    value = value:gsub('[%z\1-\31\127]', '')
    value = U.Trim(value)
    if maxLength and #value > maxLength then
        value = value:sub(1, maxLength)
    end
    return value
end

-- ── Randomness ──────────────────────────────────────────────────────────────

local STRING_CHARSET = {}
local NUMBER_CHARSET = {}
for i = 48, 57 do NUMBER_CHARSET[#NUMBER_CHARSET + 1] = string.char(i) end
for i = 65, 90 do STRING_CHARSET[#STRING_CHARSET + 1] = string.char(i) end
for i = 97, 122 do STRING_CHARSET[#STRING_CHARSET + 1] = string.char(i) end

--- Generate a random alphabetic string.
--- @param length number
--- @return string
function U.RandomString(length)
    length = tonumber(length) or 0
    if length <= 0 then return '' end
    local out = {}
    for i = 1, length do
        out[i] = STRING_CHARSET[math.random(1, #STRING_CHARSET)]
    end
    return table.concat(out)
end

--- Generate a random numeric string (never starts with a zero).
--- @param length number
--- @return string
function U.RandomNumber(length)
    length = tonumber(length) or 0
    if length <= 0 then return '' end
    local out = { tostring(math.random(1, 9)) }
    for i = 2, length do
        out[i] = NUMBER_CHARSET[math.random(1, #NUMBER_CHARSET)]
    end
    return table.concat(out)
end

-- ── Tables ──────────────────────────────────────────────────────────────────

--- Recursive copy of a table. Shared references are preserved inside the copy.
--- @param value any
--- @return any
function U.DeepCopy(value)
    if type(value) ~= 'table' then return value end
    local copy = {}
    for key, item in pairs(value) do
        copy[key] = U.DeepCopy(item)
    end
    return copy
end

--- Count the number of keys in a table.
--- @param value table?
--- @return number
function U.Count(value)
    if type(value) ~= 'table' then return 0 end
    local total = 0
    for _ in pairs(value) do total = total + 1 end
    return total
end

--- Deep merge `override` into a copy of `base`.
--- @param base table
--- @param override table?
--- @return table
function U.Merge(base, override)
    local result = U.DeepCopy(base) or {}
    if type(override) ~= 'table' then return result end
    for key, value in pairs(override) do
        if type(value) == 'table' and type(result[key]) == 'table' then
            result[key] = U.Merge(result[key], value)
        else
            result[key] = U.DeepCopy(value)
        end
    end
    return result
end

--- True when the value is callable (a Lua function or a CFX function reference).
--- @param value any
--- @return boolean
function U.IsFunction(value)
    if type(value) == 'function' then return true end
    if type(value) == 'table' then
        if rawget(value, '__cfx_functionReference') ~= nil then return true end
        local mt = getmetatable(value)
        if mt and type(mt.__call) == 'function' then return true end
    end
    return false
end

--- True when the value is a table with an array-like shape.
--- @param value any
--- @return boolean
function U.IsArray(value)
    if type(value) ~= 'table' then return false end
    return #value > 0 or next(value) == nil
end

-- ── Validation ──────────────────────────────────────────────────────────────

--- Validate a table against a simple schema description.
--- schema = { field = { type = 'string'|'number'|'boolean'|'table', required = bool } }
--- @param source table?
--- @param schema table
--- @return boolean ok, string[] errors
function U.Validate(source, schema)
    local errors = {}
    if type(source) ~= 'table' then
        return false, { 'expected a table' }
    end
    for field, rule in pairs(schema) do
        local value = source[field]
        if value == nil then
            if rule.required then
                errors[#errors + 1] = ('missing required field "%s"'):format(field)
            end
        else
            if rule.type and type(value) ~= rule.type then
                errors[#errors + 1] = ('field "%s" expected %s, got %s'):format(field, rule.type, type(value))
            end
            if rule.max and type(value) == 'string' and #value > rule.max then
                errors[#errors + 1] = ('field "%s" exceeds maximum length of %d'):format(field, rule.max)
            end
        end
    end
    if #errors > 0 then return false, errors end
    return true, errors
end

-- ── Vectors ─────────────────────────────────────────────────────────────────

--- Normalise anything vector-ish into { x = , y = , z = , w = }.
--- @param value any
--- @return table?
function U.ToVector4(value)
    if type(value) ~= 'table' then return nil end
    if value.x == nil or value.y == nil or value.z == nil then return nil end
    return {
        x = value.x + 0.0,
        y = value.y + 0.0,
        z = value.z + 0.0,
        w = (value.w or 0.0) + 0.0,
    }
end

--- Squared distance between two vector-ish tables (avoids sqrt).
--- @param a table
--- @param b table
--- @return number
function U.DistanceSquared(a, b)
    if type(a) ~= 'table' or type(b) ~= 'table' then return math.huge end
    local dx = (a.x or 0) - (b.x or 0)
    local dy = (a.y or 0) - (b.y or 0)
    local dz = (a.z or 0) - (b.z or 0)
    return dx * dx + dy * dy + dz * dz
end
