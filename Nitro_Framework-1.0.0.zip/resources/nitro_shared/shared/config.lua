--[[
    nitro_shared :: shared/config.lua

    Global, cross-cutting configuration for Nitro_Framework.

    Domain-specific configuration (characters, inventory, economy, ...) lives in
    the config.lua of the resource that owns that domain. This file only holds
    settings that more than one resource needs to agree on.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro.Config = {}

-- ─────────────────────────────────────────────────────────────────────────────
-- Server
-- ─────────────────────────────────────────────────────────────────────────────
Nitro.Config.Server = {
    -- Refuse all incoming connections.
    Closed = false,
    -- Reason shown to players who try to connect while the server is closed.
    ClosedReason = 'The server is temporarily closed.',
    -- Only allow players holding the permission below to connect.
    Whitelist = false,
    WhitelistPermission = 'admin',
    -- Permission required to connect while Closed is true.
    ClosedPermission = 'admin',
    -- Reject a second simultaneous session using the same Rockstar license.
    CheckDuplicateLicense = true,
    -- Discord invite appended to kick/exploit messages. Leave empty to omit.
    Discord = '',
    -- Name used in greetings.
    ServerName = 'Nitro Roleplay',
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Locale
-- ─────────────────────────────────────────────────────────────────────────────
Nitro.Config.Locale = {
    -- Active language. English ships with the framework.
    Default = 'en',
    -- Language used when a key is missing from the active language.
    Fallback = 'en',
    -- Print a console warning when a phrase key cannot be resolved.
    WarnOnMissing = true,
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Logging / diagnostics
-- ─────────────────────────────────────────────────────────────────────────────
Nitro.Config.Logging = {
    -- General framework logging.
    Debug = false,
    -- Log every SQL statement (contains parameter data - keep off in production).
    DatabaseDebug = false,
    -- Log permission checks that fail.
    PermissionDebug = false,
    -- Prefix used for every framework console line.
    Prefix = '[Nitro]',
    -- Minimum severity to print: 'debug' | 'info' | 'warn' | 'error'
    Level = 'info',
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Security
-- ─────────────────────────────────────────────────────────────────────────────
Nitro.Config.Security = {
    -- Rate limit (milliseconds) applied to sensitive client -> server requests.
    RateLimit = 750,
    -- Rate limit for monetary operations (milliseconds).
    MoneyRateLimit = 1500,
    -- Maximum length accepted for free-text fields.
    MaxStringLength = 64,
    -- Maximum length accepted for long free-text fields (descriptions etc).
    MaxTextLength = 512,
    -- Reject requests whose payload exceeds this many bytes.
    MaxPayloadBytes = 16384,
    -- Sanitise strings received from clients before they touch the database.
    SanitiseInput = true,
    -- Maximum number of characters a single account may own.
    MaxCharactersPerAccount = 5,
}

-- ─────────────────────────────────────────────────────────────────────────────
-- User interface theme (consumed by nitro_ui)
-- ─────────────────────────────────────────────────────────────────────────────
Nitro.Config.UI = {
    -- Global switch for the Nito UI. Individual resources respect it.
    Enabled = true,
    -- Theme name; nitro_ui ships with 'graphite' (dark graphite + nitro blue).
    Theme = 'graphite',
    -- Where notifications appear: top-left top-right bottom-left bottom-right
    -- top bottom left right center
    NotificationPosition = 'top-right',
    -- Show the drain bar on notifications.
    NotificationProgress = true,
    -- Default notification lifetime in milliseconds.
    NotificationDuration = 5000,
    -- Font stack used by the Nitro interface.
    FontPrimary = '"Rajdhani", "Exo 2", system-ui, sans-serif',
    FontMono = '"JetBrains Mono", "Consolas", monospace',
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Developer utilities
-- ─────────────────────────────────────────────────────────────────────────────
Nitro.Config.Developer = {
    -- Expose a server console command that dumps framework diagnostics.
    DiagnosticsCommand = true,
    -- Print a resource-by-resource health report 10 seconds after startup.
    StartupReport = true,
}
