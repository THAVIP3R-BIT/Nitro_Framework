--[[
    nitro_shared :: shared/locale.lua

    Nitro localisation runtime.

    Locale files live in `locale/<code>.lua` and register themselves through
    `Nitro.RegisterLocale(code, phrases)`. Adding a new language never requires
    a change to framework code.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro.LocaleFiles = Nitro.LocaleFiles or {}
Nitro.CurrentLocale = Nitro.CurrentLocale or (Nitro.Config and Nitro.Config.Locale.Default) or 'en'

--- @class NitroLocale
--- @field phrases table<string, string>
--- @field fallback NitroLocale?
--- @field warnOnMissing boolean
Nitro.Locale = {}
Nitro.Locale.__index = Nitro.Locale

--- Substitute `%{key}` placeholders inside a phrase.
--- @param phrase string
--- @param substitutions table<string, any>?
--- @return string
local function interpolate(phrase, substitutions)
    if type(phrase) ~= 'string' then return '' end
    if not substitutions then return phrase end
    local result = phrase
    for key, value in pairs(substitutions) do
        result = result:gsub('%%{' .. tostring(key) .. '}', tostring(value))
    end
    return result
end

--- Create a locale instance.
--- @param opts { phrases: table, fallback: NitroLocale?, warnOnMissing: boolean? }
--- @return NitroLocale
function Nitro.Locale.new(opts)
    opts = opts or {}
    local self = setmetatable({}, Nitro.Locale)
    self.phrases = {}
    self.warnOnMissing = opts.warnOnMissing ~= false
    self.fallback = opts.fallback
    self:extend(opts.phrases or {})
    return self
end

--- Recursively flatten a nested phrase table into dotted keys.
--- @param phrases table
--- @param prefix string?
function Nitro.Locale:extend(phrases, prefix)
    for key, value in pairs(phrases or {}) do
        local fullKey = prefix and ('%s.%s'):format(prefix, key) or key
        if type(value) == 'table' then
            self:extend(value, fullKey)
        else
            self.phrases[fullKey] = tostring(value)
        end
    end
end

--- Resolve a phrase.
--- @param key string
--- @param substitutions table<string, any>?
--- @return string
function Nitro.Locale:t(key, substitutions)
    if type(key) ~= 'string' then return '' end
    local phrase = self.phrases[key]
    if type(phrase) ~= 'string' then
        if self.warnOnMissing then
            print(('[Nitro] Missing phrase for key "%s" (locale: %s)'):format(key, tostring(self.code or 'unknown')))
        end
        if self.fallback then return self.fallback:t(key, substitutions) end
        return key
    end
    return interpolate(phrase, substitutions)
end

--- True when the key resolves inside this locale.
--- @param key string
--- @return boolean
function Nitro.Locale:has(key)
    return self.phrases[key] ~= nil
end

--- Register a locale file. Called by files inside `locale/`.
--- @param code string
--- @param phrases table
function Nitro.RegisterLocale(code, phrases)
    if type(code) ~= 'string' or code == '' then return false end
    Nitro.LocaleFiles[code] = Nitro.LocaleFiles[code] or phrases
    return true
end

--- Build the live locale object for a language code.
--- @param code string?
--- @return NitroLocale
function Nitro.BuildLocale(code)
    code = code or Nitro.CurrentLocale
    local fallbackCode = (Nitro.Config and Nitro.Config.Locale.Fallback) or 'en'
    local fallback = nil
    if Nitro.LocaleFiles[fallbackCode] and fallbackCode ~= code then
        fallback = Nitro.Locale.new({
            phrases = Nitro.LocaleFiles[fallbackCode],
            warnOnMissing = false,
        })
    end
    local locale = Nitro.Locale.new({
        phrases = Nitro.LocaleFiles[code] or {},
        fallback = fallback,
        warnOnMissing = (Nitro.Config and Nitro.Config.Locale.WarnOnMissing) ~= false,
    })
    locale.code = code
    return locale
end

--- Change the active language at runtime.
--- @param code string
--- @return boolean
function Nitro.SetLocale(code)
    if type(code) ~= 'string' or not Nitro.LocaleFiles[code] then return false end
    Nitro.CurrentLocale = code
    Nitro.ActiveLocale = Nitro.BuildLocale(code)
    return true
end

Nitro.ActiveLocale = Nitro.BuildLocale(Nitro.CurrentLocale)

--- Translate a phrase using the active locale.
--- @param key string
--- @param substitutions table<string, any>?
--- @return string
function Nitro.Translate(key, substitutions)
    return Nitro.ActiveLocale:t(key, substitutions)
end
