--[[
    nitro_shared :: shared/logging.lua

    Console logging helpers shared by every Nitro resource.

    Levels: debug | info | warn | error
    Output format: ^colour[Nitro][resource] message^0

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro.Log = {}

local LEVELS = { debug = 1, info = 2, warn = 3, error = 4 }
local COLOURS = {
    debug = '^5',
    info = '^2',
    warn = '^3',
    error = '^1',
}

--- @param level string
--- @return number
local function levelValue(level)
    return LEVELS[level] or LEVELS.info
end

--- Write a log line.
--- @param level string 'debug' | 'info' | 'warn' | 'error'
--- @param message string
--- @param resource string? overriding resource label
function Nitro.Log.write(level, message, resource)
    local config = Nitro.Config and Nitro.Config.Logging or {}
    local minLevel = levelValue(config.Level or 'info')
    if levelValue(level) < minLevel then return end
    if level == 'debug' and not config.Debug then return end

    resource = resource or GetCurrentResourceName()
    local colour = COLOURS[level] or '^7'
    print(('%s%s[%s][%s]^0 %s'):format(colour, tostring(config.Prefix or '[Nitro]'), resource, level:upper(), tostring(message)))
end

--- @param message string
function Nitro.Log.debug(message, resource)
    Nitro.Log.write('debug', message, resource)
end

--- @param message string
function Nitro.Log.info(message, resource)
    Nitro.Log.write('info', message, resource)
end

--- @param message string
function Nitro.Log.warn(message, resource)
    Nitro.Log.write('warn', message, resource)
end

--- @param message string
function Nitro.Log.error(message, resource)
    Nitro.Log.write('error', message, resource)
end

--- Print a structured table (used by the diagnostics command).
--- @param value any
--- @param indent number?
function Nitro.Log.dump(value, indent)
    indent = indent or 0
    if type(value) ~= 'table' then
        print(('%s%s'):format(string.rep('  ', indent), tostring(value)))
        return
    end
    for key, item in pairs(value) do
        if type(item) == 'table' then
            print(('%s^3%s:^0'):format(string.rep('  ', indent), tostring(key)))
            Nitro.Log.dump(item, indent + 1)
        else
            print(('%s^3%s:^0 ^7%t^0'):format(string.rep('  ', indent), tostring(key), item))
        end
    end
end
