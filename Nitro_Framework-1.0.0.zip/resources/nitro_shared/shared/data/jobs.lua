--[[
    nitro_shared :: shared/data/jobs.lua

    Nitro-native job catalogue.

    A job definition:
      label        - display name
      type         - free-form grouping used by resource logic ('leo', 'ems', ...)
      defaultDuty  - duty state applied when a character is loaded
      offDutyPay   - whether the grade is paid while off duty
      vehicle      - allowed vehicle classes/models for job vehicles
      grades       - map of grade level -> { name, payment, isboss, permissions }

    The grades are a *map* keyed by the grade level. Level 0 is the entry
    point of a job, the highest level is usually the boss. Read a grade
    safely with `exports['nitro_jobs']:GetGrade(job, level)`.

    Grade permissions are a list of dotted permission strings that server side
    resources check through `exports['nitro_jobs']:HasGradePermission`.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro.Shared.Jobs = {
    unemployed = {
        label = 'Civilian',
        type = 'none',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Freelancer', payment = 10, permissions = {} },
        },
    },

    taxi = {
        label = 'Los Santos Taxi',
        type = 'transport',
        defaultDuty = true,
        offDutyPay = false,
        vehicle = { 'taxi' },
        grades = {
            ['0'] = { name = 'Driver', payment = 45, permissions = {} },
            ['1'] = { name = 'Dispatcher', payment = 55, permissions = { 'job.taxi.dispatch' } },
            ['2'] = { name = 'Shift Lead', payment = 70, permissions = { 'job.taxi.dispatch' } },
            ['3'] = { name = 'Fleet Manager', payment = 95, isboss = true, permissions = { 'job.taxi.dispatch', 'job.taxi.manage' } },
        },
    },

    police = {
        label = 'San Andreas State Police',
        type = 'leo',
        defaultDuty = true,
        offDutyPay = false,
        vehicle = { 'police', 'sheriff', 'pranger', 'riot' },
        grades = {
            ['0'] = { name = 'Cadet', payment = 55, permissions = {} },
            ['1'] = { name = 'Officer', payment = 80, permissions = { 'job.police.cuff' } },
            ['2'] = { name = 'Detective', payment = 105, permissions = { 'job.police.cuff', 'job.police.search' } },
            ['3'] = { name = 'Sergeant', payment = 130, permissions = { 'job.police.cuff', 'job.police.search', 'job.police.impound' } },
            ['4'] = { name = 'Lieutenant', payment = 160, permissions = { 'job.police.cuff', 'job.police.search', 'job.police.impound', 'job.police.oversight' } },
            ['5'] = { name = 'Chief of Police', payment = 210, isboss = true, permissions = { 'job.police.cuff', 'job.police.search', 'job.police.impound', 'job.police.oversight', 'job.police.command' } },
        },
    },

    ambulance = {
        label = 'San Andreas Medical',
        type = 'ems',
        defaultDuty = true,
        offDutyPay = false,
        vehicle = { 'ambulance' },
        grades = {
            ['0'] = { name = 'Trainee', payment = 55, permissions = {} },
            ['1'] = { name = 'Paramedic', payment = 80, permissions = { 'job.ambulance.revive' } },
            ['2'] = { name = 'Field Medic', payment = 105, permissions = { 'job.ambulance.revive', 'job.ambulance.treat' } },
            ['3'] = { name = 'Trauma Specialist', payment = 135, permissions = { 'job.ambulance.revive', 'job.ambulance.treat', 'job.ambulance.transport' } },
            ['4'] = { name = 'Medical Director', payment = 180, isboss = true, permissions = { 'job.ambulance.revive', 'job.ambulance.treat', 'job.ambulance.transport', 'job.ambulance.command' } },
        },
    },

    mechanic = {
        label = 'LS Customs',
        type = 'mechanic',
        defaultDuty = true,
        offDutyPay = false,
        vehicle = { 'service' },
        grades = {
            ['0'] = { name = 'Apprentice', payment = 45, permissions = {} },
            ['1'] = { name = 'Technician', payment = 65, permissions = { 'job.mechanic.repair' } },
            ['2'] = { name = 'Custom Specialist', payment = 85, permissions = { 'job.mechanic.repair', 'job.mechanic.customise' } },
            ['3'] = { name = 'Shop Foreman', payment = 120, isboss = true, permissions = { 'job.mechanic.repair', 'job.mechanic.customise', 'job.mechanic.command' } },
        },
    },

    realestate = {
        label = 'Premier Realty',
        type = 'business',
        defaultDuty = true,
        offDutyPay = false,
        grades = {
            ['0'] = { name = 'Receptionist', payment = 45, permissions = {} },
            ['1'] = { name = 'Sales Agent', payment = 65, permissions = { 'job.realestate.viewing' } },
            ['2'] = { name = 'Broker', payment = 90, permissions = { 'job.realestate.viewing', 'job.realestate.negotiate' } },
            ['3'] = { name = 'Managing Broker', payment = 130, isboss = true, permissions = { 'job.realestate.viewing', 'job.realestate.negotiate', 'job.realestate.command' } },
        },
    },

    tow = {
        label = 'Los Santos Towing',
        type = 'service',
        defaultDuty = true,
        offDutyPay = false,
        vehicle = { 'tow' },
        grades = {
            ['0'] = { name = 'Recovery Driver', payment = 45, permissions = {} },
            ['1'] = { name = 'Tow Operator', payment = 60, permissions = { 'job.tow.recover' } },
            ['2'] = { name = 'Yard Manager', payment = 90, isboss = true, permissions = { 'job.tow.recover', 'job.tow.command' } },
        },
    },
}

-- Job types are used to group similar roles (e.g. all LEO jobs).
Nitro.Shared.JobTypes = {
    none = 'Civilian',
    leo = 'Law Enforcement',
    ems = 'Emergency Medical',
    mechanic = 'Automotive',
    business = 'Business',
    transport = 'Transport',
    service = 'Public Service',
}
