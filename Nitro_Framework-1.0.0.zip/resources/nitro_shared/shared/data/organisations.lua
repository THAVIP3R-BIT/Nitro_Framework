--[[
    nitro_shared :: shared/data/organisations.lua

    Nitro-native organisation catalogue.

    Organisations are the Nitro successor to the legacy "gang" concept but are
    deliberately neutral: criminal crews, street gangs, militias, crews and
    unions all live in the same registry.

    An organisation definition:
      label    - display name
      type     - free-form grouping ('crew', 'street', 'militia', 'union')
      shared   - whether the organisation owns a shared account and stash
      grades   - map of rank level -> { name, isboss, permissions }

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro.Shared.Organisations = {
    none = {
        label = 'No Affiliation',
        type = 'none',
        shared = false,
        grades = {
            ['0'] = { name = 'Unaffiliated', permissions = {} },
        },
    },

    ballas = {
        label = 'Ballas',
        type = 'street',
        shared = true,
        grades = {
            ['0'] = { name = 'Runner', permissions = {} },
            ['1'] = { name = 'Soldier', permissions = { 'org.ballas.gunlocker' } },
            ['2'] = { name = 'Shot Caller', permissions = { 'org.ballas.gunlocker', 'org.ballas.vehicles' } },
            ['3'] = { name = 'Lieutenant', permissions = { 'org.ballas.gunlocker', 'org.ballas.vehicles', 'org.ballas.stash' } },
            ['4'] = { name = 'Boss', isboss = true, permissions = { 'org.ballas.gunlocker', 'org.ballas.vehicles', 'org.ballas.stash', 'org.ballas.command' } },
        },
    },

    vespucci = {
        label = 'Vespucci Sharks',
        type = 'street',
        shared = true,
        grades = {
            ['0'] = { name = 'Runner', permissions = {} },
            ['1'] = { name = 'Soldier', permissions = { 'org.vespucci.gunlocker' } },
            ['2'] = { name = 'Shot Caller', permissions = { 'org.vespucci.gunlocker', 'org.vespucci.vehicles' } },
            ['3'] = { name = 'Lieutenant', permissions = { 'org.vespucci.gunlocker', 'org.vespucci.vehicles', 'org.vespucci.stash' } },
            ['4'] = { name = 'Boss', isboss = true, permissions = { 'org.vespucci.gunlocker', 'org.vespucci.vehicles', 'org.vespucci.stash', 'org.vespucci.command' } },
        },
    },

    sentinel = {
        label = 'Sentinel Collective',
        type = 'crew',
        shared = true,
        grades = {
            ['0'] = { name = 'Associate', permissions = {} },
            ['1'] = { name = 'Specialist', permissions = { 'org.sentinel.gunlocker' } },
            ['2'] = { name = 'Director', permissions = { 'org.sentinel.gunlocker', 'org.sentinel.vehicles', 'org.sentinel.stash' } },
            ['3'] = { name = 'Principal', isboss = true, permissions = { 'org.sentinel.gunlocker', 'org.sentinel.vehicles', 'org.sentinel.stash', 'org.sentinel.command' } },
        },
    },

    ironworks = {
        label = 'Ironworks Industrial Union',
        type = 'union',
        shared = true,
        grades = {
            ['0'] = { name = 'Member', permissions = {} },
            ['1'] = { name = 'Steward', permissions = { 'org.ironworks.stash' } },
            ['2'] = { name = 'Foreman', permissions = { 'org.ironworks.stash', 'org.ironworks.vehicles' } },
            ['3'] = { name = 'Chairperson', isboss = true, permissions = { 'org.ironworks.stash', 'org.ironworks.vehicles', 'org.ironworks.command' } },
        },
    },
}

Nitro.Shared.OrganisationTypes = {
    none = 'Unaffiliated',
    street = 'Street Crew',
    crew = 'Organisation',
    militia = 'Militia',
    union = 'Union',
}
