--[[
    nitro_shared :: shared/init.lua

    Establishes the Nitro namespace inside the nitro_shared resource.

    IMPORTANT: FiveM gives every resource its own Lua VM. Globals defined here
    are *not* visible to other resources. Other resources must use the public
    exports declared in fxmanifest.lua (or the `Nitro` helper injected by
    `exports['nitro_shared']:GetShared()`).

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro = Nitro or {}

Nitro.Name = 'Nitro_Framework'
Nitro.Tag = 'NITRO'

Nitro.Version = {
    major = 1,
    minor = 0,
    patch = 0,
    label = '1.0.0',
    codename = 'Ignition'
}

--- Human readable version string, e.g. "1.0.0"
--- @return string
function Nitro.GetVersionString()
    return ('%d.%d.%d'):format(Nitro.Version.major, Nitro.Version.minor, Nitro.Version.patch)
end

--- Shared catalogues live here. Keys are stable and documented in
--- docs/api-reference.md.
Nitro.Shared = {
    Items = {},
    Weapons = {},
    Vehicles = {},
    VehicleHashes = {},
    Locations = {},
    Jobs = {},
    Organisations = {},
}

--- Namespaces that are allowed to be requested through GetSharedNamespace.
Nitro.SharedNamespaces = {
    Items = true,
    Weapons = true,
    Vehicles = true,
    VehicleHashes = true,
    Locations = true,
    Jobs = true,
    Organisations = true,
}
