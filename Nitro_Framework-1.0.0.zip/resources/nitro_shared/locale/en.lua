--[[
    nitro_shared :: locale/en.lua

    English phrase catalogue - the Nitro_Framework reference language.

    To add a language: copy this file to `locale/<code>.lua`, translate the
    values, change the registration code at the bottom, and add the code to
    `Nitro.Config.Locale.Default` in shared/config.lua. No framework code has
    to change.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro.RegisterLocale('en', {
    error = {
        not_online = 'Player is not online.',
        wrong_format = 'Incorrect format.',
        missing_args = 'Not every required argument was supplied.',
        missing_args2 = 'All arguments must be filled out.',
        no_access = 'You do not have access to that command.',
        no_permission = 'You do not have permission to do that.',
        item_not_exist = 'That item does not exist.',
        too_heavy = 'The container cannot hold that much weight.',
        location_not_exist = 'That location does not exist.',
        duplicate_license = '[Nitro] A session with this Rockstar license is already active.',
        no_valid_license = '[Nitro] No valid Rockstar license was found.',
        not_whitelisted = '[Nitro] You are not whitelisted for this server.',
        server_closed = '[Nitro] The server is currently closed.',
        server_already_open = 'The server is already open.',
        server_already_closed = 'The server is already closed.',
        character_not_found = 'Character not found.',
        character_exists = 'A character with that identity already exists.',
        character_limit = 'You have reached the maximum number of characters.',
        character_protected = 'This character cannot be deleted.',
        insufficient_funds = 'Insufficient funds.',
        invalid_amount = 'Invalid amount.',
        invalid_plate = 'Invalid plate.',
        invalid_input = 'Invalid input.',
        not_owner = 'You do not own that.',
        storage_full = 'The storage is full.',
        rate_limited = 'You are doing that too often.',
        database_error = 'A database error occurred, the operation was cancelled.',
        migration_failed = 'The database migration failed. Check the server console.',
        dependency_missing = 'A required dependency is missing.',
        inventory_full = 'Your inventory is full.',
        organisation_not_found = 'Organisation not found.',
        job_not_found = 'Job not found.',
        vehicle_not_found = 'Vehicle not found.',
        property_not_found = 'Property not found.',
        transaction_failed = 'The transaction could not be completed.',
        already_exists = 'That already exists.',
        grade_not_found = 'That grade does not exist.',
        unknown = 'An unknown error occurred.',
    },
    success = {
        server_opened = 'The server is now open.',
        server_closed = 'The server is now closed.',
        teleported_waypoint = 'Teleported to your waypoint.',
        character_created = 'Character created.',
        character_deleted = 'Character deleted.',
        character_selected = 'Character loaded.',
        item_added = 'Item added.',
        item_removed = 'Item removed.',
        money_added = 'Funds added.',
        money_removed = 'Funds removed.',
        transfer_complete = 'Transfer complete.',
        job_set = 'Job updated.',
        organisation_set = 'Organisation updated.',
        hired = 'Player hired.',
        fired = 'Player dismissed.',
        promoted = 'Player promoted.',
        demoted = 'Player demoted.',
        vehicle_created = 'Vehicle created.',
        vehicle_deleted = 'Vehicle deleted.',
        property_registered = 'Property registered.',
        saved = 'Saved.',
        notified = 'Notification sent.',
    },
    info = {
        received_paycheck = 'You received a paycheck of $%{value}.',
        job_info = 'Job: %{value} | Grade: %{value2} | Duty: %{value3}',
        organisation_info = 'Organisation: %{value} | Rank: %{value2}',
        on_duty = 'You are now on duty.',
        off_duty = 'You are now off duty.',
        checking_ban = 'Checking ban status...',
        join_server = 'Welcome to %{server}.',
        checking_whitelisted = 'Checking your whitelist status...',
        exploit_banned = 'You have been banned for cheating.',
        exploit_dropped = 'You were disconnected for exploiting the framework.',
        character_selection = 'Select a character.',
        loading_character = 'Loading %{value}...',
        character_saved = 'Your character was saved.',
        permissions_updated = 'Your permissions were updated.',
    },
    command = {
        tp = {
            help = 'Teleport to a player or coordinates.',
            params = {
                x = { name = 'id/x', help = 'Player id or X coordinate' },
                y = { name = 'y', help = 'Y coordinate' },
                z = { name = 'z', help = 'Z coordinate' },
            },
        },
        tpm = { help = 'Teleport to your waypoint.' },
        togglepvp = { help = 'Toggle PvP for the server.' },
        addpermission = {
            help = 'Grant a permission group to a player.',
            params = {
                id = { name = 'id', help = 'Player id' },
                permission = { name = 'permission', help = 'Permission group' },
            },
        },
        removepermission = {
            help = 'Revoke a permission group from a player.',
            params = {
                id = { name = 'id', help = 'Player id' },
                permission = { name = 'permission', help = 'Permission group' },
            },
        },
        openserver = { help = 'Open the server to everyone.' },
        closeserver = {
            help = 'Close the server to players without permissions.',
            params = {
                reason = { name = 'reason', help = 'Reason (optional)' },
            },
        },
        car = {
            help = 'Spawn a vehicle.',
            params = {
                model = { name = 'model', help = 'Vehicle model name' },
            },
        },
        dv = { help = 'Delete the vehicle you are using.' },
        dvall = { help = 'Delete every vehicle in the world.' },
        dvp = { help = 'Delete every ped in the world.' },
        dvo = { help = 'Delete every object in the world.' },
        givemoney = {
            help = 'Give a player money.',
            params = {
                id = { name = 'id', help = 'Player id' },
                account = { name = 'account', help = 'Account (cash, bank)' },
                amount = { name = 'amount', help = 'Amount' },
            },
        },
        setmoney = {
            help = 'Set a player balance.',
            params = {
                id = { name = 'id', help = 'Player id' },
                account = { name = 'account', help = 'Account (cash, bank)' },
                amount = { name = 'amount', help = 'Amount' },
            },
        },
        job = { help = 'Show your current job.' },
        setjob = {
            help = 'Set a player job.',
            params = {
                id = { name = 'id', help = 'Player id' },
                job = { name = 'job', help = 'Job name' },
                grade = { name = 'grade', help = 'Grade level' },
            },
        },
        organisation = { help = 'Show your current organisation.' },
        setorganisation = {
            help = 'Set a player organisation.',
            params = {
                id = { name = 'id', help = 'Player id' },
                organisation = { name = 'organisation', help = 'Organisation name' },
                grade = { name = 'grade', help = 'Rank level' },
            },
        },
        ooc = { help = 'Send an out of character message.' },
        me = {
            help = 'Show a message above your head.',
            params = {
                message = { name = 'message', help = 'Message to show' },
            },
        },
        nitro = { help = 'Show framework information.' },
        nitrohealth = { help = 'Show the framework health report.' },
        characters = { help = 'List the characters of a player id.' },
        delcharacter = {
            help = 'Delete a character.',
            params = {
                id = { name = 'id', help = 'Character id' },
            },
        },
    },
    admin = {
        announcement = '**ANNOUNCEMENT** %{message}',
        player_lookup = '**%{name}** | Id: %{id} | Licence: %{license}',
        target_not_found = 'No player matched that search.',
        banned = 'The player was banned.',
        unbanned = 'The ban was lifted.',
        no_reason = 'No reason supplied.',
    },
    ui = {
        character_select_title = 'Select Character',
        character_select_subtitle = 'Choose the identity you want to step into.',
        character_create_title = 'New Character',
        character_create_subtitle = 'Build the identity you want to play.',
        character_name_label = 'Full name',
        character_dob_label = 'Date of birth',
        character_nationality_label = 'Nationality',
        character_gender_label = 'Gender',
        character_confirm = 'Confirm',
        character_cancel = 'Cancel',
        character_delete = 'Delete',
        character_play = 'Play',
        inventory_title = 'Inventory',
        inventory_weight = 'Weight',
        inventory_empty = 'Nothing here.',
        admin_title = 'Administration',
        input_title = 'Input',
        input_confirm = 'Confirm',
        input_cancel = 'Cancel',
        menu_empty = 'No options available.',
        progress_title = 'Working...',
    },
})
