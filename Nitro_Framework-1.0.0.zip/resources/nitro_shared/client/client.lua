--[[
    nitro_shared :: client/client.lua

    Client side public API for nitro_shared.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

-- ── Shared catalogue synchronisation ─────────────────────────────────────────

RegisterNetEvent('nitro:client:sharedUpdate', function(namespace, key, value)
    if type(namespace) ~= 'string' then return end
    local target = Nitro.Shared[namespace]
    if type(target) ~= 'table' then return end
    target[key] = value
    TriggerEvent('nitro:client:sharedUpdated', namespace, key, value)
end)

-- ── Data access ─────────────────────────────────────────────────────────────

exports('GetShared', function()
    return Nitro.Shared
end)

exports('GetSharedNamespace', function(namespace, key)
    if type(namespace) ~= 'string' then return nil end
    if not Nitro.SharedNamespaces[namespace] then return nil end
    local data = Nitro.Shared[namespace]
    if not data then return nil end
    if key == nil then return data end
    return data[key]
end)

exports('GetConfig', function(path)
    if path == nil then return Nitro.Config end
    local current = Nitro.Config
    for part in tostring(path):gmatch('[^.]+') do
        if type(current) ~= 'table' then return nil end
        current = current[part]
    end
    return current
end)

exports('GetVersion', function()
    return Nitro.GetVersionString()
end)

exports('GetItem', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Items[name]
end)

exports('GetWeapon', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Weapons[name] or Nitro.Shared.Weapons[joaat(name)]
end)

exports('GetVehicle', function(model)
    if type(model) ~= 'string' then return nil end
    return Nitro.Shared.Vehicles[model]
end)

exports('GetVehicleByModel', function(model)
    if type(model) ~= 'string' then return nil end
    return Nitro.Shared.Vehicles[model]
end)

exports('GetVehicleHash', function(hash)
    if hash == nil then return nil end
    return Nitro.Shared.VehicleHashes[tonumber(hash)]
end)

exports('GetJob', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Jobs[name]
end)

exports('GetOrganisation', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Organisations[name]
end)

exports('GetLocation', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Locations[name]
end)

-- ── Utilities ───────────────────────────────────────────────────────────────

exports('Round', function(value, decimals) return Nitro.Utils.Round(value, decimals) end)
exports('Trim', function(value) return Nitro.Utils.Trim(value) end)
exports('Split', function(value, delimiter) return Nitro.Utils.Split(value, delimiter) end)
exports('RandomString', function(length) return Nitro.Utils.RandomString(length) end)
exports('RandomNumber', function(length) return Nitro.Utils.RandomNumber(length) end)
exports('DeepCopy', function(value) return Nitro.Utils.DeepCopy(value) end)
exports('IsFunction', function(value) return Nitro.Utils.IsFunction(value) end)
exports('Sanitize', function(value, maxLength) return Nitro.Utils.Sanitise(value, maxLength) end)
exports('Count', function(value) return Nitro.Utils.Count(value) end)

-- ── Localisation ────────────────────────────────────────────────────────────

exports('Translate', function(key, substitutions)
    return Nitro.Translate(key, substitutions)
end)

exports('SetLocale', function(code)
    return Nitro.SetLocale(code)
end)

exports('GetLocale', function()
    return Nitro.CurrentLocale
end)
