--[[
    nitro_shared :: server/server.lua

    Server side public API for nitro_shared.

    Every export declared here is part of the Nitro_Framework developer API and
    is documented in docs/api-reference.md.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

local resourceName = GetCurrentResourceName()

-- ── Internal helpers ────────────────────────────────────────────────────────

--- Push a shared catalogue change to every connected client.
--- @param namespace string
--- @param key string
--- @param value any
local function broadcastUpdate(namespace, key, value)
    TriggerClientEvent('nitro:client:sharedUpdate', -1, namespace, key, value)
    TriggerEvent('nitro:server:sharedUpdate', namespace, key, value)
end

--- Resolve a dotted configuration path.
--- @param source table
--- @param path string
--- @return any
local function resolvePath(source, path)
    if type(path) ~= 'string' or path == '' then return source end
    local current = source
    for part in path:gmatch('[^.]+') do
        if type(current) ~= 'table' then return nil end
        current = current[part]
    end
    return current
end

-- ── Data access ─────────────────────────────────────────────────────────────

--- Return the whole shared catalogue table.
--- The returned table is live: registering an item is immediately visible to
--- every holder of the reference.
--- @return table
exports('GetShared', function()
    return Nitro.Shared
end)

--- Return a single namespace from the shared catalogue.
--- @param namespace 'Items'|'Weapons'|'Vehicles'|'VehicleHashes'|'Locations'|'Jobs'|'Organisations'
--- @param key string? optional second level key
--- @return any
exports('GetSharedNamespace', function(namespace, key)
    if type(namespace) ~= 'string' then return nil end
    if not Nitro.SharedNamespaces[namespace] then return nil end
    local data = Nitro.Shared[namespace]
    if not data then return nil end
    if key == nil then return data end
    return data[key]
end)

--- Read the framework configuration.
--- @param path string? dotted path, e.g. 'Server.Whitelist'
--- @return any
exports('GetConfig', function(path)
    if path == nil then return Nitro.Config end
    return resolvePath(Nitro.Config, path)
end)

--- @return string version string, e.g. "1.0.0"
exports('GetVersion', function()
    return Nitro.GetVersionString()
end)

-- ── Items ───────────────────────────────────────────────────────────────────

--- @param name string
--- @return table?
exports('GetItem', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Items[name]
end)

--- Register (or replace) an item definition.
--- @param name string
--- @param definition table
--- @return boolean ok, string? reason
exports('RegisterItem', function(name, definition)
    if type(name) ~= 'string' or name == '' then return false, 'invalid_name' end
    if type(definition) ~= 'table' then return false, 'invalid_definition' end
    Nitro.Shared.Items[name] = definition
    broadcastUpdate('Items', name, definition)
    return true
end)

--- Remove an item definition.
--- @param name string
--- @return boolean ok, string? reason
exports('RemoveItem', function(name)
    if type(name) ~= 'string' then return false, 'invalid_name' end
    if not Nitro.Shared.Items[name] then return false, 'not_found' end
    Nitro.Shared.Items[name] = nil
    broadcastUpdate('Items', name, nil)
    return true
end)

-- ── Weapons ─────────────────────────────────────────────────────────────────

--- @param name string
--- @return table?
exports('GetWeapon', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Weapons[name] or Nitro.Shared.Weapons[joaat(name)]
end)

--- @param name string
--- @param definition table
--- @return boolean ok, string? reason
exports('RegisterWeapon', function(name, definition)
    if type(name) ~= 'string' then return false, 'invalid_name' end
    if type(definition) ~= 'table' then return false, 'invalid_definition' end
    Nitro.Shared.Weapons[name] = definition
    broadcastUpdate('Weapons', name, definition)
    return true
end)

-- ── Vehicles ────────────────────────────────────────────────────────────────

--- Look a vehicle up by model name.
--- @param model string
--- @return table?
exports('GetVehicle', function(model)
    if type(model) ~= 'string' then return nil end
    return Nitro.Shared.Vehicles[model]
end)

--- @param model string
--- @return table?
exports('GetVehicleByModel', function(model)
    if type(model) ~= 'string' then return nil end
    return Nitro.Shared.Vehicles[model]
end)

--- Look a vehicle up by its joaat hash.
--- @param hash number
--- @return table?
exports('GetVehicleHash', function(hash)
    if hash == nil then return nil end
    return Nitro.Shared.VehicleHashes[tonumber(hash)]
end)

--- @param model string
--- @param definition table
--- @return boolean ok, string? reason
exports('RegisterVehicle', function(model, definition)
    if type(model) ~= 'string' then return false, 'invalid_name' end
    if type(definition) ~= 'table' then return false, 'invalid_definition' end
    Nitro.Shared.Vehicles[model] = definition
    broadcastUpdate('Vehicles', model, definition)
    return true
end)

-- ── Jobs ────────────────────────────────────────────────────────────────────

--- @param name string
--- @return table?
exports('GetJob', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Jobs[name]
end)

--- @param name string
--- @param definition table
--- @return boolean ok, string? reason
exports('RegisterJob', function(name, definition)
    if type(name) ~= 'string' or name == '' then return false, 'invalid_name' end
    if type(definition) ~= 'table' then return false, 'invalid_definition' end
    if type(definition.grades) ~= 'table' then return false, 'missing_grades' end
    Nitro.Shared.Jobs[name] = definition
    broadcastUpdate('Jobs', name, definition)
    return true
end)

--- @param name string
--- @return boolean ok, string? reason
exports('RemoveJob', function(name)
    if type(name) ~= 'string' then return false, 'invalid_name' end
    if not Nitro.Shared.Jobs[name] then return false, 'not_found' end
    Nitro.Shared.Jobs[name] = nil
    broadcastUpdate('Jobs', name, nil)
    return true
end)

-- ── Organisations ───────────────────────────────────────────────────────────

--- @param name string
--- @return table?
exports('GetOrganisation', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Organisations[name]
end)

--- @param name string
--- @param definition table
--- @return boolean ok, string? reason
exports('RegisterOrganisation', function(name, definition)
    if type(name) ~= 'string' or name == '' then return false, 'invalid_name' end
    if type(definition) ~= 'table' then return false, 'invalid_definition' end
    if type(definition.grades) ~= 'table' then return false, 'missing_grades' end
    Nitro.Shared.Organisations[name] = definition
    broadcastUpdate('Organisations', name, definition)
    return true
end)

--- @param name string
--- @return boolean ok, string? reason
exports('RemoveOrganisation', function(name)
    if type(name) ~= 'string' then return false, 'invalid_name' end
    if not Nitro.Shared.Organisations[name] then return false, 'not_found' end
    Nitro.Shared.Organisations[name] = nil
    broadcastUpdate('Organisations', name, nil)
    return true
end)

-- ── Locations ───────────────────────────────────────────────────────────────

--- @param name string
--- @return table?
exports('GetLocation', function(name)
    if type(name) ~= 'string' then return nil end
    return Nitro.Shared.Locations[name]
end)

--- @param name string
--- @param definition table
--- @return boolean ok, string? reason
exports('RegisterLocation', function(name, definition)
    if type(name) ~= 'string' or name == '' then return false, 'invalid_name' end
    if type(definition) ~= 'table' then return false, 'invalid_definition' end
    Nitro.Shared.Locations[name] = definition
    broadcastUpdate('Locations', name, definition)
    return true
end)

-- ── Utilities ───────────────────────────────────────────────────────────────

exports('Round', function(value, decimals) return Nitro.Utils.Round(value, decimals) end)
exports('Trim', function(value) return Nitro.Utils.Trim(value) end)
exports('Split', function(value, delimiter) return Nitro.Utils.Split(value, delimiter) end)
exports('RandomString', function(length) return Nitro.Utils.RandomString(length) end)
exports('RandomNumber', function(length) return Nitro.Utils.RandomNumber(length) end)
exports('DeepCopy', function(value) return Nitro.Utils.DeepCopy(value) end)
exports('IsFunction', function(value) return Nitro.Utils.IsFunction(value) end)
exports('Sanitize', function(value, maxLength) return Nitro.Utils.Sanitise(value, maxLength) end)
exports('Count', function(value) return Nitro.Utils.Count(value) end)

-- ── Localisation ────────────────────────────────────────────────────────────

--- Translate a phrase key using the active locale.
--- @param key string
--- @param substitutions table?
--- @return string
exports('Translate', function(key, substitutions)
    return Nitro.Translate(key, substitutions)
end)

--- Switch the active locale at runtime.
--- @param code string
--- @return boolean
exports('SetLocale', function(code)
    return Nitro.SetLocale(code)
end)

--- @return string current locale code
exports('GetLocale', function()
    return Nitro.CurrentLocale
end)

-- ── Startup sanity check ────────────────────────────────────────────────────

CreateThread(function()
    local missing = {}
    for _, namespace in ipairs({ 'Items', 'Jobs', 'Organisations', 'Vehicles' }) do
        if Nitro.Utils.Count(Nitro.Shared[namespace]) == 0 then
            missing[#missing + 1] = namespace
        end
    end
    if #missing > 0 then
        Nitro.Log.warn(('catalogue namespace(s) empty: %s'):format(table.concat(missing, ', ')), resourceName)
    else
        Nitro.Log.info(('shared catalogues ready (%d items, %d jobs, %d organisations, %d vehicles)'):format(
            Nitro.Utils.Count(Nitro.Shared.Items),
            Nitro.Utils.Count(Nitro.Shared.Jobs),
            Nitro.Utils.Count(Nitro.Shared.Organisations),
            Nitro.Utils.Count(Nitro.Shared.Vehicles)
        ), resourceName)
    end
end)
