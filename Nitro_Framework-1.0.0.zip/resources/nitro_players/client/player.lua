--[[
    nitro_players :: client/player.lua

    Client side character handling: freezing the ped until a character is
    loaded, restoring the saved position and reporting position changes back
    to the server.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Players = Nitro.Players or {}

Nitro.Players.Client = {}

local Client = Nitro.Players.Client

local playerData = {}
local loaded = false
local positionTimer = 0

--- Freeze or unfreeze the local player.
--- @param state boolean
local function setFrozen(state)
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, state)
    SetEntityVisible(ped, not state)
    if state then
        SetEntityCoords(ped, GetEntityCoords(ped), true, true)
    end
end

--- Move the player to a position.
--- @param position table
local function applyPosition(position)
    if type(position) ~= 'table' then return end
    local x, y, z = tonumber(position.x), tonumber(position.y), tonumber(position.z)
    if not x or not y or not z then return end
    local ped = PlayerPedId()
    SetEntityCoords(ped, x + 0.0, y + 0.0, z + 0.0, false, false, false, false)
    if position.heading then
        SetEntityHeading(ped, tonumber(position.heading) or 0.0)
    end
    FreezeEntityPosition(ped, false)
    SetEntityVisible(ped, true)
end

--- The current position of the player.
--- @return table
function Client.GetPosition()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)
    return {
        x = coords.x,
        y = coords.y,
        z = coords.z,
        heading = heading,
    }
end

RegisterNetEvent('nitro:client:playerLoaded', function(data)
    playerData = type(data) == 'table' and data or {}
    loaded = true

    local position = playerData.position or Nitro.Players.Config.DefaultSpawn
    applyPosition(position)

    TriggerEvent('nitro:client:characterLoaded', playerData)
end)

RegisterNetEvent('nitro:client:playerUnloaded', function()
    loaded = false
    playerData = {}
    setFrozen(true)
    TriggerEvent('nitro:client:characterUnloaded')
end)

-- Freeze the player as soon as the session starts so nobody runs around
-- without a character.
CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    setFrozen(true)
    TriggerEvent('nitro:client:readyForSelection')
end)

-- Report the position to the server.
CreateThread(function()
    while true do
        Wait(1000)
        positionTimer = positionTimer + 1
        if positionTimer * 1000 >= Nitro.Players.Config.PositionSyncInterval then
            positionTimer = 0
            if loaded and not IsEntityDead(PlayerPedId()) then
                TriggerServerEvent('nitro:net:req:playerPosition', Client.GetPosition())
            end
        end
    end
end)

-- Report the position right before the player leaves.
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if loaded then
        TriggerServerEvent('nitro:net:req:playerPosition', Client.GetPosition())
    end
end)

-- ── Public client API ───────────────────────────────────────────────────────

exports('GetPlayerData', function()
    return playerData
end)

exports('IsLoaded', function()
    return loaded
end)

exports('GetPosition', function()
    return Client.GetPosition()
end)
