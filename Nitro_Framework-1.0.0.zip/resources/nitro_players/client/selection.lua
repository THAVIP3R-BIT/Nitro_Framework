--[[
    nitro_players :: client/selection.lua

    Drives the character selection flow.

    The screen itself is provided by nitro_ui. When nitro_ui is not running
    the framework falls back to the in game text prompt of GTA V so the
    resource still works on its own.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Players = Nitro.Players or {}

local selected = false

--- Ask the server for the characters of this player.
--- @return table[] characters
local function fetchCharacters()
    local characters = {}
    exports.nitro_core:TriggerCallback('nitro:players:getCharacters', function(ok, result)
        if ok and type(result) == 'table' then
            characters = result
        end
    end)
    return characters
end

--- Open the selection screen.
--- @param characters table[]
local function openSelection(characters)
    if #characters == 0 then
        TriggerEvent('nitro:ui:openCharacterCreator')
        return
    end

    if Nitro.Players.Config.AutoLoadSingleCharacter and #characters == 1 then
        exports.nitro_core:TriggerCallback('nitro:players:loadCharacter', function(ok)
            if not ok then
                TriggerEvent('nitro:ui:openCharacterSelector', characters)
            end
        end, characters[1].characterId)
        return
    end

    TriggerEvent('nitro:ui:openCharacterSelector', characters)
end

-- The screen was opened by nitro_ui, answer it.
RegisterNetEvent('nitro:client:characterSelected', function(characterId)
    if type(characterId) ~= 'string' or characterId == '' then return end
    selected = true
    exports.nitro_core:TriggerCallback('nitro:players:loadCharacter', function(ok, reason)
        if not ok then
            selected = false
            TriggerEvent('nitro:ui:showError', reason or 'The character could not be loaded.')
        end
    end, characterId)
end)

-- A new character was created, load it straight away.
RegisterNetEvent('nitro:client:characterCreated', function(characterId)
    if type(characterId) ~= 'string' or characterId == '' then return end
    exports.nitro_core:TriggerCallback('nitro:players:loadCharacter', function(ok, reason)
        if not ok then
            TriggerEvent('nitro:ui:showError', reason or 'The character could not be loaded.')
        end
    end, characterId)
end)

-- The player asked to open the selection again.
RegisterCommand('characters', function()
    local characters = fetchCharacters()
    openSelection(characters)
end, false)

-- Start the flow as soon as the client is ready.
AddEventHandler('nitro:client:readyForSelection', function()
    if selected then return end
    local characters = fetchCharacters()
    openSelection(characters)
end)

--- Force the selection screen to open again.
exports('OpenCharacterSelection', function()
    local characters = fetchCharacters()
    openSelection(characters)
end)
