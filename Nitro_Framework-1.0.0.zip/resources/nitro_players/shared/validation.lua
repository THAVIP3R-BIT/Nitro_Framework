--[[
    nitro_players :: shared/validation.lua

    Validation helpers for character creation. Every value that reaches the
    database goes through this file first.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Players = Nitro.Players or {}

Nitro.Players.Validation = {}

local Validation = Nitro.Players.Validation

--- Allowed name characters: letters, spaces, apostrophes and hyphens.
local NAME_PATTERN = "^[A-Za-z][A-Za-z'%- ]*$"

--- Validate a first or last name.
--- @param value string
--- @param label string used in the error message
--- @return boolean ok, string? value, string? error
function Validation.ValidateName(value, label)
    if type(value) ~= 'string' then return false, nil, ('%s is required'):format(label) end
    local trimmed = value:gsub('^%s+', ''):gsub('%s+$', '')
    if #trimmed < 2 then return false, nil, ('%s must be at least 2 characters'):format(label) end
    if #trimmed > 24 then return false, nil, ('%s must be at most 24 characters'):format(label) end
    if not trimmed:match(NAME_PATTERN) then
        return false, nil, ('%s may only contain letters, spaces, apostrophes and hyphens'):format(label)
    end
    return true, trimmed, nil
end

--- Validate a phone number.
--- @param value string
--- @return boolean ok, string? value, string? error
function Validation.ValidatePhone(value)
    if value == nil or value == '' then return true, nil, nil end
    if type(value) ~= 'string' then return false, nil, 'Phone number is invalid' end
    local trimmed = value:gsub('%s', '')
    if #trimmed < 4 or #trimmed > 24 then return false, nil, 'Phone number is invalid' end
    if not trimmed:match('^[%+%d%-]+$') then return false, nil, 'Phone number is invalid' end
    return true, trimmed, nil
end

--- Validate a date of birth.
--- @param value string 'YYYY-MM-DD'
--- @return boolean ok, string? value, string? error
function Validation.ValidateDateOfBirth(value)
    if value == nil or value == '' then return true, nil, nil end
    if type(value) ~= 'string' then return false, nil, 'Date of birth is invalid' end
    local year, month, day = value:match('^(%d%d%d%d)%-(%d%d)%-(%d%d)$')
    if not year then return false, nil, 'Date of birth must use the YYYY-MM-DD format' end
    year, month, day = tonumber(year), tonumber(month), tonumber(day)
    if month < 1 or month > 12 or day < 1 or day > 31 then
        return false, nil, 'Date of birth is invalid'
    end
    if year < 1900 or year > tonumber(os.date('%Y')) then
        return false, nil, 'Date of birth is invalid'
    end
    return true, ('%04d-%02d-%02d'):format(year, month, day), nil
end

--- Validate the gender flag.
--- @param value any
--- @return boolean ok, number value, string? error
function Validation.ValidateGender(value)
    local gender = tonumber(value) or 0
    if gender ~= 0 and gender ~= 1 then return false, 0, 'Gender is invalid' end
    return true, gender, nil
end

--- Validate a nationality.
--- @param value string
--- @return boolean ok, string value, string? error
function Validation.ValidateNationality(value)
    if type(value) ~= 'string' or value == '' then return true, 'USA', nil end
    local trimmed = value:gsub('^%s+', ''):gsub('%s+$', ''):upper()
    if #trimmed > 3 or not trimmed:match('^[A-Z]+$') then
        return false, 'USA', 'Nationality must be a three letter country code'
    end
    return true, trimmed, nil
end

--- Validate a job name against the shared catalogue.
--- @param value string
--- @return boolean ok, string value, string? error
function Validation.ValidateJob(value)
    local job = value
    if type(job) ~= 'string' or job == '' then
        return true, Nitro.Players.Config.DefaultJob, nil
    end
    job = job:lower()
    if job == 'none' or job == 'unemployed' then
        return true, Nitro.Players.Config.DefaultJob, nil
    end
    local ok = pcall(function()
        return exports.nitro_shared:GetJob(job)
    end)
    if not ok then return true, Nitro.Players.Config.DefaultJob, nil end
    if not exports.nitro_shared:GetJob(job) then
        return false, nil, 'Unknown job'
    end
    return true, job, nil
end
