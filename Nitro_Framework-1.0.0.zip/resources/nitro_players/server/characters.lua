--[[
    nitro_players :: server/characters.lua

    Character lifecycle: create, list, load, unload and delete.

    Every statement goes through the nitro_database resource, which in turn
    talks to oxmysql. Nothing in this file opens a database connection.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Players = Nitro.Players or {}

Nitro.Players.Characters = {}

local Characters = Nitro.Players.Characters

local ID_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

--- Generate a character identifier, e.g. "K3XQ7BNA".
--- @return string
local function generateCharacterId()
    local id = {}
    for index = 1, 8 do
        local position = math.random(1, #ID_ALPHABET)
        id[index] = ID_ALPHABET:sub(position, position)
    end
    return table.concat(id)
end

--- The Rockstar licence of a player.
--- @param src number
--- @return string?
function Nitro.Players.GetLicense(src)
    if type(src) ~= 'number' or src <= 0 then return nil end
    for _, identifier in ipairs(GetPlayerIdentifiers(src) or {}) do
        local prefix, value = identifier:match('^([^:]+):(.+)$')
        if prefix == 'license' or prefix == 'license2' then
            return value
        end
    end
    return nil
end

--- Find (or create) the account row of a player.
--- @param src number
--- @return table? account
function Nitro.Players.GetAccount(src)
    local license = Nitro.Players.GetLicense(src)
    if not license then return nil end

    local account = exports.nitro_database:Single(
        'SELECT * FROM nitro_accounts WHERE license = ?',
        { license }
    )

    if not account then
        exports.nitro_database:Insert(
            'INSERT IGNORE INTO nitro_accounts (license) VALUES (?)',
            { license }
        )
        account = exports.nitro_database:Single(
            'SELECT * FROM nitro_accounts WHERE license = ?',
            { license }
        )
    end

    return account
end

--- Every character of the account that owns the player.
--- @param src number
--- @return table[] characters
function Characters.List(src)
    local account = Nitro.Players.GetAccount(src)
    if not account then return {} end
    local rows = exports.nitro_database:Query(
        'SELECT * FROM nitro_characters WHERE account_id = ? ORDER BY last_seen DESC, id ASC',
        { account.id }
    )
    return rows or {}
end

--- Turn a database row into the player data structure used by the framework.
--- @param row table
--- @param account table?
--- @return table
function Characters.ToPlayerData(row, account)
    local job = row.job_name or Nitro.Players.Config.DefaultJob
    local organisation = row.organisation_name or Nitro.Players.Config.DefaultOrganisation

    local jobDefinition = nil
    local organisationDefinition = nil
    pcall(function()
        jobDefinition = exports.nitro_shared:GetJob(job)
        organisationDefinition = exports.nitro_shared:GetOrganisation(organisation)
    end)

    local jobGrade = row.job_grade or 0
    local grade = nil
    if jobDefinition and type(jobDefinition.grades) == 'table' then
        grade = jobDefinition.grades[jobGrade] or jobDefinition.grades[tostring(jobGrade)]
    end

    return {
        characterId = row.character_id,
        accountId = account and account.id or nil,
        license = account and account.license or nil,
        firstName = row.first_name,
        lastName = row.last_name,
        dateOfBirth = row.date_of_birth,
        gender = row.gender,
        nationality = row.nationality,
        phone = row.phone,
        accountNumber = row.account_number,
        cash = row.cash or 0,
        job = {
            name = job,
            label = jobDefinition and jobDefinition.label or job,
            grade = jobGrade,
            gradeLabel = grade and grade.name or ('Grade ' .. jobGrade),
            isBoss = grade and grade.isboss or false,
            payment = grade and grade.payment or 0,
            duty = true,
        },
        organisation = {
            name = organisation,
            label = organisationDefinition and organisationDefinition.label or organisation,
            grade = row.organisation_grade or 0,
        },
        position = row.position,
        metadata = row.metadata or {},
        status = row.status or {},
        lastSeen = row.last_seen,
    }
end

--- Create a new character.
--- @param src number
--- @param data table
--- @return boolean ok, table? character, string? error
function Characters.Create(src, data)
    if type(data) ~= 'table' then return false, nil, 'invalid_data' end

    local account = Nitro.Players.GetAccount(src)
    if not account then return false, nil, 'no_account' end

    local maxCharacters = 5
    pcall(function()
        maxCharacters = exports.nitro_shared:GetConfig('Security.MaxCharactersPerAccount') or maxCharacters
    end)

    local count = exports.nitro_database:Scalar(
        'SELECT COUNT(*) FROM nitro_characters WHERE account_id = ?',
        { account.id }
    ) or 0
    if count >= maxCharacters then
        return false, nil, 'too_many_characters'
    end

    local Validation = Nitro.Players.Validation
    local firstName, lastName

    local ok, value, err = Validation.ValidateName(data.firstName, 'First name')
    if not ok then return false, nil, err end
    firstName = value

    ok, value, err = Validation.ValidateName(data.lastName, 'Last name')
    if not ok then return false, nil, err end
    lastName = value

    local dateOfBirth
    ok, value, err = Validation.ValidateDateOfBirth(data.dateOfBirth)
    if not ok then return false, nil, err end
    dateOfBirth = value

    local gender
    ok, value, err = Validation.ValidateGender(data.gender)
    if not ok then return false, nil, err end
    gender = value

    local nationality
    ok, value, err = Validation.ValidateNationality(data.nationality)
    if not ok then return false, nil, err end
    nationality = value

    local phone
    ok, value, err = Validation.ValidatePhone(data.phone)
    if not ok then return false, nil, err end
    phone = value

    local job
    ok, value, err = Validation.ValidateJob(data.job)
    if not ok then return false, nil, err end
    job = value

    local characterId = generateCharacterId()
    local accountNumber = ('NITRO%s'):format(account.id):sub(1, 24)

    local insertId = exports.nitro_database:Insert(
        ([[
            INSERT INTO nitro_characters
                (account_id, character_id, first_name, last_name, date_of_birth, gender,
                 nationality, phone, account_number, job_name, job_grade,
                 organisation_name, organisation_grade, cash, position, metadata, last_seen)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ]]):gsub('%s+', ' '),
        {
            account.id,
            characterId,
            firstName,
            lastName,
            dateOfBirth,
            gender,
            nationality,
            phone,
            accountNumber,
            job,
            0,
            Nitro.Players.Config.DefaultOrganisation,
            0,
            Nitro.Players.Config.StartingCash,
            json.encode(Nitro.Players.Config.DefaultSpawn),
            json.encode({}),
        }
    )

    if not insertId or insertId == 0 then
        return false, nil, 'insert_failed'
    end

    -- Every character owns a personal bank account.
    exports.nitro_database:Insert(
        'INSERT IGNORE INTO nitro_banking_accounts (owner_type, owner_id, account_number, label, balance) VALUES (?, ?, ?, ?, ?)',
        { 'character', characterId, accountNumber, 'Personal Account', Nitro.Players.Config.StartingBank }
    )

    local row = exports.nitro_database:Single(
        'SELECT * FROM nitro_characters WHERE character_id = ?',
        { characterId }
    )

    TriggerEvent('nitro:server:characterCreated', src, row)
    return true, row, nil
end

--- Check whether a character belongs to the player.
--- @param src number
--- @param characterId string
--- @return boolean
function Characters.Owns(src, characterId)
    local account = Nitro.Players.GetAccount(src)
    if not account or type(characterId) ~= 'string' then return false end
    local row = exports.nitro_database:Single(
        'SELECT id FROM nitro_characters WHERE character_id = ? AND account_id = ?',
        { characterId, account.id }
    )
    return row ~= nil
end

--- Delete a character.
--- @param src number
--- @param characterId string
--- @return boolean ok, string? error
function Characters.Delete(src, characterId)
    if type(characterId) ~= 'string' or characterId == '' then return false, 'invalid_id' end
    if not Characters.Owns(src, characterId) then return false, 'not_owner' end
    if not Nitro.Players.Config.AllowDeleteOnline and Nitro.Players.IsLoaded(src) then
        return false, 'character_in_use'
    end

    local affected = exports.nitro_database:Update(
        'DELETE FROM nitro_characters WHERE character_id = ?',
        { characterId }
    )
    if affected == 0 then return false, 'not_found' end

    exports.nitro_database:Update(
        'DELETE FROM nitro_banking_accounts WHERE owner_type = ? AND owner_id = ?',
        { 'character', characterId }
    )
    exports.nitro_database:Update(
        'DELETE FROM nitro_inventories WHERE owner_type = ? AND owner_id = ?',
        { 'character', characterId }
    )

    TriggerEvent('nitro:server:characterDeleted', src, characterId)
    return true, nil
end

--- Load a character and turn the player into that character.
--- @param src number
--- @param characterId string
--- @return boolean ok, table? data, string? error
function Characters.Load(src, characterId)
    if type(characterId) ~= 'string' or characterId == '' then return false, nil, 'invalid_id' end
    if not Characters.Owns(src, characterId) then return false, nil, 'not_owner' end
    if Nitro.Players.IsLoaded(src) then return false, nil, 'already_loaded' end

    local row = exports.nitro_database:Single(
        'SELECT * FROM nitro_characters WHERE character_id = ?',
        { characterId }
    )
    if not row then return false, nil, 'not_found' end

    local account = Nitro.Players.GetAccount(src)
    local data = Characters.ToPlayerData(row, account)

    Nitro.Players.ActiveCharacter = Nitro.Players.ActiveCharacter or {}
    Nitro.Players.ActiveCharacter[src] = data

    exports.nitro_core:SetPlayerData(src, data)
    exports.nitro_core:SetPlayerData(src, {
        characterId = data.characterId,
        firstName = data.firstName,
        lastName = data.lastName,
        name = ('%s %s'):format(data.firstName, data.lastName),
        job = data.job,
        organisation = data.organisation,
        cash = data.cash,
    })

    TriggerClientEvent('nitro:client:playerLoaded', src, data)
    TriggerEvent('nitro:server:playerLoaded', src, data)

    return true, data, nil
end

--- Unload the current character of a player.
--- @param src number
--- @return boolean
function Characters.Unload(src)
    if not Nitro.Players.IsLoaded(src) then return false end
    local data = Nitro.Players.ActiveCharacter and Nitro.Players.ActiveCharacter[src]
    Nitro.Players.ActiveCharacter[src] = nil
    exports.nitro_core:ClearPlayerData(src)
    TriggerClientEvent('nitro:client:playerUnloaded', src)
    TriggerEvent('nitro:server:characterUnloaded', src, data)
    return true
end
