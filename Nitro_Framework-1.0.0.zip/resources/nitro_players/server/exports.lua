--[[
    nitro_players :: server/exports.lua

    Public server API of nitro_players, plus the callbacks the character
    selection screen uses.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Players = Nitro.Players or {}

local Characters = Nitro.Players.Characters

-- ── Exports ──────────────────────────────────────────────────────────────────

--- The account row of a player.
--- @param src number
--- @return table?
exports('GetAccount', function(src)
    return Nitro.Players.GetAccount(src)
end)

--- Every character of the account that owns the player.
--- @param src number
--- @return table[]
exports('GetCharacters', function(src)
    return Characters.List(src)
end)

--- @param src number
--- @param data table
--- @return boolean ok, table? character, string? error
exports('CreateCharacter', function(src, data)
    return Characters.Create(src, data)
end)

--- @param src number
--- @param characterId string
--- @return boolean ok, string? error
exports('DeleteCharacter', function(src, characterId)
    return Characters.Delete(src, characterId)
end)

--- @param src number
--- @param characterId string
--- @return boolean ok, table? data, string? error
exports('LoadCharacter', function(src, characterId)
    return Characters.Load(src, characterId)
end)

--- @param src number
--- @return boolean
exports('UnloadCharacter', function(src)
    return Characters.Unload(src)
end)

--- @param src number
--- @return boolean saved
exports('SaveCharacter', function(src)
    return Nitro.Players.Save(src)
end)

--- Look a character up by its identifier.
--- @param characterId string
--- @return table?
exports('GetCharacter', function(characterId)
    if type(characterId) ~= 'string' then return nil end
    return exports.nitro_database:Single(
        'SELECT * FROM nitro_characters WHERE character_id = ?',
        { characterId }
    )
end)

--- @param src number
--- @return boolean
exports('IsLoaded', function(src)
    return Nitro.Players.IsLoaded(src)
end)

--- The live player data of a player.
--- @param src number
--- @return table?
exports('GetPlayerData', function(src)
    return Nitro.Players.ActiveCharacter[src]
end)

--- The server id of the player that is playing a character.
--- @param characterId string
--- @return number?
exports('GetSrcByCharacterId', function(characterId)
    if type(characterId) ~= 'string' then return nil end
    for _, player in ipairs(exports.nitro_core:GetOnlinePlayers()) do
        local data = exports.nitro_core:GetPlayerData(player.src)
        if data and data.characterId == characterId then
            return player.src
        end
    end
    return nil
end)

--- @param src number
--- @param position table
exports('SetPosition', function(src, position)
    Nitro.Players.SetPosition(src, position)
end)

--- @param src number
--- @return table?
exports('GetPosition', function(src)
    return Nitro.Players.GetPosition(src)
end)

-- ── Callbacks ────────────────────────────────────────────────────────────────

exports.nitro_core:RegisterCallback('nitro:players:getCharacters', function(src)
    local characters = Characters.List(src)
    local summary = {}
    for _, row in ipairs(characters) do
        summary[#summary + 1] = {
            characterId = row.character_id,
            firstName = row.first_name,
            lastName = row.last_name,
            dateOfBirth = row.date_of_birth,
            gender = row.gender,
            nationality = row.nationality,
            jobName = row.job_name,
            jobGrade = row.job_grade,
            organisationName = row.organisation_name,
            cash = row.cash,
            lastSeen = row.last_seen,
        }
    end
    return summary
end)

exports.nitro_core:RegisterCallback('nitro:players:createCharacter', function(src, data)
    local ok, character, err = Characters.Create(src, data)
    if not ok then return false, err end
    return true, {
        characterId = character.character_id,
        firstName = character.first_name,
        lastName = character.last_name,
    }
end)

exports.nitro_core:RegisterCallback('nitro:players:deleteCharacter', function(src, characterId)
    return Characters.Delete(src, characterId)
end)

exports.nitro_core:RegisterCallback('nitro:players:loadCharacter', function(src, characterId)
    local ok, data, err = Characters.Load(src, characterId)
    if not ok then return false, err end
    return true, {
        characterId = data.characterId,
        firstName = data.firstName,
        lastName = data.lastName,
    }
end)

exports.nitro_core:RegisterCallback('nitro:players:isLoaded', function(src)
    return Nitro.Players.IsLoaded(src)
end)

exports.nitro_core:RegisterCallback('nitro:players:getPlayerData', function(src)
    return Nitro.Players.ActiveCharacter[src] or {}
end)
