-- =============================================================================
-- nitro_players :: server/persistence.lua
--
-- Keeps the character row in sync with the live session.
--
-- Ownership rules
--   nitro_players    writes `position` and `last_seen`.
--   nitro_characters writes `metadata` (appearance, notes).
--   nitro_jobs       writes `job_name`, `job_grade` and `status`.
--   nitro_banking    writes `cash` and the bank balance.
--
-- Every resource therefore owns its own columns and no two resources race
-- for the same row.
--
-- Original Nitro_Framework work. Licensed GPL-3.0-or-later.
-- =============================================================================

Nitro = Nitro or {}
Nitro.Players = Nitro.Players or {}

Nitro.Players.ActiveCharacter = Nitro.Players.ActiveCharacter or {}
Nitro.Players.Positions = Nitro.Players.Positions or {}

local Characters = Nitro.Players.Characters

--- @param src number
--- @return boolean
function Nitro.Players.IsLoaded(src)
    return Nitro.Players.ActiveCharacter[src] ~= nil
end

--- Store the last known position of a player.
--- @param src number
--- @param position table
function Nitro.Players.SetPosition(src, position)
    if type(src) ~= 'number' or src <= 0 then return end
    if type(position) ~= 'table' then return end
    local x, y, z, heading = tonumber(position.x), tonumber(position.y), tonumber(position.z), tonumber(position.heading)
    if not x or not y or not z then return end
    Nitro.Players.Positions[src] = {
        x = x,
        y = y,
        z = z,
        heading = heading or 0.0,
    }
end

--- The last known position of a player.
--- @param src number
--- @return table?
function Nitro.Players.GetPosition(src)
    return Nitro.Players.Positions[src]
end

--- Write the character row to the database.
--- @param src number
--- @return boolean saved
function Nitro.Players.Save(src)
    local data = Nitro.Players.ActiveCharacter[src]
    if not data then return false end

    local position = Nitro.Players.Positions[src] or data.position

    local affected = exports.nitro_database:Update(
        'UPDATE nitro_characters SET position = ?, last_seen = NOW() WHERE character_id = ?',
        { json.encode(position), data.characterId }
    )

    return affected > 0
end

--- Persist a player and release the session.
--- @param src number
function Nitro.Players.UnloadAndSave(src)
    if Nitro.Players.Config.SaveOnDisconnect then
        Nitro.Players.Save(src)
    end
    Characters.Unload(src)
    Nitro.Players.Positions[src] = nil
end

-- ── Events ───────────────────────────────────────────────────────────────────

RegisterNetEvent('nitro:net:req:playerPosition', function(position)
    local src = source
    if not Nitro.Players.IsLoaded(src) then return end
    Nitro.Players.SetPosition(src, position)
end)

AddEventHandler('playerDropped', function()
    local src = source
    Nitro.Players.UnloadAndSave(src)
end)

-- ── Periodic save ────────────────────────────────────────────────────────────

CreateThread(function()
    while true do
        Wait(Nitro.Players.Config.SaveInterval)
        for src in pairs(Nitro.Players.ActiveCharacter) do
            local ok, err = pcall(function()
                return Nitro.Players.Save(src)
            end)
            if not ok then
                print(('^1[nitro_players] failed to save character %d: %s^0'):format(src, tostring(err)))
            end
        end
    end
end)
