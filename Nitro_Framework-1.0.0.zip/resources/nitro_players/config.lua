--[[
    nitro_players :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Players = Nitro.Players or {}

Nitro.Players.Config = {
    -- How often the character is written to the database while the player is
    -- online (milliseconds).
    SaveInterval = 120000,

    -- Write the character when the player disconnects.
    SaveOnDisconnect = true,

    -- How often the client reports its position to the server (milliseconds).
    PositionSyncInterval = 5000,

    -- Default values for a freshly created character.
    DefaultJob = 'unemployed',
    DefaultOrganisation = 'none',
    StartingCash = 500,
    StartingBank = 5000,

    -- The world position a player spawns at when no position was saved yet.
    DefaultSpawn = {
        x = -1035.71,
        y = -2731.87,
        z = 12.86,
        heading = 0.0,
    },

    -- Automatically load the only character of an account, skipping the
    -- selection screen.
    AutoLoadSingleCharacter = true,

    -- Allow a character to be deleted while it is online.
    AllowDeleteOnline = false,
}
