fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_players'
author 'Nitro_Framework'
description 'Nitro_Framework accounts, characters and character persistence.'
version '1.0.0'

shared_scripts {
    'config.lua',
    'shared/validation.lua',
}

server_scripts {
    'server/characters.lua',
    'server/persistence.lua',
    'server/exports.lua',
}

client_scripts {
    'client/player.lua',
    'client/selection.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'
dependency 'nitro_core'

exports {
    'GetAccount',
    'GetCharacters',
    'CreateCharacter',
    'DeleteCharacter',
    'LoadCharacter',
    'UnloadCharacter',
    'SaveCharacter',
    'GetCharacter',
    'IsLoaded',
    'GetPlayerData',
    'SetPosition',
    'GetPosition',
    'OpenCharacterSelection',
    'GetSrcByCharacterId',
}
