--[[
    nitro_jobs :: client/jobs.lua

    Client side employment helpers.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Jobs = Nitro.Jobs or {}

local job = {}
local organisation = {}

--- Refresh the job from the server.
local function refresh()
    exports.nitro_core:TriggerCallback('nitro:jobs:getJob', function(ok, result)
        if not ok or type(result) ~= 'table' then return end
        job = result
        TriggerEvent('nitro:client:jobUpdated', job)
        TriggerEvent('nitro:ui:updateJob', job)
    end)
end

RegisterNetEvent('nitro:client:jobUpdated', function(data)
    job = type(data) == 'table' and data or {}
    TriggerEvent('nitro:ui:updateJob', job)
end)

RegisterNetEvent('nitro:client:organisationUpdated', function(data)
    organisation = type(data) == 'table' and data or {}
    TriggerEvent('nitro:ui:updateOrganisation', organisation)
end)

RegisterNetEvent('nitro:client:characterLoaded', function()
    refresh()
end)

RegisterNetEvent('nitro:client:characterUnloaded', function()
    job = {}
    organisation = {}
end)

-- Toggle the duty state.
RegisterCommand('duty', function()
    exports.nitro_core:TriggerCallback('nitro:jobs:toggleDuty', function(ok, result)
        if not ok then
            TriggerEvent('nitro:ui:showError', result or 'Duty could not be changed.')
            return
        end
        TriggerEvent('nitro:ui:notification', {
            type = 'info',
            message = result and 'You are now on duty.' or 'You are now off duty.',
        })
    end)
end, false)

--- The job of the player.
--- @return table
exports('GetJob', function()
    return job
end)

--- The organisation of the player.
--- @return table
exports('GetOrganisation', function()
    return organisation
end)
