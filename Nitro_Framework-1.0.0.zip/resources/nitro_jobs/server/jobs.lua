--[[
    nitro_jobs :: server/jobs.lua

    Employment: the job of a character, its grade, duty state and the
    organisation it belongs to.

    The catalogue that ships with the framework lives in nitro_shared. This
    resource mirrors it into the database so an administrator can change a
    salary or a rank at runtime.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Jobs = Nitro.Jobs or {}

Nitro.Jobs.Core = {}

local Core = Nitro.Jobs.Core

--- The job definition of a job name.
--- @param jobName string
--- @return table?
function Core.GetJobDefinition(jobName)
    if type(jobName) ~= 'string' then return nil end
    local ok, definition = pcall(function()
        return exports.nitro_shared:GetJob(jobName)
    end)
    if not ok then return nil end
    return definition
end

--- The grades of a job.
--- @param jobName string
--- @return table grades map of level -> definition
function Core.GetGrades(jobName)
    local definition = Core.GetJobDefinition(jobName)
    if not definition or type(definition.grades) ~= 'table' then return {} end
    return definition.grades
end

--- A single grade of a job. The grade map may be keyed by number or by
--- string, so both are tried.
--- @param jobName string
--- @param level number
--- @return table?
function Core.GetGrade(jobName, level)
    local grades = Core.GetGrades(jobName)
    return grades[level] or grades[tostring(level)]
end

--- The grades of a job as a sorted list.
--- @param jobName string
--- @return table[]
function Core.GetGradeList(jobName)
    local grades = Core.GetGrades(jobName)
    local list = {}
    for level, grade in pairs(grades) do
        list[#list + 1] = {
            level = tonumber(level) or 0,
            name = grade.name,
            payment = grade.payment,
            isboss = grade.isboss,
            permissions = grade.permissions,
        }
    end
    table.sort(list, function(a, b) return a.level < b.level end)
    return list
end

--- The job of a character.
--- @param characterId string
--- @return table?
function Core.GetJob(characterId)
    if type(characterId) ~= 'string' then return nil end
    local row = exports.nitro_database:Single(
        'SELECT job_name, job_grade, status FROM nitro_characters WHERE character_id = ?',
        { characterId }
    )
    if not row then return nil end

    local definition = Core.GetJobDefinition(row.job_name)
    local grade = Core.GetGrade(row.job_name, row.job_grade or 0)

    return {
        name = row.job_name,
        label = definition and definition.label or row.job_name,
        grade = row.job_grade or 0,
        gradeLabel = grade and grade.name or ('Grade ' .. tostring(row.job_grade or 0)),
        isBoss = grade and grade.isboss or false,
        payment = grade and grade.payment or 0,
        duty = Core.IsOnDuty(characterId),
    }
end

--- Is the character on duty?
--- @param characterId string
--- @return boolean
function Core.IsOnDuty(characterId)
    if type(characterId) ~= 'string' then return false end
    local row = exports.nitro_database:Single(
        'SELECT status FROM nitro_characters WHERE character_id = ?',
        { characterId }
    )
    if not row or not row.status then return true end
    local status = type(row.status) == 'table' and row.status or json.decode(row.status)
    if type(status) ~= 'table' then return true end
    if status.duty == nil then return true end
    return status.duty == true
end

--- Set the job and grade of a character.
--- @param src number
--- @param jobName string
--- @param grade number?
--- @return boolean ok, table? job, string? error
function Core.SetJob(src, jobName, grade)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, nil, 'no_character' end

    local definition = Core.GetJobDefinition(jobName)
    if not definition then return false, nil, 'unknown_job' end

    grade = math.floor(tonumber(grade) or 0)
    local gradeDefinition = Core.GetGrade(jobName, grade)
    if not gradeDefinition then return false, nil, 'invalid_grade' end

    exports.nitro_database:Update(
        'UPDATE nitro_characters SET job_name = ?, job_grade = ? WHERE character_id = ?',
        { jobName, grade, data.characterId }
    )

    data.job = {
        name = jobName,
        label = definition.label or jobName,
        grade = grade,
        gradeLabel = gradeDefinition.label,
        isBoss = gradeDefinition.isboss or false,
        payment = gradeDefinition.payment or 0,
        duty = data.job and data.job.duty ~= false,
    }

    exports.nitro_core:SetPlayerData(src, { job = data.job })
    TriggerClientEvent('nitro:client:jobUpdated', src, data.job)
    TriggerEvent('nitro:server:jobUpdated', src, data.job)

    return true, data.job, nil
end

--- Set the grade of a character, keeping the job.
--- @param src number
--- @param grade number
--- @return boolean ok, table? job, string? error
function Core.SetGrade(src, grade)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data or not data.job then return false, nil, 'no_character' end
    return Core.SetJob(src, data.job.name, grade)
end

--- Toggle the duty state of a character.
--- @param src number
--- @param duty boolean
--- @return boolean ok, string? error
function Core.SetDuty(src, duty)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end

    duty = duty == true
    -- The JSON path is written with single quotes so that the statement also
    -- works on a server that runs MySQL with ANSI_QUOTES enabled.
    exports.nitro_database:Update(
        [[UPDATE nitro_characters SET status = JSON_SET(COALESCE(status, JSON_OBJECT()), '$.duty', ?) WHERE character_id = ?]],
        { duty and 1 or 0, data.characterId }
    )

    if data.job then
        data.job.duty = duty
        exports.nitro_core:SetPlayerData(src, { job = data.job })
        TriggerClientEvent('nitro:client:jobUpdated', src, data.job)
    end
    TriggerEvent('nitro:server:dutyChanged', src, duty)
    return true, nil
end

--- The organisation of a character.
--- @param characterId string
--- @return table?
function Core.GetOrganisation(characterId)
    if type(characterId) ~= 'string' then return nil end
    local row = exports.nitro_database:Single(
        'SELECT organisation_name, organisation_grade FROM nitro_characters WHERE character_id = ?',
        { characterId }
    )
    if not row then return nil end
    local definition
    pcall(function()
        definition = exports.nitro_shared:GetOrganisation(row.organisation_name)
    end)
    return {
        name = row.organisation_name,
        label = definition and definition.label or row.organisation_name,
        grade = row.organisation_grade or 0,
    }
end

--- Set the organisation of a character.
--- @param src number
--- @param organisationName string
--- @param grade number?
--- @return boolean ok, string? error
function Core.SetOrganisation(src, organisationName, grade)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end

    local definition
    pcall(function()
        definition = exports.nitro_shared:GetOrganisation(organisationName)
    end)
    if not definition then return false, 'unknown_organisation' end

    grade = math.floor(tonumber(grade) or 0)
    local rankDefinition = Core.GetGrade(organisationName, grade)
    if not rankDefinition then return false, 'invalid_grade' end

    exports.nitro_database:Update(
        'UPDATE nitro_characters SET organisation_name = ?, organisation_grade = ? WHERE character_id = ?',
        { organisationName, grade, data.characterId }
    )

    data.organisation = {
        name = organisationName,
        label = definition.label or organisationName,
        grade = grade,
    }
    exports.nitro_core:SetPlayerData(src, { organisation = data.organisation })
    TriggerClientEvent('nitro:client:organisationUpdated', src, data.organisation)
    TriggerEvent('nitro:server:organisationUpdated', src, data.organisation)

    return true, nil
end

--- Write the catalogue of nitro_shared into the database.
--- @return boolean ok, number jobs, number grades
function Core.SyncCatalogue()
    local jobs = exports.nitro_shared:GetSharedNamespace('Jobs') or {}
    local jobCount, gradeCount = 0, 0

    for name, definition in pairs(jobs) do
        if type(name) == 'string' and type(definition) == 'table' then
            exports.nitro_database:Insert(
                'INSERT INTO nitro_jobs (name, label, type, default_duty, off_duty_pay, metadata) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), type = VALUES(type), default_duty = VALUES(default_duty), off_duty_pay = VALUES(off_duty_pay)',
                {
                    name,
                    definition.label or name,
                    definition.type or 'none',
                    definition.defaultDuty == false and 0 or 1,
                    definition.offDutyPay and 1 or 0,
                    json.encode(definition.metadata or {}),
                }
            )
            jobCount = jobCount + 1

            local jobRow = exports.nitro_database:Single('SELECT id FROM nitro_jobs WHERE name = ?', { name })
            if jobRow then
                for level, grade in pairs(definition.grades or {}) do
                    local gradeLevel = tonumber(level) or 0
                    exports.nitro_database:Insert(
                        'INSERT INTO nitro_job_grades (job_id, level, name, payment, is_boss, permissions) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), payment = VALUES(payment), is_boss = VALUES(is_boss)',
                        {
                            jobRow.id,
                            gradeLevel,
                            grade.name or ('Grade ' .. tostring(gradeLevel)),
                            tonumber(grade.payment) or 0,
                            grade.isboss and 1 or 0,
                            json.encode(grade.permissions or {}),
                        }
                    )
                    gradeCount = gradeCount + 1
                end
            end
        end
    end

    return true, jobCount, gradeCount
end
