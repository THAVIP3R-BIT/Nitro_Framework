--[[
    nitro_jobs :: server/payroll.lua

    The hourly pay run.

    Every online character with a job receives the payment of its grade.
    The payment is written to the bank account of the character.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Jobs = Nitro.Jobs or {}

Nitro.Jobs.Payroll = {}

local Payroll = Nitro.Jobs.Payroll

--- Pay every online character.
--- @return number paidAmount, number paidPlayers
function Payroll.Run()
    local players = exports.nitro_core:GetOnlinePlayers()
    local total = 0
    local count = 0

    for _, player in ipairs(players) do
        local data = exports.nitro_core:GetPlayerData(player.src)
        if data and data.job and data.characterId then
            local onDuty = true
            if Nitro.Jobs.Config.PayrollRequiresDuty then
                onDuty = data.job.duty ~= false
            end
            if onDuty and (data.job.payment or 0) > 0 then
                local ok
                if Nitro.Jobs.Config.PayrollToBank then
                    ok = exports.nitro_banking:AddBank(
                        'character', data.characterId, data.job.payment, 'Payroll', nil
                    )
                else
                    ok = exports.nitro_banking:AddCash(
                        data.characterId, data.job.payment, 'Payroll', nil
                    )
                end
                if ok then
                    total = total + data.job.payment
                    count = count + 1
                    TriggerClientEvent('nitro:client:payday', player.src, data.job.payment)
                end
            end
        end
    end

    TriggerEvent('nitro:server:payrollCompleted', total, count)
    return total, count
end

CreateThread(function()
    while true do
        Wait(Nitro.Jobs.Config.PayrollInterval)
        local ok, err = pcall(function()
            return Payroll.Run()
        end)
        if not ok then
            print(('^1[nitro_jobs] payroll failed: %s^0'):format(tostring(err)))
        end
    end
end)

--- Run the payroll now (used by the admin resource).
exports('RunPayroll', function()
    return Payroll.Run()
end)
