--[[
    nitro_jobs :: server/exports.lua

    Public server API of nitro_jobs.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Jobs = Nitro.Jobs or {}

local Core = Nitro.Jobs.Core

--- The job of a character.
--- @param characterId string
--- @return table?
exports('GetJob', function(characterId)
    return Core.GetJob(characterId)
end)

--- The grades of a job.
--- @param jobName string
--- @return table
exports('GetGrades', function(jobName)
    return Core.GetGrades(jobName)
end)

--- A single grade of a job.
--- @param jobName string
--- @param level number
--- @return table?
exports('GetGrade', function(jobName, level)
    return Core.GetGrade(jobName, level)
end)

--- Set the job and grade of a player.
--- @param src number
--- @param jobName string
--- @param grade number?
--- @return boolean ok, table? job, string? error
exports('SetJob', function(src, jobName, grade)
    return Core.SetJob(src, jobName, grade)
end)

--- Set the grade of a player.
--- @param src number
--- @param grade number
--- @return boolean ok, table? job, string? error
exports('SetGrade', function(src, grade)
    return Core.SetGrade(src, grade)
end)

--- Toggle the duty state of a player.
--- @param src number
--- @param duty boolean
--- @return boolean ok, string? error
exports('SetDuty', function(src, duty)
    return Core.SetDuty(src, duty)
end)

--- Is the character on duty?
--- @param characterId string
--- @return boolean
exports('IsOnDuty', function(characterId)
    return Core.IsOnDuty(characterId)
end)

--- The organisation of a character.
--- @param characterId string
--- @return table?
exports('GetOrganisation', function(characterId)
    return Core.GetOrganisation(characterId)
end)

--- Set the organisation of a player.
--- @param src number
--- @param organisationName string
--- @param grade number?
--- @return boolean ok, string? error
exports('SetOrganisation', function(src, organisationName, grade)
    return Core.SetOrganisation(src, organisationName, grade)
end)

--- Write the shared job catalogue into the database.
--- @return boolean ok, number jobs, number grades
exports('SyncCatalogue', function()
    return Core.SyncCatalogue()
end)

--- Does the job of a player hold a grade permission?
--- @param src number
--- @param permission string
--- @return boolean
exports('HasGradePermission', function(src, permission)
    local data = exports.nitro_core:GetPlayerData(src)
    if not data or not data.job then return false end
    local grade = Core.GetGrade(data.job.name, data.job.grade)
    if not grade or type(grade.permissions) ~= 'table' then return false end
    for _, entry in ipairs(grade.permissions) do
        if entry == permission then return true end
    end
    return false
end)

-- ── Callbacks ────────────────────────────────────────────────────────────────

exports.nitro_core:RegisterCallback('nitro:jobs:getJob', function(src)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return {} end
    return data.job or {}
end)

exports.nitro_core:RegisterCallback('nitro:jobs:toggleDuty', function(src)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data or not data.job then return false, 'no_character' end
    local duty = data.job.duty == false
    local ok, err = Core.SetDuty(src, duty)
    if not ok then return false, err end
    return true, duty
end)

-- Mirror the catalogue into the database when the resource starts.
CreateThread(function()
    if not Nitro.Jobs.Config.SyncCatalogueOnStart then return end
    -- Give the database a moment to come up.
    Wait(3000)
    local ok, jobs, grades = pcall(function()
        return Core.SyncCatalogue()
    end)
    if ok then
        print(('^2[Nitro]^7 job catalogue synced (%d jobs, %d grades)'):format(jobs, grades))
    else
        print(('^1[Nitro]^7 job catalogue sync failed: %s'):format(tostring(grades)))
    end
end)
