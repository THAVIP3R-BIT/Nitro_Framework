--[[
    nitro_jobs :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Jobs = Nitro.Jobs or {}

Nitro.Jobs.Config = {
    -- Interval between two pay runs, in milliseconds (one hour).
    PayrollInterval = 3600000,

    -- Pay is only given to characters that are on duty.
    PayrollRequiresDuty = true,

    -- Payroll is written to the bank account.
    PayrollToBank = true,

    -- Write the job and grade catalogue of nitro_shared into the database so
    -- it can be edited at runtime.
    SyncCatalogueOnStart = true,

    -- Starting job of a new character.
    DefaultJob = 'unemployed',
    DefaultGrade = 0,
}
