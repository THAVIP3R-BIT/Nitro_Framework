fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_jobs'
author 'Nitro_Framework'
description 'Nitro_Framework employment: jobs, grades, duty and payroll.'
version '1.0.0'

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/jobs.lua',
    'server/payroll.lua',
    'server/exports.lua',
}

client_scripts {
    'client/jobs.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'
dependency 'nitro_core'
dependency 'nitro_players'
dependency 'nitro_banking'

exports {
    'GetJob',
    'GetGrades',
    'GetGrade',
    'SetJob',
    'SetGrade',
    'SetDuty',
    'IsOnDuty',
    'HasGradePermission',
    'GetOrganisation',
    'SetOrganisation',
    'SyncCatalogue',
    'RunPayroll',
}
