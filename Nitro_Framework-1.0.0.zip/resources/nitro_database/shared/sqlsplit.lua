--[[
    nitro_database :: shared/sqlsplit.lua

    A small, dependency free SQL statement splitter.

    MySQL's wire protocol rejects multi statement queries when the driver is
    not configured for them, so Nitro executes every statement of a migration
    file on its own. Splitting naively on `;` breaks on semicolons inside
    string literals and comments, which is why this splitter understands:

      * 'single quoted' strings (with '' and \' escapes)
      * "double quoted" strings
      * `backtick` identifiers
      * -- line comments and # line comments
      * /* block comments */

    The module is pure Lua and is unit tested in tests/specs/sqlsplit_spec.lua.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro = Nitro or {}
Nitro.Sql = Nitro.Sql or {}

--- Split a SQL script into individual statements.
--- @param script string
--- @return string[] statements (without the trailing semicolon, trimmed)
function Nitro.Sql.Split(script)
    local statements = {}
    if type(script) ~= 'string' then return statements end

    local buffer = {}
    local length = #script
    local index = 1

    local function flush()
        local candidate = table.concat(buffer):gsub('^%s+', ''):gsub('%s+$', '')
        if candidate ~= '' then
            statements[#statements + 1] = candidate
        end
        buffer = {}
    end

    while index <= length do
        local char = script:sub(index, index)
        local nextChar = script:sub(index + 1, index + 1)

        -- line comment
        if (char == '-' and nextChar == '-') or char == '#' then
            while index <= length and script:sub(index, index) ~= '\n' do
                index = index + 1
            end
        -- block comment
        elseif char == '/' and nextChar == '*' then
            index = index + 2
            while index <= length do
                if script:sub(index, index) == '*' and script:sub(index + 1, index + 1) == '/' then
                    index = index + 2
                    break
                end
                index = index + 1
            end
        -- quoted strings
        elseif char == "'" or char == '"' or char == '`' then
            local quote = char
            buffer[#buffer + 1] = char
            index = index + 1
            while index <= length do
                local current = script:sub(index, index)
                if current == '\\' then
                    buffer[#buffer + 1] = current
                    buffer[#buffer + 1] = script:sub(index + 1, index + 1)
                    index = index + 2
                elseif current == quote then
                    -- doubled quote is an escaped quote
                    if script:sub(index + 1, index + 1) == quote then
                        buffer[#buffer + 1] = quote
                        buffer[#buffer + 1] = quote
                        index = index + 2
                    else
                        buffer[#buffer + 1] = quote
                        index = index + 1
                        break
                    end
                else
                    buffer[#buffer + 1] = current
                    index = index + 1
                end
            end
        -- statement terminator
        elseif char == ';' then
            flush()
            index = index + 1
        else
            buffer[#buffer + 1] = char
            index = index + 1
        end
    end

    flush()
    return statements
end

--- Rolling checksum used to detect migration drift.
--- Kept to pure Lua (no bit library) so it can run inside the test harness.
--- The modulus is the largest prime below 2^31 and the modulo is floored, so
--- that the digest is an unsigned 31 bit integer on every Lua implementation.
--- @param content string
--- @return string 8 character hex digest
function Nitro.Sql.Checksum(content)
    if type(content) ~= 'string' then return '00000000' end
    local hash = 5381
    local modulus = 2147483647 -- 2^31 - 1
    for index = 1, #content do
        hash = math.floor((hash * 33 + content:byte(index)) % modulus)
    end
    return ('%08x'):format(hash)
end
