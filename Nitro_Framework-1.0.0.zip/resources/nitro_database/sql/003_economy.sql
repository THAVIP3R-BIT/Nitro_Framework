-- AUTO-GENERATED COPY - edit migrations/003_economy.sql and run "npm run sync:migrations".
-- =============================================================================
-- Nitro_Framework :: 003_economy.sql
-- Bank accounts and the immutable transaction ledger.
--
-- Every account of the framework lives in nitro_banking_accounts. The
-- `owner_type` / `owner_id` pair decides whose money it is:
--   character    -> owner_id is a character_id
--   organisation -> owner_id is an organisation name
--   business     -> owner_id is a business id
--
-- nitro_transactions is an append only ledger. `reference` is UNIQUE and is
-- used as an idempotency key, so a retried request can never move money
-- twice.
--
-- Relationships
--   nitro_banking_accounts.account_number <-> nitro_transactions.from_account
--                                             nitro_transactions.to_account
-- =============================================================================

CREATE TABLE IF NOT EXISTS `nitro_banking_accounts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `owner_type` VARCHAR(16) NOT NULL DEFAULT 'character',
  `owner_id` VARCHAR(64) NOT NULL,
  `account_number` VARCHAR(24) NOT NULL,
  `label` VARCHAR(64) NOT NULL DEFAULT 'Personal Account',
  `balance` BIGINT NOT NULL DEFAULT 0,
  `frozen` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_banking_accounts_number` (`account_number`),
  UNIQUE KEY `uq_nitro_banking_accounts_owner` (`owner_type`, `owner_id`),
  KEY `idx_nitro_banking_accounts_balance` (`balance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_transactions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `reference` VARCHAR(64) NOT NULL,
  `from_account` VARCHAR(24) NULL DEFAULT NULL,
  `to_account` VARCHAR(24) NULL DEFAULT NULL,
  `amount` BIGINT NOT NULL DEFAULT 0,
  `balance_after` BIGINT NULL DEFAULT NULL,
  `transaction_type` VARCHAR(32) NOT NULL DEFAULT 'transfer',
  `description` VARCHAR(191) NULL DEFAULT NULL,
  `actor` VARCHAR(64) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_transactions_reference` (`reference`),
  KEY `idx_nitro_transactions_from` (`from_account`),
  KEY `idx_nitro_transactions_to` (`to_account`),
  KEY `idx_nitro_transactions_type` (`transaction_type`),
  KEY `idx_nitro_transactions_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
