-- AUTO-GENERATED COPY - edit migrations/001_core.sql and run "npm run sync:migrations".
-- =============================================================================
-- Nitro_Framework :: 001_core.sql
-- Accounts and characters.
--
-- An "account" is a Rockstar licence owned by a player. An account can own
-- several characters, each with its own identity, wallet, job and metadata.
--
-- Money
--   `cash` is the physical money the character carries and is stored here.
--   The bank balance lives in `nitro_banking_accounts` (see 003_economy.sql)
--   so that exactly one resource - nitro_banking - ever writes a balance.
--
-- Relationships
--   nitro_accounts 1 --- * nitro_characters
--   nitro_characters.*.account_id -> nitro_accounts.id  (ON DELETE CASCADE)
-- =============================================================================

CREATE TABLE IF NOT EXISTS `nitro_accounts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `license` VARCHAR(64) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_accounts_license` (`license`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_characters` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `account_id` BIGINT UNSIGNED NOT NULL,
  `character_id` VARCHAR(32) NOT NULL,
  `first_name` VARCHAR(50) NOT NULL DEFAULT 'Firstname',
  `last_name` VARCHAR(50) NOT NULL DEFAULT 'Lastname',
  `date_of_birth` DATE NULL DEFAULT NULL,
  `gender` TINYINT NOT NULL DEFAULT 0,
  `nationality` VARCHAR(32) NOT NULL DEFAULT 'USA',
  `phone` VARCHAR(24) NULL DEFAULT NULL,
  `account_number` VARCHAR(24) NULL DEFAULT NULL,
  `job_name` VARCHAR(64) NOT NULL DEFAULT 'unemployed',
  `job_grade` TINYINT NOT NULL DEFAULT 0,
  `organisation_name` VARCHAR(64) NOT NULL DEFAULT 'none',
  `organisation_grade` TINYINT NOT NULL DEFAULT 0,
  `cash` BIGINT NOT NULL DEFAULT 0,
  `position` JSON NULL DEFAULT NULL,
  `metadata` JSON NULL DEFAULT NULL,
  `status` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_seen` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_characters_character_id` (`character_id`),
  UNIQUE KEY `uq_nitro_characters_phone` (`phone`),
  UNIQUE KEY `uq_nitro_characters_account_number` (`account_number`),
  KEY `idx_nitro_characters_account` (`account_id`),
  KEY `idx_nitro_characters_job` (`job_name`),
  KEY `idx_nitro_characters_organisation` (`organisation_name`),
  KEY `idx_nitro_characters_last_seen` (`last_seen`),
  CONSTRAINT `fk_nitro_characters_account`
    FOREIGN KEY (`account_id`) REFERENCES `nitro_accounts` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
