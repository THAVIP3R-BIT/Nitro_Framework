-- AUTO-GENERATED COPY - edit migrations/006_governance.sql and run "npm run sync:migrations".
-- =============================================================================
-- Nitro_Framework :: 006_governance.sql
-- Bans and the administrative audit trail.
--
-- nitro_admin_log is append only. It is written by nitro_admin whenever a
-- privileged action is executed and is the source of truth for "who did what".
-- Retention is handled by the configurable pruning job in nitro_admin.
-- =============================================================================

CREATE TABLE IF NOT EXISTS `nitro_bans` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `license` VARCHAR(64) NULL DEFAULT NULL,
  `discord` VARCHAR(64) NULL DEFAULT NULL,
  `ip` VARCHAR(45) NULL DEFAULT NULL,
  `name` VARCHAR(64) NULL DEFAULT NULL,
  `reason` TEXT NULL DEFAULT NULL,
  `expires_at` TIMESTAMP NULL DEFAULT NULL,
  `banned_by` VARCHAR(64) NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_nitro_bans_license` (`license`),
  KEY `idx_nitro_bans_discord` (`discord`),
  KEY `idx_nitro_bans_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_admin_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `actor_id` VARCHAR(32) NULL DEFAULT NULL,
  `actor_license` VARCHAR(64) NULL DEFAULT NULL,
  `action` VARCHAR(64) NOT NULL,
  `target` VARCHAR(64) NULL DEFAULT NULL,
  `details` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_nitro_admin_log_action` (`action`),
  KEY `idx_nitro_admin_log_actor` (`actor_id`),
  KEY `idx_nitro_admin_log_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
