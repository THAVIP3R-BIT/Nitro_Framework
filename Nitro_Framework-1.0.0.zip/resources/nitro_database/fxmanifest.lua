fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_database'
author 'Nitro_Framework'
description 'Nitro_Framework database integration. oxmysql is the only supported driver.'
version '1.0.0'

shared_scripts {
    'config.lua',
    'shared/sqlsplit.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/log.lua',
    'server/database.lua',
    'server/migrations.lua',
    'server/exports.lua'
}

dependency 'oxmysql'

files {
    'sql/*.sql'
}

exports {
    'GetVersion',
    'IsReady',
    'WaitForReady',
    'GetServerVersion',
    'Query',
    'Single',
    'Scalar',
    'Insert',
    'Update',
    'Prepare',
    'Transaction',
    'Raw',
    'RunMigrations',
    'GetMigrationStatus',
    'GetDiagnostics'
}
