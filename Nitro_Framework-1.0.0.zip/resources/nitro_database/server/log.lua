--[[
    nitro_database :: server/log.lua

    Self contained logger for nitro_database.

    nitro_database must be able to run on its own, without nitro_shared being
    loaded first, so it cannot rely on the shared `Nitro.Log` helper (every
    FiveM resource runs in its own Lua VM). The output format is identical to
    the shared logger so the console stays consistent.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Database = Nitro.Database or {}

Nitro.Database.Log = {}

local LEVELS = { debug = 1, info = 2, warn = 3, error = 4 }
local COLOURS = {
    debug = '^5',
    info = '^2',
    warn = '^3',
    error = '^1',
}

local Log = Nitro.Database.Log

--- @param level string
--- @return number
local function levelValue(level)
    return LEVELS[level] or LEVELS.info
end

--- Write a log line.
--- @param level string 'debug' | 'info' | 'warn' | 'error'
--- @param message string
function Log.write(level, message)
    local config = Nitro.Database.Config or {}
    local logging = config.Logging or {}
    local minLevel = levelValue(logging.Level or 'info')
    if levelValue(level) < minLevel then return end
    if level == 'debug' and not logging.Debug then return end
    local colour = COLOURS[level] or '^7'
    print(('%s%s[nitro_database][%s]^0 %s'):format(colour, tostring(logging.Prefix or '[Nitro]'), level:upper(), tostring(message)))
end

--- @param message string
function Log.debug(message)
    Log.write('debug', message)
end

--- @param message string
function Log.info(message)
    Log.write('info', message)
end

--- @param message string
function Log.warn(message)
    Log.write('warn', message)
end

--- @param message string
function Log.error(message)
    Log.write('error', message)
end
