--[[
    nitro_database :: server/exports.lua

    Public database API for Nitro resources.

    Every function documented here is part of the Nitro_Framework developer
    API - see docs/api-reference.md.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

--- @return string
exports('GetVersion', function()
    return Nitro.GetVersionString()
end)

--- @return boolean
exports('IsReady', function()
    return Nitro.Database.IsReady()
end)

--- @return boolean
exports('WaitForReady', function()
    return Nitro.Database.WaitForReady()
end)

--- @return string?
exports('GetServerVersion', function()
    return Nitro.Database.GetServerVersion()
end)

--- @param statement string
--- @param params table?
--- @return table
exports('Query', function(statement, params)
    return Nitro.Database.Query(statement, params)
end)

--- @param statement string
--- @param params table?
--- @return table?
exports('Single', function(statement, params)
    return Nitro.Database.Single(statement, params)
end)

--- @param statement string
--- @param params table?
--- @return any
exports('Scalar', function(statement, params)
    return Nitro.Database.Scalar(statement, params)
end)

--- @param statement string
--- @param params table?
--- @return number
exports('Insert', function(statement, params)
    return Nitro.Database.Insert(statement, params)
end)

--- @param statement string
--- @param params table?
--- @return number
exports('Update', function(statement, params)
    return Nitro.Database.Update(statement, params)
end)

--- @param statement string
--- @param params table?
--- @return any
exports('Prepare', function(statement, params)
    return Nitro.Database.Prepare(statement, params)
end)

--- @param queries table[]
--- @return boolean ok, any results
exports('Transaction', function(queries)
    return Nitro.Database.Transaction(queries)
end)

--- @param statement string
--- @return boolean ok, any result
exports('Raw', function(statement)
    return Nitro.Database.Raw(statement)
end)

--- @param options table?
--- @return boolean ok, table result
exports('RunMigrations', function(options)
    return Nitro.Database.RunMigrations(options)
end)

--- @return table[]
exports('GetMigrationStatus', function()
    return Nitro.Database.GetMigrationStatus()
end)

--- @return table
exports('GetDiagnostics', function()
    return Nitro.Database.GetDiagnostics()
end)
