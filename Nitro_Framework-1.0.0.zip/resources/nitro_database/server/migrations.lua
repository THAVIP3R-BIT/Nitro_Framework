--[[
    nitro_database :: server/migrations.lua

    Versioned, repeatable SQL migration runner.

    * Migrations live in `<resource>/sql/` and are declared, in order, in
      `Nitro.Database.Config.Migrations`.
    * Applied migrations are recorded in the `nitro_migrations` table so the
      runner is safe to execute on every boot.
    * A migration that has already been applied is never executed again.
    * A changed checksum is reported as drift (the runner refuses to silently
      re-apply a modified migration).
    * No migration in the bundled set drops, truncates or overwrites a table.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro = Nitro or {}
Nitro.Database = Nitro.Database or {}

local Config = Nitro.Database.Config
local resourceName = GetCurrentResourceName()

--- @class NitroMigration
--- @field version number
--- @field file string
--- @field name string
--- @field checksum string

--- Parse `001_core.sql` into a version + name pair.
--- @param file string
--- @return number? version, string? name
local function parseFileName(file)
    local version, name = tostring(file):match('^(%d+)_(.+)%.sql$')
    if not version then return nil, nil end
    return tonumber(version), name
end

--- Read the migration table contents.
--- @return table<string, table> applied migrations keyed by version
local function loadApplied()
    local applied = {}
    local rows = Nitro.Database.Query(('SELECT version, name, checksum, applied_at FROM `%s`'):format(Config.MigrationTable))
    for _, row in ipairs(rows) do
        applied[tostring(row.version)] = row
    end
    return applied
end

--- Create the migration bookkeeping table when it is missing.
local function ensureMigrationTable()
    Nitro.Database.Raw(([=[
CREATE TABLE IF NOT EXISTS `%s` (
  `version` INT NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `checksum` VARCHAR(32) NOT NULL DEFAULT '',
  `applied_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
]=]):format(Config.MigrationTable))
end

--- Execute every migration that has not been applied yet.
--- @param options { force: boolean? }?
--- @return boolean ok, table result { applied = {}, skipped = {}, failed = {} }
function Nitro.Database.RunMigrations(options)
    options = options or {}
    if not Nitro.Database.IsReady() then
        Nitro.Database.Log.error('cannot run migrations: no database connection', 'nitro_database')
        return false, { applied = {}, skipped = {}, failed = { 'no_connection' } }
    end

    ensureMigrationTable()
    local applied = loadApplied()
    local result = { applied = {}, skipped = {}, failed = {} }

    for _, file in ipairs(Config.Migrations or {}) do
        local version, name = parseFileName(file)
        if not version then
            Nitro.Database.Log.error(('invalid migration filename "%s"'):format(tostring(file)), 'nitro_database')
            result.failed[#result.failed + 1] = file
        else
            local path = ('%s/%s'):format(Config.MigrationDirectory, file)
            local content = LoadResourceFile(resourceName, path)
            if not content then
                Nitro.Database.Log.error(('migration file "%s" is missing from the resource'):format(path), 'nitro_database')
                result.failed[#result.failed + 1] = file
            else
                local checksum = Nitro.Sql.Checksum(content)
                local record = applied[tostring(version)]
                if record and not options.force then
                    if record.checksum ~= checksum then
                        Nitro.Database.Log.warn(('migration %s changed after it was applied (expected %s, found %s)')
                            :format(file, tostring(record.checksum), checksum), 'nitro_database')
                    end
                    result.skipped[#result.skipped + 1] = file
                else
                    local statements = Nitro.Sql.Split(content)
                    local failed = false
                    for index, statement in ipairs(statements) do
                        local ok = Nitro.Database.Raw(statement)
                        if not ok then
                            Nitro.Database.Log.error(('migration %s failed on statement %d'):format(file, index), 'nitro_database')
                            failed = true
                            break
                        end
                    end
                    if failed then
                        result.failed[#result.failed + 1] = file
                    else
                        Nitro.Database.Insert(
                            ('INSERT INTO `%s` (version, name, checksum) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), checksum = VALUES(checksum)')
                                :format(Config.MigrationTable),
                            { version, name or file, checksum }
                        )
                        result.applied[#result.applied + 1] = file
                        Nitro.Database.Log.info(('applied migration %s (%s)'):format(file, name or 'unnamed'), 'nitro_database')
                    end
                end
            end
        end
    end

    TriggerEvent('nitro:server:migrationsComplete', result)
    return #result.failed == 0, result
end

--- Report the state of every declared migration.
--- @return table[] list of { version, name, file, applied, appliedAt, checksum, current }
function Nitro.Database.GetMigrationStatus()
    local status = {}
    local applied = {}
    if Nitro.Database.IsReady() then
        applied = loadApplied()
    end
    for _, file in ipairs(Config.Migrations or {}) do
        local version, name = parseFileName(file)
        local content = LoadResourceFile(resourceName, ('%s/%s'):format(Config.MigrationDirectory, file))
        local record = applied[tostring(version)]
        status[#status + 1] = {
            version = version or 0,
            name = name or file,
            file = file,
            applied = record ~= nil,
            appliedAt = record and record.applied_at or nil,
            checksum = content and Nitro.Sql.Checksum(content) or nil,
            currentChecksum = record and record.checksum or nil,
            drifted = record and content and record.checksum ~= Nitro.Sql.Checksum(content) or false,
        }
    end
    return status
end

-- ── Automatic migration on startup ──────────────────────────────────────────

CreateThread(function()
    while not Nitro.Database.IsReady() do
        Wait(500)
    end
    -- Give the connection a moment to settle before touching the schema.
    Wait(1000)
    if not Config.AutoMigrate then
        Nitro.Database.Log.info('automatic migrations are disabled', 'nitro_database')
        return
    end
    local ok, result = Nitro.Database.RunMigrations()
    if ok then
        Nitro.Database.Log.info(('migrations complete (%d applied, %d already present)'):format(
            #result.applied, #result.skipped), 'nitro_database')
    else
        Nitro.Database.Log.error(('migrations failed: %s'):format(table.concat(result.failed, ', ')), 'nitro_database')
    end
end)
