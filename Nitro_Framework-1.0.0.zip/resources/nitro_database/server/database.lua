--[[
    nitro_database :: server/database.lua

    The single database entry point for Nitro_Framework.

    Every Nitro owned resource that needs persistence goes through this API,
    which in turn uses oxmysql. No other database driver is supported and no
    other resource is allowed to open its own connection.

    Design notes
    ------------
    * All statements are parameterised. The framework never concatenates
      untrusted input into SQL.
    * Every call is executed with oxmysql's coroutine friendly `.await`
      variant, so the server tick is never blocked: the thread yields while the
      query is in flight.
    * Errors are caught, counted and logged; a failed query never leaves a
      half written player row behind.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro = Nitro or {}
Nitro.Database = Nitro.Database or {}

local Config = Nitro.Database.Config

--- Runtime diagnostics, surfaced by the /nitro db command.
Nitro.Database.Diagnostics = {
    Queries = 0,
    Errors = 0,
    Transactions = 0,
    LastError = nil,
    Ready = false,
    ConnectedAt = nil,
    ServerVersion = nil,
}

-- ── Internal helpers ────────────────────────────────────────────────────────

--- Call an oxmysql function synchronously inside the current coroutine.
--- @param fn function oxmysql function
--- @param ... any
--- @return any
local function call(fn, ...)
    if type(fn) ~= 'function' then
        Nitro.Database.Log.error('oxmysql function is not available', 'nitro_database')
        return nil
    end
    if fn.await then
        return fn.await(...)
    end
    return Citizen.Await(fn(...))
end

--- Increment counters and record the last error.
--- @param context string
--- @param err any
local function recordError(context, err)
    Nitro.Database.Diagnostics.Errors = Nitro.Database.Diagnostics.Errors + 1
    Nitro.Database.Diagnostics.LastError = ('%s: %s'):format(context, tostring(err))
    Nitro.Database.Log.error(('%s failed: %s'):format(context, tostring(err)), 'nitro_database')
end

--- Print a statement when query logging is enabled.
--- @param statement string
--- @param params table?
local function trace(statement, params)
    if not Config.LogQueries then return end
    Nitro.Database.Log.debug(('%s %s'):format(statement, params and json.encode(params) or ''), 'nitro_database')
end

-- ── Connection lifecycle ────────────────────────────────────────────────────

--- Resolve once oxmysql reports the connection is ready.
--- @return boolean ready
function Nitro.Database.WaitForReady()
    if Nitro.Database.Diagnostics.Ready then return true end
    if not MySQL or not MySQL.ready then
        -- Very old oxmysql builds have no ready callback; assume ready.
        Nitro.Database.Diagnostics.Ready = true
        return true
    end
    MySQL.ready(function()
        Nitro.Database.Diagnostics.Ready = true
        Nitro.Database.Diagnostics.ConnectedAt = os.time()
        Nitro.Database.Log.info('database connection established', 'nitro_database')
        TriggerEvent('nitro:server:databaseReady')
    end)
    return Nitro.Database.Diagnostics.Ready
end

--- True when the database connection is usable.
--- @return boolean
function Nitro.Database.IsReady()
    return Nitro.Database.Diagnostics.Ready == true
end

--- Read the connected database server version.
--- @return string?
function Nitro.Database.GetServerVersion()
    if Nitro.Database.Diagnostics.ServerVersion then
        return Nitro.Database.Diagnostics.ServerVersion
    end
    local ok, result = pcall(function()
        return call(MySQL.scalar, 'SELECT VERSION()')
    end)
    if ok and result then
        Nitro.Database.Diagnostics.ServerVersion = tostring(result)
    end
    return Nitro.Database.Diagnostics.ServerVersion
end

-- ── Query API ───────────────────────────────────────────────────────────────

--- Run a SELECT that returns rows.
--- @param statement string SQL using `?` placeholders
--- @param params table? array of bound values
--- @return table rows
function Nitro.Database.Query(statement, params)
    if type(statement) ~= 'string' or statement == '' then return {} end
    params = params or {}
    trace(statement, params)
    Nitro.Database.Diagnostics.Queries = Nitro.Database.Diagnostics.Queries + 1
    local ok, result = pcall(function()
        return call(MySQL.query, statement, params)
    end)
    if not ok then
        recordError('query', result)
        return {}
    end
    return result or {}
end

--- Run a SELECT that returns a single row.
--- @param statement string
--- @param params table?
--- @return table? row
function Nitro.Database.Single(statement, params)
    if type(statement) ~= 'string' or statement == '' then return nil end
    params = params or {}
    trace(statement, params)
    Nitro.Database.Diagnostics.Queries = Nitro.Database.Diagnostics.Queries + 1
    local ok, result = pcall(function()
        return call(MySQL.single, statement, params)
    end)
    if not ok then
        recordError('single', result)
        return nil
    end
    return result
end

--- Run a SELECT that returns a single scalar value.
--- @param statement string
--- @param params table?
--- @return any
function Nitro.Database.Scalar(statement, params)
    if type(statement) ~= 'string' or statement == '' then return nil end
    params = params or {}
    trace(statement, params)
    Nitro.Database.Diagnostics.Queries = Nitro.Database.Diagnostics.Queries + 1
    local ok, result = pcall(function()
        return call(MySQL.scalar, statement, params)
    end)
    if not ok then
        recordError('scalar', result)
        return nil
    end
    return result
end

--- Insert a row.
--- @param statement string
--- @param params table?
--- @return number? insert id (0 when the insert produced no id)
function Nitro.Database.Insert(statement, params)
    if type(statement) ~= 'string' or statement == '' then return 0 end
    params = params or {}
    trace(statement, params)
    Nitro.Database.Diagnostics.Queries = Nitro.Database.Diagnostics.Queries + 1
    local ok, result = pcall(function()
        return call(MySQL.insert, statement, params)
    end)
    if not ok then
        recordError('insert', result)
        return 0
    end
    return tonumber(result) or 0
end

--- Run an UPDATE / DELETE.
--- @param statement string
--- @param params table?
--- @return number affected rows
function Nitro.Database.Update(statement, params)
    if type(statement) ~= 'string' or statement == '' then return 0 end
    params = params or {}
    trace(statement, params)
    Nitro.Database.Diagnostics.Queries = Nitro.Database.Diagnostics.Queries + 1
    local ok, result = pcall(function()
        return call(MySQL.update, statement, params)
    end)
    if not ok then
        recordError('update', result)
        return 0
    end
    return tonumber(result) or 0
end

--- Run a prepared statement.
--- @param statement string
--- @param params table?
--- @return any
function Nitro.Database.Prepare(statement, params)
    if type(statement) ~= 'string' or statement == '' then return nil end
    params = params or {}
    trace(statement, params)
    Nitro.Database.Diagnostics.Queries = Nitro.Database.Diagnostics.Queries + 1
    local ok, result = pcall(function()
        return call(MySQL.prepare, statement, params)
    end)
    if not ok then
        recordError('prepare', result)
        return nil
    end
    return result
end

--- Execute a raw statement (no bound parameters).
--- Reserved for the migration runner - never call this with user input.
--- @param statement string
--- @return boolean ok, any result
function Nitro.Database.Raw(statement)
    if type(statement) ~= 'string' or statement == '' then return false, 'invalid_statement' end
    trace(statement)
    Nitro.Database.Diagnostics.Queries = Nitro.Database.Diagnostics.Queries + 1
    local ok, result = pcall(function()
        return call(MySQL.query, statement)
    end)
    if not ok then
        recordError('raw', result)
        return false, result
    end
    return true, result
end

--- Execute several statements inside a single database transaction.
--- Either every statement succeeds or the transaction is rolled back.
--- @param queries table[] list of { query = string, values = table? }
--- @return boolean ok, any results
function Nitro.Database.Transaction(queries)
    if type(queries) ~= 'table' or #queries == 0 then return false, 'no_queries' end
    Nitro.Database.Diagnostics.Transactions = Nitro.Database.Diagnostics.Transactions + 1

    local payload = {}
    for index, entry in ipairs(queries) do
        if type(entry) ~= 'table' or type(entry.query) ~= 'string' then
            recordError('transaction', ('invalid entry at index %d'):format(index))
            return false, 'invalid_query'
        end
        payload[index] = { query = entry.query, values = entry.values or {} }
        trace(entry.query, entry.values)
    end

    local ok, result = pcall(function()
        return call(MySQL.transaction, payload)
    end)
    if not ok then
        recordError('transaction', result)
        return false, result
    end
    return true, result
end

--- Convenience wrapper: run a transaction and return the results.
--- @param queries table[]
--- @return boolean ok, any results
function Nitro.Database.RunTransaction(queries)
    return Nitro.Database.Transaction(queries)
end

--- Public diagnostics snapshot.
--- @return table
function Nitro.Database.GetDiagnostics()
    local diagnostics = Nitro.Database.Diagnostics
    return {
        ready = diagnostics.Ready,
        queries = diagnostics.Queries,
        errors = diagnostics.Errors,
        transactions = diagnostics.Transactions,
        lastError = diagnostics.LastError,
        serverVersion = Nitro.Database.GetServerVersion(),
        connectedAt = diagnostics.ConnectedAt,
    }
end

-- Kick the readiness handshake as soon as the resource loads.
CreateThread(function()
    for attempt = 1, (Config.ConnectionRetries or 1) do
        Nitro.Database.WaitForReady()
        if Nitro.Database.IsReady() then return end
        Nitro.Database.Log.warn(('database not ready (attempt %d/%d)'):format(attempt, Config.ConnectionRetries or 1), 'nitro_database')
        Wait(Config.ConnectionRetryDelay or 2000)
    end
    if not Nitro.Database.IsReady() then
        Nitro.Database.Log.error('no database connection - check your mysql_connection_string', 'nitro_database')
    end
end)
