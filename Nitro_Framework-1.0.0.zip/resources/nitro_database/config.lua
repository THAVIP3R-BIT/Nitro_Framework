--[[
    nitro_database :: config.lua

    Database configuration for Nitro_Framework.

    Connection credentials are NEVER stored here. They are supplied by the
    server owner through `set mysql_connection_string "..."` in server.cfg, which
    is read by oxmysql itself.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
]]

Nitro = Nitro or {}
Nitro.Database = Nitro.Database or {}
Nitro.Database.Config = {

    -- Run the bundled SQL migrations automatically when the resource starts.
    -- Set to false if you prefer to apply migrations by hand.
    AutoMigrate = true,

    -- Table that records which migrations have been applied.
    MigrationTable = 'nitro_migrations',

    -- Directory (inside this resource) holding the versioned SQL migrations.
    -- The canonical copies live in <repo>/migrations and are synced into this
    -- folder by `npm run sync:migrations`.
    MigrationDirectory = 'sql',

    -- Print every statement that is executed (contains bound values, keep off
    -- on production servers).
    LogQueries = false,

    -- Maximum time (ms) to wait for the initial connection before the
    -- framework reports the database as unavailable.
    ConnectionTimeout = 15000,

    -- Retry the connection this many times before giving up.
    ConnectionRetries = 3,

    -- Delay between retries (ms).
    ConnectionRetryDelay = 2000,

    -- Table prefix used by the framework when it creates its own tables.
    -- Every table name in the bundled migrations already starts with `nitro_`.
    TablePrefix = 'nitro_',

    -- The diagnostics are exposed through the `GetDiagnostics` export and
    -- printed by the `/nitro db` command of nitro_core.

    -- Ordered list of the migrations that ship with the framework.
    -- The canonical files live in <repo>/migrations and are synced into this
    -- resource with `npm run sync:migrations`.
    Migrations = {
        '001_core.sql',
        '002_inventory.sql',
        '003_economy.sql',
        '004_employment.sql',
        '005_world.sql',
        '006_governance.sql',
    },
}
