fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_admin'
author 'Nitro_Framework'
description 'Nitro_Framework administration: moderation, logging and staff tools.'
version '1.0.0'

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/logging.lua',
    'server/moderation.lua',
    'server/actions.lua',
    'server/exports.lua',
}

client_scripts {
    'client/actions.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'
dependency 'nitro_core'
dependency 'nitro_players'
dependency 'nitro_banking'
dependency 'nitro_jobs'

exports {
    'IsAdmin',
    'HasPermission',
    'Ban',
    'Unban',
    'Kick',
    'Warn',
    'GetBans',
    'IsBanned',
    'GetLog',
    'WriteLog',
    'Teleport',
    'SetJob',
    'GiveMoney',
    'Revive',
}
