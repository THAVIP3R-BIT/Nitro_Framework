--[[
    nitro_admin :: server/moderation.lua

    Bans, kicks and warnings.

    A ban is stored in nitro_bans and checked while a player connects.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Admin = Nitro.Admin or {}

Nitro.Admin.Moderation = {}

local Moderation = Nitro.Admin.Moderation

--- The identifiers of a player.
--- @param src number
--- @return table
local function getIdentifiers(src)
    return exports.nitro_core:GetPlayerIdentifiers(src) or {}
end

--- Ban a player.
--- @param src number the staff member
--- @param targetSrc number? the player to ban, or nil when a licence is used
--- @param reason string?
--- @param hours number?
--- @param license string?
--- @return boolean ok, string? error
function Moderation.Ban(src, targetSrc, reason, hours, license)
    local actor = exports.nitro_players:GetPlayerData(src)
    local actorId = actor and actor.characterId or nil

    local identifiers = {}
    local name = nil

    if targetSrc then
        identifiers = getIdentifiers(targetSrc)
        name = GetPlayerName(targetSrc)
    elseif type(license) == 'string' then
        identifiers.license = license
    else
        return false, 'invalid_target'
    end

    if not identifiers.license then return false, 'no_license' end

    hours = tonumber(hours) or Nitro.Admin.Config.DefaultBanHours or 0
    local expiresAt = nil
    if hours > 0 then
        expiresAt = os.date('%Y-%m-%d %H:%M:%S', os.time() + math.floor(hours) * 3600)
    end

    exports.nitro_database:Insert(
        'INSERT INTO nitro_bans (license, discord, ip, name, reason, expires_at, banned_by) VALUES (?, ?, ?, ?, ?, ?, ?)',
        {
            identifiers.license,
            identifiers.discord,
            identifiers.ip,
            name,
            reason or Nitro.Admin.Config.DefaultBanReason,
            expiresAt,
            actorId,
        }
    )

    if targetSrc then
        DropPlayer(targetSrc, ('You have been banned.\nReason: %s'):format(reason or Nitro.Admin.Config.DefaultBanReason))
    end

    Nitro.Admin.Logging.Write(actorId, 'ban', identifiers.license, {
        reason = reason,
        hours = hours,
        name = name,
    })
    return true, nil
end

--- Remove a ban.
--- @param src number
--- @param license string
--- @return boolean ok, string? error
function Moderation.Unban(src, license)
    local actor = exports.nitro_players:GetPlayerData(src)
    local actorId = actor and actor.characterId or nil

    local affected = exports.nitro_database:Update(
        'DELETE FROM nitro_bans WHERE license = ?',
        { license }
    )
    if affected == 0 then return false, 'not_found' end

    Nitro.Admin.Logging.Write(actorId, 'unban', license, {})
    return true, nil
end

--- Every active ban.
--- @return table[]
function Moderation.GetBans()
    return exports.nitro_database:Query(
        'SELECT * FROM nitro_bans WHERE expires_at IS NULL OR expires_at > NOW() ORDER BY id DESC',
        {}
    ) or {}
end

--- Is a licence banned?
--- @param license string
--- @return boolean banned, table? ban
function Moderation.IsBanned(license)
    if type(license) ~= 'string' or license == '' then return false, nil end
    local ban = exports.nitro_database:Single(
        'SELECT * FROM nitro_bans WHERE license = ? AND (expires_at IS NULL OR expires_at > NOW()) ORDER BY id DESC LIMIT 1',
        { license }
    )
    if not ban then return false, nil end
    return true, ban
end

--- Kick a player.
--- @param src number
--- @param targetSrc number
--- @param reason string?
--- @return boolean ok, string? error
function Moderation.Kick(src, targetSrc, reason)
    local actor = exports.nitro_players:GetPlayerData(src)
    local actorId = actor and actor.characterId or nil

    if not targetSrc or not GetPlayerName(targetSrc) then return false, 'invalid_target' end

    DropPlayer(targetSrc, reason or 'You have been kicked from the server.')
    Nitro.Admin.Logging.Write(actorId, 'kick', tostring(targetSrc), { reason = reason })
    return true, nil
end

--- Warn a player.
--- @param src number
--- @param targetSrc number
--- @param reason string?
--- @return boolean ok, string? error
function Moderation.Warn(src, targetSrc, reason)
    local actor = exports.nitro_players:GetPlayerData(src)
    local actorId = actor and actor.characterId or nil

    if not targetSrc or not GetPlayerName(targetSrc) then return false, 'invalid_target' end

    local target = exports.nitro_players:GetPlayerData(targetSrc)
    local targetId = target and target.characterId or tostring(targetSrc)

    TriggerClientEvent('nitro:client:adminWarning', targetSrc, reason or 'You have been warned.')
    Nitro.Admin.Logging.Write(actorId, 'warn', targetId, { reason = reason })
    return true, nil
end
