--[[
    nitro_admin :: server/logging.lua

    The administrative audit trail.

    Every privileged action writes a row to nitro_admin_log. The table is
    append only - nothing in the framework ever updates or deletes a row.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Admin = Nitro.Admin or {}

Nitro.Admin.Logging = {}

local Logging = Nitro.Admin.Logging

--- Write a log entry.
--- @param actorId string? the character id of the staff member
--- @param action string
--- @param target string?
--- @param details table?
--- @return boolean written
function Logging.Write(actorId, action, target, details)
    if type(action) ~= 'string' or action == '' then return false end

    local license = nil
    if actorId then
        local src = exports.nitro_players:GetSrcByCharacterId(actorId)
        if src then
            local identifiers = exports.nitro_core:GetPlayerIdentifiers(src)
            license = identifiers and identifiers.license or nil
        end
    end

    local insertId = exports.nitro_database:Insert(
        'INSERT INTO nitro_admin_log (actor_id, actor_license, action, target, details) VALUES (?, ?, ?, ?, ?)',
        {
            actorId,
            license,
            action,
            target,
            details and json.encode(details) or json.encode({}),
        }
    )
    return insertId ~= nil and insertId ~= 0
end

--- The most recent log entries.
--- @param limit number?
--- @param action string?
--- @return table[]
function Logging.Get(limit, action)
    limit = math.min(tonumber(limit) or Nitro.Admin.Config.LogHistory, 500)
    if type(action) == 'string' and action ~= '' then
        return exports.nitro_database:Query(
            'SELECT * FROM nitro_admin_log WHERE action = ? ORDER BY id DESC LIMIT ' .. limit,
            { action }
        ) or {}
    end
    return exports.nitro_database:Query(
        'SELECT * FROM nitro_admin_log ORDER BY id DESC LIMIT ' .. limit,
        {}
    ) or {}
end

--- Remove log entries that are older than the configured retention.
--- @return number removed
function Logging.Prune()
    local days = tonumber(Nitro.Admin.Config.LogRetentionDays) or 0
    if days <= 0 then return 0 end
    local affected = exports.nitro_database:Update(
        'DELETE FROM nitro_admin_log WHERE created_at < (NOW() - INTERVAL ? DAY)',
        { days }
    )
    return affected or 0
end
