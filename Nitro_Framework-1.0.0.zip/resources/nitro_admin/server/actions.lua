--[[
    nitro_admin :: server/actions.lua

    Staff actions that change the world: teleports, jobs, money and revives.

    Every action is checked against the ace permissions and written to the
    administrative log.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Admin = Nitro.Admin or {}

Nitro.Admin.Actions = {}

local Actions = Nitro.Admin.Actions

--- The character id of a player.
--- @param src number
--- @return string?
local function characterIdOf(src)
    local data = exports.nitro_players:GetPlayerData(src)
    return data and data.characterId or nil
end

--- Teleport a player to another player.
--- @param src number
--- @param targetSrc number
--- @return boolean ok, string? error
function Actions.Teleport(src, targetSrc)
    if not targetSrc or not GetPlayerName(targetSrc) then return false, 'invalid_target' end
    local actorId = characterIdOf(src)
    local targetId = characterIdOf(targetSrc)

    TriggerClientEvent('nitro:client:teleportToPlayer', src, targetSrc)
    Nitro.Admin.Logging.Write(actorId, 'teleport', targetId, { targetSrc = targetSrc })
    return true, nil
end

--- Set the job of a player.
--- @param src number
--- @param targetSrc number
--- @param jobName string
--- @param grade number?
--- @return boolean ok, string? error
function Actions.SetJob(src, targetSrc, jobName, grade)
    local ok, _, err = exports.nitro_jobs:SetJob(targetSrc, jobName, grade)
    if not ok then return false, err end

    local actorId = characterIdOf(src)
    local targetId = characterIdOf(targetSrc)
    Nitro.Admin.Logging.Write(actorId, 'setjob', targetId, { job = jobName, grade = grade })
    return true, nil
end

--- Give money to a player.
--- @param src number
--- @param targetSrc number
--- @param amount number
--- @param kind string 'cash' | 'bank'
--- @return boolean ok, string? error
function Actions.GiveMoney(src, targetSrc, amount, kind)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, 'invalid_amount' end

    local targetId = characterIdOf(targetSrc)
    if not targetId then return false, 'no_character' end

    local ok
    if kind == 'bank' then
        ok = exports.nitro_banking:AddBank('character', targetId, amount, 'Administrative grant')
    else
        ok = exports.nitro_banking:AddCash(targetId, amount, 'Administrative grant')
    end
    if not ok then return false, 'grant_failed' end

    local actorId = characterIdOf(src)
    Nitro.Admin.Logging.Write(actorId, 'give_money', targetId, { amount = amount, kind = kind })
    return true, nil
end

--- Revive a player.
--- @param src number
--- @param targetSrc number
--- @return boolean ok, string? error
function Actions.Revive(src, targetSrc)
    if not targetSrc or not GetPlayerName(targetSrc) then return false, 'invalid_target' end
    local actorId = characterIdOf(src)
    local targetId = characterIdOf(targetSrc)
    TriggerClientEvent('nitro:client:revive', targetSrc)
    Nitro.Admin.Logging.Write(actorId, 'revive', targetId, {})
    return true, nil
end
