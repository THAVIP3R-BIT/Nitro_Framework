--[[
    nitro_admin :: server/exports.lua

    Public server API of nitro_admin and the staff commands.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Admin = Nitro.Admin or {}

local Moderation = Nitro.Admin.Moderation
local Logging = Nitro.Admin.Logging
local Actions = Nitro.Admin.Actions

--- Is a player staff?
--- @param src number
--- @return boolean
exports('IsAdmin', function(src)
    return exports.nitro_core:IsPlayerAdmin(src)
end)

--- Does a player hold a permission?
--- @param src number
--- @param permission string
--- @return boolean
exports('HasPermission', function(src, permission)
    return exports.nitro_core:HasPermission(src, permission)
end)

--- Ban a player.
--- @param src number
--- @param targetSrc number?
--- @param reason string?
--- @param hours number?
--- @param license string?
--- @return boolean ok, string? error
exports('Ban', function(src, targetSrc, reason, hours, license)
    return Moderation.Ban(src, targetSrc, reason, hours, license)
end)

--- Remove a ban.
--- @param src number
--- @param license string
--- @return boolean ok, string? error
exports('Unban', function(src, license)
    return Moderation.Unban(src, license)
end)

--- Kick a player.
--- @param src number
--- @param targetSrc number
--- @param reason string?
--- @return boolean ok, string? error
exports('Kick', function(src, targetSrc, reason)
    return Moderation.Kick(src, targetSrc, reason)
end)

--- Warn a player.
--- @param src number
--- @param targetSrc number
--- @param reason string?
--- @return boolean ok, string? error
exports('Warn', function(src, targetSrc, reason)
    return Moderation.Warn(src, targetSrc, reason)
end)

--- Every active ban.
--- @return table[]
exports('GetBans', function()
    return Moderation.GetBans()
end)

--- Is a licence banned?
--- @param license string
--- @return boolean banned, table? ban
exports('IsBanned', function(license)
    return Moderation.IsBanned(license)
end)

--- The most recent log entries.
--- @param limit number?
--- @param action string?
--- @return table[]
exports('GetLog', function(limit, action)
    return Logging.Get(limit, action)
end)

--- Write a log entry.
--- @param actorId string?
--- @param action string
--- @param target string?
--- @param details table?
--- @return boolean
exports('WriteLog', function(actorId, action, target, details)
    return Logging.Write(actorId, action, target, details)
end)

--- Teleport a player to another player.
--- @param src number
--- @param targetSrc number
--- @return boolean ok, string? error
exports('Teleport', function(src, targetSrc)
    return Actions.Teleport(src, targetSrc)
end)

--- Set the job of a player.
--- @param src number
--- @param targetSrc number
--- @param jobName string
--- @param grade number?
--- @return boolean ok, string? error
exports('SetJob', function(src, targetSrc, jobName, grade)
    return Actions.SetJob(src, targetSrc, jobName, grade)
end)

--- Give money to a player.
--- @param src number
--- @param targetSrc number
--- @param amount number
--- @param kind string?
--- @return boolean ok, string? error
exports('GiveMoney', function(src, targetSrc, amount, kind)
    return Actions.GiveMoney(src, targetSrc, amount, kind)
end)

--- Revive a player.
--- @param src number
--- @param targetSrc number
--- @return boolean ok, string? error
exports('Revive', function(src, targetSrc)
    return Actions.Revive(src, targetSrc)
end)

-- ── Staff commands ───────────────────────────────────────────────────────────

--- Resolve a player id from a name or an id.
--- @param value string
--- @return number?
local function resolveTarget(value)
    if type(value) ~= 'string' then return nil end
    local id = tonumber(value)
    if id and GetPlayerName(id) then return id end
    for _, player in ipairs(GetPlayers()) do
        local src = tonumber(player)
        if src and GetPlayerName(src) and GetPlayerName(src):lower():find(value:lower(), 1, true) then
            return src
        end
    end
    return nil
end

--- Reply to a staff member.
--- @param src number
--- @param message string
local function reply(src, message)
    TriggerClientEvent('nitro:ui:notification', src, { type = 'info', message = message })
end

for command, permission in pairs(Nitro.Admin.Config.Commands or {}) do
    RegisterCommand(command, function(src, args)
        if src == 0 then return end
        if not exports.nitro_core:HasPermission(src, permission) then
            reply(src, 'You do not have permission to use this command.')
            return
        end

        if command == 'admin' then
            TriggerClientEvent('nitro:ui:openAdminMenu', src)
            return
        end

        if command == 'ban' then
            local target = resolveTarget(args[1])
            if not target then
                reply(src, 'Unknown player.')
                return
            end
            local reason = table.concat(args, ' ')
            local ok, err = Moderation.Ban(src, target, reason ~= '' and reason or nil)
            reply(src, ok and ('Banned %s.'):format(GetPlayerName(target)) or ('Ban failed: %s'):format(err))
            return
        end

        if command == 'unban' then
            local license = args[1]
            if not license then
                reply(src, 'Usage: /unban <licence>')
                return
            end
            local ok, err = Moderation.Unban(src, license)
            reply(src, ok and 'Ban removed.' or ('Unban failed: %s'):format(err))
            return
        end

        if command == 'kick' then
            local target = resolveTarget(args[1])
            if not target then
                reply(src, 'Unknown player.')
                return
            end
            local reason = table.concat(args, ' ')
            local ok, err = Moderation.Kick(src, target, reason ~= '' and reason or nil)
            reply(src, ok and ('Kicked %s.'):format(GetPlayerName(target)) or ('Kick failed: %s'):format(err))
            return
        end

        if command == 'warn' then
            local target = resolveTarget(args[1])
            if not target then
                reply(src, 'Unknown player.')
                return
            end
            local reason = table.concat(args, ' ')
            local ok, err = Moderation.Warn(src, target, reason ~= '' and reason or nil)
            reply(src, ok and ('Warned %s.'):format(GetPlayerName(target)) or ('Warn failed: %s'):format(err))
            return
        end

        if command == 'tp' then
            local target = resolveTarget(args[1])
            if not target then
                reply(src, 'Unknown player.')
                return
            end
            local ok, err = Actions.Teleport(src, target)
            reply(src, ok and 'Teleported.' or ('Teleport failed: %s'):format(err))
            return
        end

        if command == 'setjob' then
            local target = resolveTarget(args[1])
            local jobName = args[2]
            local grade = tonumber(args[3]) or 0
            if not target or not jobName then
                reply(src, 'Usage: /setjob <player> <job> [grade]')
                return
            end
            local ok, err = Actions.SetJob(src, target, jobName, grade)
            reply(src, ok and 'Job updated.' or ('Job update failed: %s'):format(err))
            return
        end

        if command == 'givecash' or command == 'givebank' then
            local target = resolveTarget(args[1])
            local amount = tonumber(args[2])
            if not target or not amount then
                reply(src, ('Usage: /%s <player> <amount>'):format(command))
                return
            end
            local kind = command == 'givebank' and 'bank' or 'cash'
            local ok, err = Actions.GiveMoney(src, target, amount, kind)
            reply(src, ok and ('Gave %s to %s.'):format(amount, GetPlayerName(target)) or ('Grant failed: %s'):format(err))
            return
        end

        if command == 'revive' then
            local target = resolveTarget(args[1])
            if not target then
                reply(src, 'Unknown player.')
                return
            end
            local ok, err = Actions.Revive(src, target)
            reply(src, ok and 'Player revived.' or ('Revive failed: %s'):format(err))
            return
        end
    end, false)
end

-- Check the bans while a player connects.
AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    deferrals.defer()
    Wait(0)

    local src = source
    local license = nil
    for _, identifier in ipairs(GetPlayerIdentifiers(src) or {}) do
        local prefix, value = identifier:match('^([^:]+):(.+)$')
        if prefix == 'license' or prefix == 'license2' then
            license = value
            break
        end
    end
    if not license then return end

    local banned, ban = Moderation.IsBanned(license)
    if not banned then return end

    deferrals.done(('You are banned from this server.\nReason: %s'):format(ban.reason or 'No reason given.'))
end)

-- ── Callbacks ────────────────────────────────────────────────────────────────

exports.nitro_core:RegisterCallback('nitro:admin:getLog', function(src)
    if not exports.nitro_core:HasPermission(src, Nitro.Admin.Config.Permission) then
        return false, 'no_permission'
    end
    return Logging.Get(50)
end)

exports.nitro_core:RegisterCallback('nitro:admin:getBans', function(src)
    if not exports.nitro_core:HasPermission(src, Nitro.Admin.Config.Permission) then
        return false, 'no_permission'
    end
    return Moderation.GetBans()
end)
