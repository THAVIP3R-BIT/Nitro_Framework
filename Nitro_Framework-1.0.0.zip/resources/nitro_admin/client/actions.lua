--[[
    nitro_admin :: client/actions.lua

    Client side of the staff tools.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Admin = Nitro.Admin or {}

local playerPosition = nil

--- Teleport to another player.
RegisterNetEvent('nitro:client:teleportToPlayer', function(targetSrc)
    local targetPed = GetPlayerPed(targetSrc)
    if not targetPed or targetPed == 0 then return end
    local coords = GetEntityCoords(targetPed)
    local ped = PlayerPedId()
    SetEntityCoords(ped, coords.x + 1.0, coords.y + 1.0, coords.z, false, false, false, false)
    TriggerEvent('nitro:ui:notification', { type = 'info', message = 'Teleported.' })
end)

--- Revive the player.
RegisterNetEvent('nitro:client:revive', function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local isDead = playerPosition ~= nil
    if isDead then
        SetEntityCoords(ped, playerPosition.x, playerPosition.y, playerPosition.z, false, false, false, false)
        playerPosition = nil
    end
    SetEntityHealth(ped, GetEntityMaxHealth(ped))
    ClearPedTasksImmediately(ped)
    TriggerEvent('nitro:ui:notification', { type = 'success', message = 'You have been revived.' })
end)

--- Remember the position of a dead player so the revive can bring them back.
CreateThread(function()
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        if IsEntityDead(ped) then
            if not playerPosition then
                playerPosition = GetEntityCoords(ped)
            end
        end
    end
end)

--- Show a warning that a staff member issued.
RegisterNetEvent('nitro:client:adminWarning', function(reason)
    TriggerEvent('nitro:ui:notification', {
        type = 'warning',
        message = ('Warning: %s'):format(reason),
        duration = 8000,
    })
end)
