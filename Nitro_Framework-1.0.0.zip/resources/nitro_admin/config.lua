--[[
    nitro_admin :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Admin = Nitro.Admin or {}

Nitro.Admin.Config = {
    -- Permission that is required for the moderation commands.
    Permission = 'admin',

    -- Permission that is required for the powerful commands (money, job,
    -- teleport to a player).
    SeniorPermission = 'superadmin',

    -- How many log entries are kept for the in game log view.
    LogHistory = 100,

    -- Reason that is shown when a player is banned without a reason.
    DefaultBanReason = 'Breaking the server rules.',

    -- Number of hours a temporary ban lasts when no duration is given.
    DefaultBanHours = 0,

    -- Remove log entries that are older than this many days.
    -- 0 disables the clean up.
    LogRetentionDays = 90,

    -- Commands that only staff members may use.
    Commands = {
        ['admin'] = 'admin',
        ['ban'] = 'admin',
        ['unban'] = 'admin',
        ['kick'] = 'admin',
        ['warn'] = 'admin',
        ['tp'] = 'admin',
        ['setjob'] = 'superadmin',
        ['givecash'] = 'superadmin',
        ['givebank'] = 'superadmin',
        ['revive'] = 'admin',
    },
}
