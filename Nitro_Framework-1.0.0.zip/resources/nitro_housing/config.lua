--[[
    nitro_housing :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Housing = Nitro.Housing or {}

Nitro.Housing.Config = {
    -- Price of a property, per tier.
    Prices = {
        standard = 50000,
        premium = 150000,
        luxury = 400000,
    },

    -- Percentage of the price that is paid back when a property is sold.
    SellReturn = 0.8,

    -- Access levels a character can be given.
    AccessLevels = {
        shared = true,
        resident = true,
        owner = true,
    },
}
