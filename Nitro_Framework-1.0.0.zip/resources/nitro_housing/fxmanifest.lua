fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_housing'
author 'Nitro_Framework'
description 'Nitro_Framework housing: properties, ownership and access.'
version '1.0.0'

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/properties.lua',
    'server/events.lua',
    'server/exports.lua',
}

client_scripts {
    'client/properties.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'
dependency 'nitro_core'
dependency 'nitro_players'
dependency 'nitro_banking'

exports {
    'GetProperty',
    'GetProperties',
    'GetOwnedProperties',
    'CreateProperty',
    'BuyProperty',
    'SellProperty',
    'GetAccess',
    'GrantAccess',
    'RevokeAccess',
    'CanAccess',
    'EnterProperty',
}
