--[[
    nitro_housing :: client/properties.lua

    Client side housing helpers: markers for properties and the teleport
    into a property.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Housing = Nitro.Housing or {}

Nitro.Housing.Client = {}

local Client = Nitro.Housing.Client

local properties = {}

--- Load the property list from the server.
function Client.Refresh()
    exports.nitro_core:TriggerCallback('nitro:housing:getProperties', function(ok, result)
        if not ok or type(result) ~= 'table' then return end
        properties = result
        TriggerEvent('nitro:ui:updateProperties', properties)
    end)
end

--- The properties of the server.
--- @return table[]
exports('GetProperties', function()
    return properties
end)

--- Enter a property.
--- @param propertyKey string
exports('EnterProperty', function(propertyKey)
    TriggerServerEvent('nitro:net:req:enterProperty', propertyKey)
end)

RegisterNetEvent('nitro:client:enterProperty', function(propertyKey)
    local property = properties
    for _, entry in ipairs(property) do
        if entry.property_key == propertyKey then
            TriggerEvent('nitro:client:propertyEntered', entry)
            return
        end
    end
end)

RegisterNetEvent('nitro:client:characterLoaded', function()
    Client.Refresh()
end)
