--[[
    nitro_housing :: server/events.lua

    Server side handlers for the client requests of nitro_housing.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Housing = Nitro.Housing or {}

local Core = Nitro.Housing.Core

--- Ask to enter a property.
RegisterNetEvent('nitro:net:req:enterProperty', function(propertyKey)
    local src = source
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return end

    if not Core.CanAccess(data.characterId, propertyKey) then
        TriggerClientEvent('nitro:ui:showError', src, 'You do not have access to this property.')
        return
    end

    TriggerClientEvent('nitro:client:enterProperty', src, propertyKey)
    TriggerEvent('nitro:server:propertyEntered', src, propertyKey)
end)
