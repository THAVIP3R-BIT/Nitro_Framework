--[[
    nitro_housing :: server/exports.lua

    Public server API of nitro_housing.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Housing = Nitro.Housing or {}

local Core = Nitro.Housing.Core

--- A property by its key.
--- @param propertyKey string
--- @return table?
exports('GetProperty', function(propertyKey)
    return Core.Get(propertyKey)
end)

--- Every property.
--- @return table[]
exports('GetProperties', function()
    return Core.GetAll()
end)

--- Every property of a character.
--- @param characterId string
--- @return table[]
exports('GetOwnedProperties', function(characterId)
    return Core.GetOwned(characterId)
end)

--- Register a property.
--- @param propertyKey string
--- @param label string
--- @param tier string?
--- @param metadata table?
--- @return boolean ok, string? error
exports('CreateProperty', function(propertyKey, label, tier, metadata)
    return Core.Create(propertyKey, label, tier, metadata)
end)

--- Buy a property.
--- @param src number
--- @param propertyKey string
--- @return boolean ok, string? error
exports('BuyProperty', function(src, propertyKey)
    return Core.Buy(src, propertyKey)
end)

--- Sell a property.
--- @param src number
--- @param propertyKey string
--- @return boolean ok, string? error
exports('SellProperty', function(src, propertyKey)
    return Core.Sell(src, propertyKey)
end)

--- The characters that have access to a property.
--- @param propertyKey string
--- @return table[]
exports('GetAccess', function(propertyKey)
    return Core.GetAccess(propertyKey)
end)

--- Give a character access to a property.
--- @param src number
--- @param propertyKey string
--- @param characterId string
--- @param accessLevel string?
--- @return boolean ok, string? error
exports('GrantAccess', function(src, propertyKey, characterId, accessLevel)
    return Core.GrantAccess(src, propertyKey, characterId, accessLevel)
end)

--- Take the access of a character away.
--- @param src number
--- @param propertyKey string
--- @param characterId string
--- @return boolean ok, string? error
exports('RevokeAccess', function(src, propertyKey, characterId)
    return Core.RevokeAccess(src, propertyKey, characterId)
end)

--- May a character enter a property?
--- @param characterId string
--- @param propertyKey string
--- @return boolean
exports('CanAccess', function(characterId, propertyKey)
    return Core.CanAccess(characterId, propertyKey)
end)

--- Let a player enter a property.
--- @param src number
--- @param propertyKey string
--- @return boolean
exports('EnterProperty', function(src, propertyKey)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false end
    if not Core.CanAccess(data.characterId, propertyKey) then return false end
    TriggerClientEvent('nitro:client:enterProperty', src, propertyKey)
    return true
end)

-- ── Callbacks ────────────────────────────────────────────────────────────────

exports.nitro_core:RegisterCallback('nitro:housing:getProperties', function()
    local properties = Core.GetAll()
    for _, property in ipairs(properties) do
        property.price = Core.GetPrice(property)
    end
    return properties
end)

exports.nitro_core:RegisterCallback('nitro:housing:buyProperty', function(src, propertyKey)
    local ok, err = Core.Buy(src, propertyKey)
    if not ok then return false, err end
    return true
end)

exports.nitro_core:RegisterCallback('nitro:housing:sellProperty', function(src, propertyKey)
    local ok, err = Core.Sell(src, propertyKey)
    if not ok then return false, err end
    return true
end)
