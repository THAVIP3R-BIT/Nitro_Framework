--[[
    nitro_housing :: server/properties.lua

    Properties and access.

    A property is owned by a character and may be shared with other
    characters. Every access entry is a row in nitro_property_access.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Housing = Nitro.Housing or {}

Nitro.Housing.Core = {}

local Core = Nitro.Housing.Core

--- A property by its key.
--- @param propertyKey string
--- @return table?
function Core.Get(propertyKey)
    if type(propertyKey) ~= 'string' or propertyKey == '' then return nil end
    return exports.nitro_database:Single(
        'SELECT * FROM nitro_properties WHERE property_key = ?',
        { propertyKey }
    )
end

--- Every property.
--- @return table[]
function Core.GetAll()
    return exports.nitro_database:Query('SELECT * FROM nitro_properties ORDER BY label ASC', {}) or {}
end

--- Every property of a character.
--- @param characterId string
--- @return table[]
function Core.GetOwned(characterId)
    if type(characterId) ~= 'string' then return {} end
    return exports.nitro_database:Query(
        'SELECT * FROM nitro_properties WHERE owner_character_id = ? ORDER BY label ASC',
        { characterId }
    ) or {}
end

--- Register a property.
--- @param propertyKey string
--- @param label string
--- @param tier string?
--- @param metadata table?
--- @return boolean ok, string? error
function Core.Create(propertyKey, label, tier, metadata)
    if type(propertyKey) ~= 'string' or propertyKey == '' then return false, 'invalid_key' end
    exports.nitro_database:Insert(
        'INSERT INTO nitro_properties (property_key, label, tier, metadata) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE label = VALUES(label), tier = VALUES(tier)',
        { propertyKey, label or propertyKey, tier or 'standard', metadata and json.encode(metadata) or json.encode({}) }
    )
    return true, nil
end

--- The price of a property.
--- @param property table
--- @return number
function Core.GetPrice(property)
    if type(property) ~= 'table' then return 0 end
    local prices = Nitro.Housing.Config.Prices or {}
    return tonumber(prices[property.tier] or prices.standard) or 0
end

--- Buy a property.
--- @param src number
--- @param propertyKey string
--- @return boolean ok, string? error
function Core.Buy(src, propertyKey)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end

    local property = Core.Get(propertyKey)
    if not property then return false, 'unknown_property' end
    if property.owner_character_id then return false, 'already_owned' end

    local price = Core.GetPrice(property)
    local paid = exports.nitro_banking:RemoveBank('character', data.characterId, price, ('Property %s'):format(property.label))
    if not paid then
        local paidCash = exports.nitro_banking:RemoveCash(data.characterId, price, ('Property %s'):format(property.label))
        if not paidCash then return false, 'insufficient_funds' end
    end

    exports.nitro_database:Update(
        'UPDATE nitro_properties SET owner_character_id = ? WHERE property_key = ?',
        { data.characterId, propertyKey }
    )

    TriggerEvent('nitro:server:propertyBought', src, propertyKey, price)
    return true, nil
end

--- Sell a property.
--- @param src number
--- @param propertyKey string
--- @return boolean ok, string? error
function Core.Sell(src, propertyKey)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end

    local property = Core.Get(propertyKey)
    if not property then return false, 'unknown_property' end
    if property.owner_character_id ~= data.characterId then return false, 'not_owner' end

    local price = Core.GetPrice(property)
    local payout = math.floor(price * (Nitro.Housing.Config.SellReturn or 0.8))

    exports.nitro_database:Update(
        'UPDATE nitro_properties SET owner_character_id = NULL WHERE property_key = ?',
        { propertyKey }
    )
    exports.nitro_database:Update(
        'DELETE FROM nitro_property_access WHERE property_id = ?',
        { property.id }
    )
    exports.nitro_banking:AddBank('character', data.characterId, payout, ('Sold property %s'):format(property.label))

    TriggerEvent('nitro:server:propertySold', src, propertyKey, payout)
    return true, nil
end

--- The characters that have access to a property.
--- @param propertyKey string
--- @return table[]
function Core.GetAccess(propertyKey)
    local property = Core.Get(propertyKey)
    if not property then return {} end
    return exports.nitro_database:Query(
        'SELECT * FROM nitro_property_access WHERE property_id = ?',
        { property.id }
    ) or {}
end

--- Give a character access to a property.
--- @param src number
--- @param propertyKey string
--- @param characterId string
--- @param accessLevel string?
--- @return boolean ok, string? error
function Core.GrantAccess(src, propertyKey, characterId, accessLevel)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end

    local property = Core.Get(propertyKey)
    if not property then return false, 'unknown_property' end
    if property.owner_character_id ~= data.characterId then return false, 'not_owner' end
    if type(characterId) ~= 'string' or characterId == '' then return false, 'invalid_character' end

    accessLevel = accessLevel or 'shared'
    if not Nitro.Housing.Config.AccessLevels[accessLevel] then return false, 'invalid_access_level' end

    exports.nitro_database:Insert(
        'INSERT INTO nitro_property_access (property_id, character_id, access_level, granted_by) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE access_level = VALUES(access_level), granted_by = VALUES(granted_by)',
        { property.id, characterId, accessLevel, data.characterId }
    )
    return true, nil
end

--- Take the access of a character away.
--- @param src number
--- @param propertyKey string
--- @param characterId string
--- @return boolean ok, string? error
function Core.RevokeAccess(src, propertyKey, characterId)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end

    local property = Core.Get(propertyKey)
    if not property then return false, 'unknown_property' end
    if property.owner_character_id ~= data.characterId then return false, 'not_owner' end

    local affected = exports.nitro_database:Update(
        'DELETE FROM nitro_property_access WHERE property_id = ? AND character_id = ?',
        { property.id, characterId }
    )
    return affected > 0, affected > 0 and nil or 'not_found'
end

--- May a character enter a property?
--- @param characterId string
--- @param propertyKey string
--- @return boolean
function Core.CanAccess(characterId, propertyKey)
    if type(characterId) ~= 'string' then return false end
    local property = Core.Get(propertyKey)
    if not property then return false end
    if property.owner_character_id == characterId then return true end

    local row = exports.nitro_database:Single(
        'SELECT id FROM nitro_property_access WHERE property_id = ? AND character_id = ?',
        { property.id, characterId }
    )
    return row ~= nil
end
