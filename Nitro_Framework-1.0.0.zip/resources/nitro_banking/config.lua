--[[
    nitro_banking :: config.lua

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Banking = Nitro.Banking or {}

Nitro.Banking.Config = {
    -- How many transactions are kept in the on screen history.
    TransactionHistory = 25,

    -- Maximum amount a single transfer may move.
    MaxTransferAmount = 10000000,

    -- Minimum amount a single transfer may move.
    MinTransferAmount = 1,

    -- Charge a fee on transfers to other players.
    -- The fee is a percentage of the transferred amount.
    TransferFee = 0.0,

    -- Organisation accounts are created automatically when they are needed.
    AutoCreateOrganisationAccounts = true,
}
