--[[
    nitro_banking :: server/exports.lua

    Public server API of nitro_banking.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Banking = Nitro.Banking or {}

local Core = Nitro.Banking.Core

--- The bank account of a character.
--- @param characterId string
--- @return table?
exports('GetAccount', function(characterId)
    return Core.GetAccount(characterId)
end)

--- The bank balance of a character.
--- @param characterId string
--- @return number
exports('GetBalance', function(characterId)
    return Core.GetBalance(characterId)
end)

--- The cash a character carries.
--- @param characterId string
--- @return number
exports('GetCash', function(characterId)
    return Core.GetCash(characterId)
end)

--- Cash plus bank.
--- @param characterId string
--- @return number
exports('GetTotal', function(characterId)
    return Core.GetTotal(characterId)
end)

--- @param characterId string
--- @param amount number
--- @param description string?
--- @param reference string?
--- @return boolean ok, string? reason
exports('AddCash', function(characterId, amount, description, reference)
    return Core.AddCash(characterId, amount, description, reference)
end)

--- @param characterId string
--- @param amount number
--- @param description string?
--- @param reference string?
--- @return boolean ok, string? reason
exports('RemoveCash', function(characterId, amount, description, reference)
    return Core.RemoveCash(characterId, amount, description, reference)
end)

--- @param ownerType string
--- @param ownerId string
--- @param amount number
--- @param description string?
--- @param reference string?
--- @return boolean ok, string? reason
exports('AddBank', function(ownerType, ownerId, amount, description, reference)
    return Core.AddBank(ownerType, ownerId, amount, description, reference)
end)

--- @param ownerType string
--- @param ownerId string
--- @param amount number
--- @param description string?
--- @param reference string?
--- @return boolean ok, string? reason
exports('RemoveBank', function(ownerType, ownerId, amount, description, reference)
    return Core.RemoveBank(ownerType, ownerId, amount, description, reference)
end)

--- @param fromType string
--- @param fromId string
--- @param toType string
--- @param toId string
--- @param amount number
--- @param description string?
--- @param actor string?
--- @return boolean ok, string? reason
exports('Transfer', function(fromType, fromId, toType, toId, amount, description, actor)
    return Core.Transfer(fromType, fromId, toType, toId, amount, description, actor)
end)

--- @param characterId string
--- @param amount number
--- @param description string?
--- @return boolean ok, string? reason
exports('Deposit', function(characterId, amount, description)
    return Core.Deposit(characterId, amount, description)
end)

--- @param characterId string
--- @param amount number
--- @param description string?
--- @return boolean ok, string? reason
exports('Withdraw', function(characterId, amount, description)
    return Core.Withdraw(characterId, amount, description)
end)

--- @param accountNumber string
--- @param limit number?
--- @return table[]
exports('GetTransactions', function(accountNumber, limit)
    return Core.GetTransactions(accountNumber, limit)
end)

--- Create the shared account of an organisation.
--- @param organisationName string
--- @param label string?
--- @param openingBalance number?
--- @return table? account
exports('CreateOrganisationAccount', function(organisationName, label, openingBalance)
    if type(organisationName) ~= 'string' or organisationName == '' then return nil end
    return Core.CreateAccount('organisation', organisationName, label or organisationName, openingBalance)
end)

-- ── Callbacks ────────────────────────────────────────────────────────────────

exports.nitro_core:RegisterCallback('nitro:banking:getBalances', function(src)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return {} end
    return {
        cash = Core.GetCash(data.characterId),
        bank = Core.GetBalance(data.characterId),
        accountNumber = data.accountNumber,
    }
end)

exports.nitro_core:RegisterCallback('nitro:banking:transfer', function(src, targetCharacterId, amount, description)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end
    if type(targetCharacterId) ~= 'string' or targetCharacterId == '' then return false, 'invalid_target' end

    local ok, reason = Core.Transfer(
        'character', data.characterId,
        'character', targetCharacterId,
        amount, description or 'Transfer', data.characterId
    )
    if not ok then return false, reason end
    return true
end)

exports.nitro_core:RegisterCallback('nitro:banking:deposit', function(src, amount)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end
    local ok, reason = Core.Deposit(data.characterId, amount, 'Deposit')
    if not ok then return false, reason end
    return true
end)

exports.nitro_core:RegisterCallback('nitro:banking:withdraw', function(src, amount)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data then return false, 'no_character' end
    local ok, reason = Core.Withdraw(data.characterId, amount, 'Withdrawal')
    if not ok then return false, reason end
    return true
end)

exports.nitro_core:RegisterCallback('nitro:banking:getTransactions', function(src)
    local data = exports.nitro_players:GetPlayerData(src)
    if not data or not data.accountNumber then return {} end
    return Core.GetTransactions(data.accountNumber)
end)
