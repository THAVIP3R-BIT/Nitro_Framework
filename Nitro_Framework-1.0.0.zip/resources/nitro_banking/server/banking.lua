--[[
    nitro_banking :: server/banking.lua

    Every change of money in Nitro_Framework happens here.

    Balances
      * Cash lives on the character row (`nitro_characters.cash`).
      * The bank balance lives in `nitro_banking_accounts.balance`.

    Safety
      * Balances are never read into Lua and written back. Every change is an
        atomic `UPDATE ... WHERE balance >= ?`, so a balance can never go
        negative even when two requests arrive at the same time.
      * Every change writes a row to the immutable ledger
        (`nitro_transactions`). The `reference` column is an idempotency key,
        so a retried request can never move money twice.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Banking = Nitro.Banking or {}

Nitro.Banking.Core = {}

local Core = Nitro.Banking.Core

--- Generate an idempotency key for a ledger entry.
--- @return string
local function generateReference()
    return ('%d-%d'):format(os.time(), math.random(100000, 999999))
end

--- The account of a character.
--- @param characterId string
--- @return table?
function Core.GetAccount(characterId)
    if type(characterId) ~= 'string' then return nil end
    return exports.nitro_database:Single(
        'SELECT * FROM nitro_banking_accounts WHERE owner_type = ? AND owner_id = ?',
        { 'character', characterId }
    )
end

--- The account of an owner of any type.
--- @param ownerType string
--- @param ownerId string
--- @return table?
function Core.GetOwnerAccount(ownerType, ownerId)
    if type(ownerType) ~= 'string' or type(ownerId) ~= 'string' then return nil end
    return exports.nitro_database:Single(
        'SELECT * FROM nitro_banking_accounts WHERE owner_type = ? AND owner_id = ?',
        { ownerType, ownerId }
    )
end

--- Create an account for an owner.
--- @param ownerType string
--- @param ownerId string
--- @param label string?
--- @param openingBalance number?
--- @return table? account
function Core.CreateAccount(ownerType, ownerId, label, openingBalance)
    local account = Core.GetOwnerAccount(ownerType, ownerId)
    if account then return account end

    local accountNumber = ('%s%s'):format(ownerType:sub(1, 3):upper(), ('%d'):format(math.random(100000, 999999)))
    exports.nitro_database:Insert(
        'INSERT IGNORE INTO nitro_banking_accounts (owner_type, owner_id, account_number, label, balance) VALUES (?, ?, ?, ?, ?)',
        { ownerType, ownerId, accountNumber, label or 'Account', tonumber(openingBalance) or 0 }
    )
    return Core.GetOwnerAccount(ownerType, ownerId)
end

--- The bank balance of a character.
--- @param characterId string
--- @return number
function Core.GetBalance(characterId)
    local account = Core.GetAccount(characterId)
    return account and tonumber(account.balance) or 0
end

--- The cash a character carries.
--- @param characterId string
--- @return number
function Core.GetCash(characterId)
    if type(characterId) ~= 'string' then return 0 end
    local row = exports.nitro_database:Single(
        'SELECT cash FROM nitro_characters WHERE character_id = ?',
        { characterId }
    )
    return row and tonumber(row.cash) or 0
end

--- Cash plus bank.
--- @param characterId string
--- @return number
function Core.GetTotal(characterId)
    return Core.GetCash(characterId) + Core.GetBalance(characterId)
end

--- Write a ledger entry.
--- @param entry table
--- @return boolean written
local function writeLedger(entry)
    local insertId = exports.nitro_database:Insert(
        'INSERT INTO nitro_transactions (reference, from_account, to_account, amount, balance_after, transaction_type, description, actor) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        {
            entry.reference,
            entry.fromAccount,
            entry.toAccount,
            entry.amount,
            entry.balanceAfter,
            entry.transactionType,
            entry.description,
            entry.actor,
        }
    )
    return insertId ~= nil and insertId ~= 0
end

--- Does a reference already exist in the ledger?
--- @param reference string
--- @return boolean
local function referenceExists(reference)
    if type(reference) ~= 'string' then return false end
    local row = exports.nitro_database:Single(
        'SELECT id FROM nitro_transactions WHERE reference = ?',
        { reference }
    )
    return row ~= nil
end

--- Add cash to a character.
--- @param characterId string
--- @param amount number
--- @param description string?
--- @param reference string?
--- @return boolean ok, string? reason
function Core.AddCash(characterId, amount, description, reference)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, 'invalid_amount' end
    if type(characterId) ~= 'string' then return false, 'invalid_character' end

    reference = reference or generateReference()
    if referenceExists(reference) then return false, 'duplicate_reference' end

    local affected = exports.nitro_database:Update(
        'UPDATE nitro_characters SET cash = cash + ? WHERE character_id = ?',
        { amount, characterId }
    )
    if affected == 0 then return false, 'not_found' end

    writeLedger({
        reference = reference,
        fromAccount = nil,
        toAccount = 'cash:' .. characterId,
        amount = amount,
        balanceAfter = Core.GetCash(characterId),
        transactionType = 'cash',
        description = description or 'Cash added',
        actor = nil,
    })
    return true, nil
end

--- Remove cash from a character.
--- @param characterId string
--- @param amount number
--- @param description string?
--- @param reference string?
--- @return boolean ok, string? reason
function Core.RemoveCash(characterId, amount, description, reference)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, 'invalid_amount' end
    if type(characterId) ~= 'string' then return false, 'invalid_character' end

    reference = reference or generateReference()
    if referenceExists(reference) then return false, 'duplicate_reference' end

    local affected = exports.nitro_database:Update(
        'UPDATE nitro_characters SET cash = cash - ? WHERE character_id = ? AND cash >= ?',
        { amount, characterId, amount }
    )
    if affected == 0 then
        return false, Core.GetCash(characterId) < amount and 'insufficient_funds' or 'not_found'
    end

    writeLedger({
        reference = reference,
        fromAccount = 'cash:' .. characterId,
        toAccount = nil,
        amount = amount,
        balanceAfter = Core.GetCash(characterId),
        transactionType = 'cash',
        description = description or 'Cash removed',
        actor = nil,
    })
    return true, nil
end

--- Add money to a bank account.
--- @param ownerType string
--- @param ownerId string
--- @param amount number
--- @param description string?
--- @param reference string?
--- @return boolean ok, string? reason
function Core.AddBank(ownerType, ownerId, amount, description, reference)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, 'invalid_amount' end

    local account = Core.GetOwnerAccount(ownerType, ownerId)
    if not account then return false, 'no_account' end

    reference = reference or generateReference()
    if referenceExists(reference) then return false, 'duplicate_reference' end

    local affected = exports.nitro_database:Update(
        'UPDATE nitro_banking_accounts SET balance = balance + ? WHERE id = ? AND frozen = 0',
        { amount, account.id }
    )
    if affected == 0 then return false, 'account_frozen' end

    writeLedger({
        reference = reference,
        fromAccount = nil,
        toAccount = account.account_number,
        amount = amount,
        balanceAfter = Core.GetOwnerAccount(ownerType, ownerId).balance,
        transactionType = 'deposit',
        description = description or 'Deposit',
        actor = nil,
    })
    return true, nil
end

--- Remove money from a bank account.
--- @param ownerType string
--- @param ownerId string
--- @param amount number
--- @param description string?
--- @param reference string?
--- @return boolean ok, string? reason
function Core.RemoveBank(ownerType, ownerId, amount, description, reference)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, 'invalid_amount' end

    local account = Core.GetOwnerAccount(ownerType, ownerId)
    if not account then return false, 'no_account' end

    reference = reference or generateReference()
    if referenceExists(reference) then return false, 'duplicate_reference' end

    local affected = exports.nitro_database:Update(
        'UPDATE nitro_banking_accounts SET balance = balance - ? WHERE id = ? AND balance >= ? AND frozen = 0',
        { amount, account.id, amount }
    )
    if affected == 0 then
        return false, tonumber(account.balance) < amount and 'insufficient_funds' or 'account_frozen'
    end

    writeLedger({
        reference = reference,
        fromAccount = account.account_number,
        toAccount = nil,
        amount = amount,
        balanceAfter = Core.GetOwnerAccount(ownerType, ownerId).balance,
        transactionType = 'withdrawal',
        description = description or 'Withdrawal',
        actor = nil,
    })
    return true, nil
end

--- Move money between two bank accounts.
--- @param fromType string
--- @param fromId string
--- @param toType string
--- @param toId string
--- @param amount number
--- @param description string?
--- @param actor string?
--- @param reference string?
--- @return boolean ok, string? reason
function Core.Transfer(fromType, fromId, toType, toId, amount, description, actor, reference)
    amount = math.floor(tonumber(amount) or 0)
    if amount < Nitro.Banking.Config.MinTransferAmount then return false, 'invalid_amount' end
    if amount > Nitro.Banking.Config.MaxTransferAmount then return false, 'amount_too_high' end
    if fromType == toType and fromId == toId then return false, 'same_account' end

    local from = Core.GetOwnerAccount(fromType, fromId)
    local to = Core.GetOwnerAccount(toType, toId)
    if not from then return false, 'no_source_account' end
    if not to then return false, 'no_target_account' end

    reference = reference or generateReference()
    if referenceExists(reference) then return false, 'duplicate_reference' end

    local fee = math.floor(amount * (Nitro.Banking.Config.TransferFee or 0))

    local deducted = exports.nitro_database:Update(
        'UPDATE nitro_banking_accounts SET balance = balance - ? WHERE id = ? AND balance >= ? AND frozen = 0',
        { amount, from.id, amount }
    )
    if deducted == 0 then
        return false, tonumber(from.balance) < amount and 'insufficient_funds' or 'account_frozen'
    end

    exports.nitro_database:Update(
        'UPDATE nitro_banking_accounts SET balance = balance + ? WHERE id = ?',
        { amount - fee, to.id }
    )

    if fee > 0 then
        writeLedger({
            reference = reference .. '-fee',
            fromAccount = from.account_number,
            toAccount = nil,
            amount = fee,
            balanceAfter = nil,
            transactionType = 'fee',
            description = 'Transfer fee',
            actor = actor,
        })
    end

    writeLedger({
        reference = reference,
        fromAccount = from.account_number,
        toAccount = to.account_number,
        amount = amount,
        balanceAfter = Core.GetOwnerAccount(toType, toId).balance,
        transactionType = 'transfer',
        description = description or 'Transfer',
        actor = actor,
    })

    TriggerEvent('nitro:server:moneyTransferred', fromType, fromId, toType, toId, amount, description, actor)
    return true, nil
end

--- Move money from the bank to the pocket.
--- @param characterId string
--- @param amount number
--- @param description string?
--- @return boolean ok, string? reason
function Core.Withdraw(characterId, amount, description)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, 'invalid_amount' end

    local reference = generateReference()
    local ok, reason = Core.RemoveBank('character', characterId, amount, description or 'Withdrawal', reference)
    if not ok then return false, reason end

    local added, addReason = Core.AddCash(characterId, amount, description or 'Withdrawal', reference .. '-cash')
    if not added then
        -- Compensate: the money goes back to the bank.
        Core.AddBank('character', characterId, amount, description or 'Withdrawal (reverted)', reference .. '-revert')
        return false, addReason
    end
    return true, nil
end

--- Move money from the pocket to the bank.
--- @param characterId string
--- @param amount number
--- @param description string?
--- @return boolean ok, string? reason
function Core.Deposit(characterId, amount, description)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return false, 'invalid_amount' end

    local reference = generateReference()
    local ok, reason = Core.RemoveCash(characterId, amount, description or 'Deposit', reference)
    if not ok then return false, reason end

    local added, addReason = Core.AddBank('character', characterId, amount, description or 'Deposit', reference .. '-bank')
    if not added then
        Core.AddCash(characterId, amount, description or 'Deposit (reverted)', reference .. '-revert')
        return false, addReason
    end
    return true, nil
end

--- The ledger of an account.
--- @param accountNumber string
--- @param limit number?
--- @return table[]
function Core.GetTransactions(accountNumber, limit)
    if type(accountNumber) ~= 'string' then return {} end
    limit = math.min(tonumber(limit) or Nitro.Banking.Config.TransactionHistory, 100)
    local rows = exports.nitro_database:Query(
        'SELECT * FROM nitro_transactions WHERE from_account = ? OR to_account = ? ORDER BY id DESC LIMIT ' .. limit,
        { accountNumber, accountNumber }
    )
    return rows or {}
end
