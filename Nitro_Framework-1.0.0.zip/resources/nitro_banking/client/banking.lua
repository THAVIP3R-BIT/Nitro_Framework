--[[
    nitro_banking :: client/banking.lua

    Client side helpers of the economy. The UI is provided by nitro_ui, this
    resource only forwards the actions and keeps the local balance in sync.

    Original Nitro_Framework work. Licensed GPL-3.0-or-later.
 ]]

Nitro = Nitro or {}
Nitro.Banking = Nitro.Banking or {}

Nitro.Banking.Client = {}

local Client = Nitro.Banking.Client

local balances = {
    cash = 0,
    bank = 0,
    accountNumber = nil,
}

--- Refresh the balances from the server.
function Client.Refresh()
    exports.nitro_core:TriggerCallback('nitro:banking:getBalances', function(ok, result)
        if not ok or type(result) ~= 'table' then return end
        balances = result
        TriggerEvent('nitro:client:balancesUpdated', balances)
        TriggerEvent('nitro:ui:updateBalances', balances)
    end)
end

RegisterNetEvent('nitro:client:characterLoaded', function()
    Client.Refresh()
end)

RegisterNetEvent('nitro:client:characterUnloaded', function()
    balances = { cash = 0, bank = 0, accountNumber = nil }
end)

RegisterNetEvent('nitro:client:balancesChanged', function()
    Client.Refresh()
end)

--- The cash and bank balance of the player.
--- @return table
exports('GetBalances', function()
    return balances
end)

--- Refresh the balances.
exports('Refresh', function()
    Client.Refresh()
end)
