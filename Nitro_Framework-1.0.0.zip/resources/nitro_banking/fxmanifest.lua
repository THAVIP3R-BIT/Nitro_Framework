fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nitro_banking'
author 'Nitro_Framework'
description 'Nitro_Framework economy: balances, transfers and the transaction ledger.'
version '1.0.0'

shared_scripts {
    'config.lua',
}

server_scripts {
    'server/banking.lua',
    'server/exports.lua',
}

client_scripts {
    'client/banking.lua',
}

dependency 'nitro_shared'
dependency 'nitro_database'
dependency 'nitro_core'
dependency 'nitro_players'

exports {
    'GetAccount',
    'GetBalance',
    'GetBalances',
    'GetCash',
    'GetTotal',
    'AddCash',
    'RemoveCash',
    'AddBank',
    'RemoveBank',
    'Transfer',
    'Deposit',
    'Withdraw',
    'GetTransactions',
    'CreateOrganisationAccount',
    'Refresh',
}
