-- =============================================================================
-- Nitro_Framework :: 005_world.sql
-- Vehicles, garages, impounds, properties and property access.
--
-- Relationships
--   nitro_vehicles.character_id -> nitro_characters.character_id (logical link)
--   nitro_properties.owner_character_id -> nitro_characters.character_id
--   nitro_properties 1 --- * nitro_property_access (ON DELETE CASCADE)
-- =============================================================================

CREATE TABLE IF NOT EXISTS `nitro_garages` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(64) NOT NULL,
  `label` VARCHAR(64) NOT NULL,
  `vehicle_type` VARCHAR(32) NOT NULL DEFAULT 'automobile',
  `coordinates` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_garages_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_impounds` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(64) NOT NULL,
  `label` VARCHAR(64) NOT NULL,
  `fee` INT NOT NULL DEFAULT 500,
  `coordinates` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_impounds_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_vehicles` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `character_id` VARCHAR(32) NULL DEFAULT NULL,
  `plate` VARCHAR(16) NOT NULL,
  `model` VARCHAR(64) NOT NULL,
  `garage` VARCHAR(64) NULL DEFAULT NULL,
  `state` VARCHAR(16) NOT NULL DEFAULT 'garaged',
  `fuel` INT NOT NULL DEFAULT 100,
  `properties` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_vehicles_plate` (`plate`),
  KEY `idx_nitro_vehicles_character` (`character_id`),
  KEY `idx_nitro_vehicles_garage` (`garage`),
  KEY `idx_nitro_vehicles_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_properties` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `property_key` VARCHAR(64) NOT NULL,
  `label` VARCHAR(64) NOT NULL,
  `tier` VARCHAR(32) NOT NULL DEFAULT 'standard',
  `owner_character_id` VARCHAR(32) NULL DEFAULT NULL,
  `metadata` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_properties_key` (`property_key`),
  KEY `idx_nitro_properties_owner` (`owner_character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_property_access` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `property_id` BIGINT UNSIGNED NOT NULL,
  `character_id` VARCHAR(32) NOT NULL,
  `access_level` VARCHAR(16) NOT NULL DEFAULT 'shared',
  `granted_by` VARCHAR(32) NULL DEFAULT NULL,
  `granted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_property_access` (`property_id`, `character_id`),
  KEY `idx_nitro_property_access_character` (`character_id`),
  CONSTRAINT `fk_nitro_property_access_property`
    FOREIGN KEY (`property_id`) REFERENCES `nitro_properties` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
