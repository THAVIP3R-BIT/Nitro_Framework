# Nitro_Framework database migrations

This directory is the **canonical, version controlled** location for every SQL
statement Nitro_Framework owns.

## Layout

```
migrations/
├── 001_core.sql          accounts + characters
├── 002_inventory.sql     containers + items
├── 003_economy.sql       bank accounts + transaction ledger
├── 004_employment.sql    jobs, grades, organisations, ranks, members
├── 005_world.sql         vehicles, garages, impounds, properties
├── 006_governance.sql    bans + administrative audit log
└── legacy/
    ├── 100_qbcore_import.sql   one-off QBCore -> Nitro data import
    └── README.md
```

## How migrations are applied

`nitro_database` keeps a copy of these files inside its own resource
(`resources/nitro_database/sql/`) because FiveM can only read files that live
inside a resource. The copies are generated - never edit them by hand.

```bash
npm run sync:migrations
```

The drift check (`npm run sync:check`, part of `npm run check`) fails when the
copies have drifted away from the canonical files, so a forgotten sync can
never reach a server.

## Applying them automatically

By default `nitro_database` applies every pending migration when the resource
starts:

```cfg
set mysql_connection_string "mysql://USERNAME:PASSWORD@localhost/DATABASE?charset=utf8mb4"

ensure oxmysql
ensure nitro_shared
ensure nitro_database
```

Applied migrations are recorded in the `nitro_migrations` table, so the runner
is safe to execute on every boot. To apply them by hand instead, set
`AutoMigrate = false` in `resources/nitro_database/config.lua` and run:

```bash
mysql -u USERNAME -p DATABASE < migrations/001_core.sql
mysql -u USERNAME -p DATABASE < migrations/002_inventory.sql
# ... and so on, in numeric order
```

## Rules the bundled migrations follow

* Every statement is `CREATE TABLE IF NOT EXISTS` - running them twice is safe.
* No bundled migration drops, truncates, renames or overwrites a table.
* Foreign keys are declared with explicit `ON DELETE` behaviour.
* JSON columns require MySQL 5.7+ / MariaDB 10.2+.
* The migration table itself is created by the runner, not by a file.

## Adding a new migration

1. Create `migrations/0NN_name.sql` with a **higher** number than every
   existing file.
2. Keep it idempotent (`IF NOT EXISTS`, `INSERT IGNORE`, `ON DUPLICATE KEY`).
3. Add the file name to `Nitro.Database.Config.Migrations` in
   `resources/nitro_database/config.lua`.
4. Run `npm run sync:migrations`.
5. Run `npm run check`, the schema check verifies that the SQL of the code
   still matches the schema.

## Rolling back

The Nitro schema never drops data on its own, so a rollback is a manual
decision. The safe procedure is:

```sql
-- 1. stop the server (or at least the nitro_* resources)
-- 2. snapshot what you are about to remove
CREATE TABLE nitro_characters_backup AS SELECT * FROM nitro_characters;
-- 3. drop only the tables you are sure about
DROP TABLE nitro_inventory_items;
DROP TABLE nitro_inventories;
-- 4. restart
```

See `docs/migrating-from-qbcore.md` for the full backup and rollback plan for
an existing QBCore installation.
