-- =============================================================================
-- Nitro_Framework :: 004_employment.sql
-- Jobs, job grades, organisations, organisation ranks and memberships.
--
-- The shared catalogues (nitro_shared) describe the *shipped* jobs and
-- organisations. The tables below mirror them so that an administrator can
-- change a salary, a rank name or a permission set at runtime without
-- editing Lua files.
--
-- Relationships
--   nitro_jobs 1 --- * nitro_job_grades                (ON DELETE CASCADE)
--   nitro_organisations 1 --- * nitro_organisation_ranks (ON DELETE CASCADE)
--   nitro_organisations 1 --- * nitro_organisation_members (ON DELETE CASCADE)
--
-- `nitro_organisation_members.character_id` references
-- `nitro_characters.character_id`.
-- =============================================================================

CREATE TABLE IF NOT EXISTS `nitro_jobs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(64) NOT NULL,
  `label` VARCHAR(64) NOT NULL,
  `type` VARCHAR(32) NOT NULL DEFAULT 'none',
  `default_duty` TINYINT(1) NOT NULL DEFAULT 1,
  `off_duty_pay` TINYINT(1) NOT NULL DEFAULT 0,
  `metadata` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_jobs_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_job_grades` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `job_id` BIGINT UNSIGNED NOT NULL,
  `level` TINYINT NOT NULL DEFAULT 0,
  `name` VARCHAR(64) NOT NULL,
  `payment` INT NOT NULL DEFAULT 0,
  `is_boss` TINYINT(1) NOT NULL DEFAULT 0,
  `permissions` JSON NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_job_grades` (`job_id`, `level`),
  CONSTRAINT `fk_nitro_job_grades_job`
    FOREIGN KEY (`job_id`) REFERENCES `nitro_jobs` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_organisations` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(64) NOT NULL,
  `label` VARCHAR(64) NOT NULL,
  `type` VARCHAR(32) NOT NULL DEFAULT 'crew',
  `shared_funds` TINYINT(1) NOT NULL DEFAULT 1,
  `metadata` JSON NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_organisations_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_organisation_ranks` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `organisation_id` BIGINT UNSIGNED NOT NULL,
  `level` TINYINT NOT NULL DEFAULT 0,
  `name` VARCHAR(64) NOT NULL,
  `is_leader` TINYINT(1) NOT NULL DEFAULT 0,
  `permissions` JSON NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_organisation_ranks` (`organisation_id`, `level`),
  CONSTRAINT `fk_nitro_organisation_ranks_organisation`
    FOREIGN KEY (`organisation_id`) REFERENCES `nitro_organisations` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_organisation_members` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `organisation_id` BIGINT UNSIGNED NOT NULL,
  `character_id` VARCHAR(32) NOT NULL,
  `rank_level` TINYINT NOT NULL DEFAULT 0,
  `joined_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_organisation_members_character` (`character_id`),
  KEY `idx_nitro_organisation_members_organisation` (`organisation_id`),
  CONSTRAINT `fk_nitro_organisation_members_organisation`
    FOREIGN KEY (`organisation_id`) REFERENCES `nitro_organisations` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
