-- =============================================================================
-- Nitro_Framework :: 002_inventory.sql
-- Containers and the items stored inside them.
--
-- A container belongs to an "owner" which can be a character, a vehicle, a
-- property, an organisation or a plain stash id. Several containers therefore
-- share the same owner_id without colliding.
--
-- Relationships
--   nitro_inventories 1 --- * nitro_inventory_items
--   nitro_inventory_items.inventory_id -> nitro_inventories.id (ON DELETE CASCADE)
--
-- `serial` is only populated for unique items (weapons with a unique serial,
-- key cards, ...). It is UNIQUE, which is what prevents the same physical item
-- from existing in two containers at once.
-- =============================================================================

CREATE TABLE IF NOT EXISTS `nitro_inventories` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `owner_type` VARCHAR(16) NOT NULL DEFAULT 'character',
  `owner_id` VARCHAR(64) NOT NULL,
  `label` VARCHAR(64) NOT NULL DEFAULT 'Container',
  `capacity` INT NOT NULL DEFAULT 50000,
  `slots` INT NOT NULL DEFAULT 50,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_inventories_owner` (`owner_type`, `owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `nitro_inventory_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `inventory_id` BIGINT UNSIGNED NOT NULL,
  `item` VARCHAR(64) NOT NULL,
  `amount` INT NOT NULL DEFAULT 1,
  `metadata` JSON NULL DEFAULT NULL,
  `serial` VARCHAR(64) NULL DEFAULT NULL,
  `slot` INT NULL DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nitro_inventory_items_serial` (`serial`),
  KEY `idx_nitro_inventory_items_inventory` (`inventory_id`),
  KEY `idx_nitro_inventory_items_item` (`item`),
  CONSTRAINT `fk_nitro_inventory_items_inventory`
    FOREIGN KEY (`inventory_id`) REFERENCES `nitro_inventories` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
