-- =============================================================================
-- Nitro_Framework :: 100_qbcore_import.sql  (LEGACY / MANUAL)
--
-- Imports an existing QBCore installation into the Nitro schema.
--
--   !!  READ docs/migrating-from-qbcore.md BEFORE RUNNING THIS FILE  !!
--
-- Properties
--   * READ ONLY with respect to every QBCore table. Nothing in `players`,
--     `bans` or `player_contacts` is dropped, truncated or overwritten.
--   * Re-runnable: accounts and characters are inserted with
--     ON DUPLICATE KEY UPDATE, so running it twice does not duplicate rows.
--   * The import is namespaced by character_id, which is the QBCore
--     citizenid. Existing identifiers are preserved exactly.
--
-- Requirements
--   * The QBCore tables must live in the same schema as the Nitro tables.
--   * Run 001_core.sql .. 006_governance.sql first.
--
-- Verify with:
--   SELECT COUNT(*) FROM nitro_characters;
--   SELECT character_id, first_name, last_name, cash, bank FROM nitro_characters LIMIT 20;
-- =============================================================================

-- ── 1. Accounts ─────────────────────────────────────────────────────────────

INSERT INTO `nitro_accounts` (`license`)
SELECT DISTINCT `license`
FROM `players`
WHERE `license` IS NOT NULL AND `license` <> ''
ON DUPLICATE KEY UPDATE `license` = VALUES(`license`);

-- ── 2. Characters ───────────────────────────────────────────────────────────

INSERT INTO `nitro_characters` (
  `account_id`,
  `character_id`,
  `first_name`,
  `last_name`,
  `date_of_birth`,
  `gender`,
  `nationality`,
  `phone`,
  `account_number`,
  `job_name`,
  `job_grade`,
  `organisation_name`,
  `organisation_grade`,
  `cash`,
  `position`,
  `metadata`,
  `last_seen`
)
SELECT
  `a`.`id`,
  `p`.`citizenid`,
  COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`charinfo`, '$.firstname')), ''), 'Firstname'),
  COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`charinfo`, '$.lastname')), ''), 'Lastname'),
  NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`charinfo`, '$.birthdate')), ''),
  COALESCE(JSON_EXTRACT(`p`.`charinfo`, '$.gender'), 0),
  COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`charinfo`, '$.nationality')), ''), 'USA'),
  NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`charinfo`, '$.phone')), ''),
  NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`charinfo`, '$.account')), ''),
  COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`job`, '$.name')), ''), 'unemployed'),
  COALESCE(JSON_EXTRACT(`p`.`job`, '$.grade.level'), 0),
  COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`gang`, '$.name')), ''), 'none'),
  COALESCE(JSON_EXTRACT(`p`.`gang`, '$.grade.level'), 0),
  COALESCE(JSON_EXTRACT(`p`.`money`, '$.cash'), 0),
  CASE WHEN JSON_VALID(`p`.`position`) THEN `p`.`position` ELSE NULL END,
  CASE WHEN JSON_VALID(`p`.`metadata`) THEN `p`.`metadata` ELSE NULL END,
  `p`.`last_updated`
FROM `players` `p`
INNER JOIN `nitro_accounts` `a`
  ON `a`.`license` = `p`.`license`
ON DUPLICATE KEY UPDATE
  `first_name` = VALUES(`first_name`),
  `last_name` = VALUES(`last_name`),
  `date_of_birth` = VALUES(`date_of_birth`),
  `gender` = VALUES(`gender`),
  `nationality` = VALUES(`nationality`),
  `phone` = VALUES(`phone`),
  `account_number` = VALUES(`account_number`),
  `job_name` = VALUES(`job_name`),
  `job_grade` = VALUES(`job_grade`),
  `organisation_name` = VALUES(`organisation_name`),
  `organisation_grade` = VALUES(`organisation_grade`),
  `cash` = VALUES(`cash`),
  `position` = VALUES(`position`),
  `metadata` = VALUES(`metadata`),
  `last_seen` = VALUES(`last_seen`);

-- ── 2b. Bank accounts ───────────────────────────────────────────────────────
--
-- The QBCore bank balance becomes the balance of the character's Nitro bank
-- account. The account number is the one the character already used, so
-- references in the ledger stay valid.

INSERT INTO `nitro_banking_accounts` (`owner_type`, `owner_id`, `account_number`, `label`, `balance`)
SELECT
  'character',
  `p`.`citizenid`,
  COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(`p`.`charinfo`, '$.account')), ''), CONCAT('NITRO', `p`.`citizenid`)),
  'Personal Account',
  COALESCE(JSON_EXTRACT(`p`.`money`, '$.bank'), 0)
FROM `players` `p`
WHERE `p`.`citizenid` IS NOT NULL AND `p`.`citizenid` <> ''
ON DUPLICATE KEY UPDATE
  `label` = VALUES(`label`),
  `balance` = VALUES(`balance`);

-- ── 3. Inventories ──────────────────────────────────────────────────────────
--
-- The QBCore `players.inventory` column stores a JSON array of
-- { "name": "<item>", "amount": <n>, "info": <json>, "slot": <n> } objects.
-- The Nitro schema stores one row per item stack instead.

INSERT INTO `nitro_inventories` (`owner_type`, `owner_id`, `label`, `capacity`)
SELECT 'character', `citizenid`, 'Personal Inventory', 50000
FROM `players`
WHERE `citizenid` IS NOT NULL AND `citizenid` <> ''
ON DUPLICATE KEY UPDATE `label` = VALUES(`label`);

INSERT INTO `nitro_inventory_items` (`inventory_id`, `item`, `amount`, `metadata`, `slot`)
SELECT
  `i`.`id`,
  JSON_UNQUOTE(JSON_EXTRACT(`j`.`item`, '$.name')),
  GREATEST(1, COALESCE(JSON_EXTRACT(`j`.`item`, '$.amount'), 1)),
  CASE
    WHEN JSON_VALID(JSON_UNQUOTE(JSON_EXTRACT(`j`.`item`, '$.info'))) AND JSON_UNQUOTE(JSON_EXTRACT(`j`.`item`, '$.info')) <> 'null'
      THEN JSON_UNQUOTE(JSON_EXTRACT(`j`.`item`, '$.info'))
    ELSE NULL
  END,
  JSON_EXTRACT(`j`.`item`, '$.slot')
FROM `players` `p`
INNER JOIN `nitro_inventories` `i`
  ON `i`.`owner_type` = 'character' AND `i`.`owner_id` = `p`.`citizenid`
INNER JOIN JSON_TABLE(
  `p`.`inventory`,
  '$[*]' COLUMNS (
    `item` JSON PATH '$'
  )
) `j`
WHERE `p`.`inventory` IS NOT NULL
  AND JSON_VALID(`p`.`inventory`)
  AND JSON_UNQUOTE(JSON_EXTRACT(`j`.`item`, '$.name')) IS NOT NULL;

-- ── 4. Bans ─────────────────────────────────────────────────────────────────

INSERT INTO `nitro_bans` (`license`, `discord`, `ip`, `name`, `reason`, `expires_at`, `banned_by`, `created_at`)
SELECT
  `b`.`license`,
  `b`.`discord`,
  `b`.`ip`,
  `b`.`name`,
  `b`.`reason`,
  CASE
    WHEN `b`.`expire` IS NULL OR `b`.`expire` <= 0 OR `b`.`expire` >= 2147483647 THEN NULL
    ELSE FROM_UNIXTIME(`b`.`expire`)
  END,
  `b`.`bannedby`,
  NOW()
FROM `bans` `b`
WHERE `b`.`license` IS NOT NULL AND `b`.`license` <> ''
ON DUPLICATE KEY UPDATE
  `reason` = VALUES(`reason`),
  `expires_at` = VALUES(`expires_at`),
  `banned_by` = VALUES(`banned_by`);
