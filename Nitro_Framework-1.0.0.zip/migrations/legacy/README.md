# Legacy import scripts

Files in this directory are **never applied automatically**. They exist for
server owners who want to move an existing QBCore installation onto
Nitro_Framework without losing their players.

## `100_qbcore_import.sql`

Copies the contents of the QBCore `players`, `bans` and inventory JSON columns
into the Nitro schema.

### Before you run it

1. **Back up your database.**

   ```bash
   mysqldump -u USERNAME -p --single-transaction --routines --triggers DATABASE > nitro_backup_$(date +%F).sql
   ```

2. **Take a second copy of the tables you are about to read from** so you can
   compare before and after:

   ```sql
   CREATE TABLE qbcore_players_snapshot AS SELECT * FROM players;
   ```

3. **Apply the Nitro schema first** (`001_core.sql` .. `006_governance.sql`).
   The import only writes into Nitro tables.

4. **Stop the server** (or at least `qb-core` and any resource that writes to
   `players`) so nothing changes while the import runs.

### Identifier mapping

| QBCore | Nitro |
| --- | --- |
| `players.citizenid` | `nitro_characters.character_id` |
| `players.license` | `nitro_accounts.license` |
| `charinfo.firstname` / `charinfo.lastname` | `first_name` / `last_name` |
| `charinfo.birthdate` | `date_of_birth` |
| `charinfo.phone` | `phone` |
| `charinfo.account` | `account_number` |
| `job.name` / `job.grade.level` | `job_name` / `job_grade` |
| `gang.name` / `gang.grade.level` | `organisation_name` / `organisation_grade` |
| `money.cash` / `money.bank` | `nitro_characters.cash` / `nitro_banking_accounts.balance` |
| `position` | `position` |
| `metadata` | `metadata` |
| `players.inventory` (JSON array) | `nitro_inventory_items` rows |
| `bans` | `nitro_bans` |

Identifiers are preserved byte for byte, so existing player data stays valid.

### Requirements

* The inventory section uses `JSON_TABLE`, which needs **MySQL 8.0.4 or newer**.
  On MariaDB, run the import in two steps: skip the inventory block, then
  import inventories with the MariaDB compatible statement below.

  ```sql
  INSERT INTO nitro_inventory_items (inventory_id, item, amount, metadata, slot)
  SELECT i.id,
         j.item->>'$.name',
         GREATEST(1, COALESCE((j.item->>'$.amount') + 0, 1)),
         CASE WHEN JSON_VALID(j.item->>'$.info') AND (j.item->>'$.info') <> 'null'
              THEN j.item->>'$.info' ELSE NULL END,
         (j.item->>'$.slot') + 0
  FROM nitro_characters c
  JOIN nitro_inventories i ON i.owner_type = 'character' AND i.owner_id = c.character_id
  JOIN JSON_TABLE(c.metadata, '$[*]' COLUMNS (item JSON PATH '$')) j
  WHERE JSON_VALID(c.metadata);
  ```

  (adjust `c.metadata` to wherever the legacy inventory JSON was kept - some
  servers used `qb-inventory`'s own `inventory` table instead.)

### Verify afterwards

```sql
SELECT COUNT(*) AS qb_players FROM players;
SELECT COUNT(*) AS nitro_characters FROM nitro_characters;

SELECT p.citizenid, c.first_name, c.last_name, c.cash, c.bank
FROM players p
JOIN nitro_characters c ON c.character_id = p.citizenid
LIMIT 20;
```

### Rollback

The import never modifies the QBCore tables, so rolling back is simply:

```sql
DELETE FROM nitro_inventory_items;
DELETE FROM nitro_inventories;
DELETE FROM nitro_characters;
DELETE FROM nitro_accounts;
```

The QBCore tables remain exactly as they were, which means you can point the
old `qb-core` resource straight back at the same database if you change your
mind.
