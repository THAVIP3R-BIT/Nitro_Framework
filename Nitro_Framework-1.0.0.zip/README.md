# Nitro_Framework

A modular FiveM roleplay framework built on oxmysql.

Nitro_Framework is an original framework. It is not a reskin of QBCore: the
architecture, the schema, the exports and the event protocol are written from
scratch. The catalogue data (items, weapons, vehicles, jobs, organisations and
locations) is redistributed under the terms of the GNU GPL v3, which is why the
whole framework is GPL-3.0-or-later. See [LICENSES.md](LICENSES.md).

---

## The resources

| Resource | Responsibility |
| --- | --- |
| `nitro_shared` | The catalogue (items, weapons, vehicles, jobs, organisations, locations), the configuration and the locale |
| `nitro_database` | The only resource that talks to the database, the migrations and the diagnostics |
| `nitro_core` | Sessions, ace permissions, the callback system, the connection gateway, the console commands |
| `nitro_players` | Accounts, characters, the selection screen, the persistence of a character |
| `nitro_characters` | The profile and the appearance of a character |
| `nitro_inventory` | Containers, items, weight, slots, serials, transfers |
| `nitro_banking` | Cash, bank accounts, transfers, the transaction ledger |
| `nitro_jobs` | Jobs, grades, duty, organisations, the payroll |
| `nitro_vehicles` | Vehicles, garages, impounds, the state bag properties |
| `nitro_housing` | Properties, ownership, access, the property flow |
| `nitro_admin` | Moderation, staff actions, the audit trail |
| `nitro_ui` | The NUI layer: character selection, creator, inventory, banking, admin menu |

Every resource only talks to the other resources through `exports` and
events, so a resource can be replaced without touching the rest of the
framework.

---

## Requirements

* A current FiveM server build with `lua54` support
* MySQL 8.0.4 or newer
* [oxmysql](https://github.com/overextended/oxmysql)
* Node.js 18 or newer, only for the development tooling

---

## Installation

The full procedure, including the database, oxmysql, the ACE permissions, the
first start and the troubleshooting, is in
[docs/deploying-on-cfx.md](docs/deploying-on-cfx.md). The short version:

1. Build the archive that a server needs and extract it at the server root:

   ```bash
   npm install
   npm run package        # dist/Nitro_Framework-<version>.zip
   ```

   The archive contains the twelve resources in `resources/nitro_*`, so they
   end up in the `resources` directory of the server.

2. Set the connection string in your `server.cfg`:

   ```cfg
   set mysql_connection_string "mysql://user:password@127.0.0.1:3306/nitro?charset=utf8mb4"
   ```

3. Start the resources in this order:

   ```cfg
   ensure oxmysql

   ensure nitro_shared
   ensure nitro_database
   ensure nitro_core
   ensure nitro_players
   ensure nitro_characters
   ensure nitro_inventory
   ensure nitro_banking
   ensure nitro_jobs
   ensure nitro_vehicles
   ensure nitro_housing
   ensure nitro_admin
   ensure nitro_ui
   ```

4. Grant the staff permissions:

   ```cfg
   add_ace group.admin nitro.admin allow
   add_ace group.superadmin nitro.superadmin allow
   add_principal group.superadmin group.admin
   ```

The migrations run automatically when `nitro_database` starts. The console
prints one line per migration.

A ready to copy `server.cfg` is in [server.cfg.example](server.cfg.example).

---

## Documentation

* [Deploying on a Cfx.re server](docs/deploying-on-cfx.md) - the complete
  installation, the permissions and the troubleshooting
* [The API reference](docs/api-reference.md) - every export, event, callback
  and command
* [Migrating from QBCore](docs/migrating-from-qbcore.md) - the database, the
  configuration, the permissions and the API mapping
* [The migrations](migrations/README.md) - the schema, the order and the
  rollback
* [The legacy import](migrations/legacy/README.md) - moving an existing
  installation onto Nitro

---

## Development

The repository ships with the tooling that keeps the framework consistent. It
needs Node.js, but nothing else: the Lua tests run inside
[fengari](https://github.com/fengari-lua/fengari), a Lua 5.3 interpreter that
is written in JavaScript.

```bash
npm install          # install the tooling
npm run check        # the whole gate: syntax, manifests, legacy audit, tests
```

| Script | What it does |
| --- | --- |
| `npm run lint:lua` | Parse every Lua file with `luaparse` |
| `npm run lint:manifests` | Check that every manifest matches the code |
| `npm run lint:legacy` | Check that no legacy identifier leaked into the code |
| `npm run lint:schema` | Check that the SQL of the code matches the migrations |
| `npm run lint:recipe` | Validate the txAdmin recipe and its `server.cfg` template |
| `npm run sync:migrations` | Copy the migrations into `nitro_database/sql` |
| `npm run package` | Build the zip that a Cfx.re server needs |
| `npm test` | Run the Lua unit tests |
| `npm run check` | All of the above except `package` |

### The migrations

The canonical SQL lives in `migrations/`, the copies that ship inside
`nitro_database/sql/` are generated:

```bash
npm run sync:migrations          # copy
node tools/sync-migrations.mjs --check   # fail when the copies are stale
```

The legacy import in `migrations/legacy/` is never copied and never applied
automatically.

### The tests

```bash
npm test
```

The suite runs the pure modules of the framework inside a real Lua
interpreter:

| Spec | Covers |
| --- | --- |
| `tests/specs/utils_spec.lua` | The helpers of `nitro_shared` |
| `tests/specs/sqlsplit_spec.lua` | The SQL splitter and the drift checksum |
| `tests/specs/validation_spec.lua` | The character validation of `nitro_players` |

---

## Project layout

```
Nitro_Framework/
├── migrations/            the canonical SQL migrations
│   └── legacy/            the one-off import of an existing installation
├── resources/
│   └── nitro_xxx/         the twelve resources
├── txadmin/               the txAdmin recipe and its server.cfg template
├── docs/                  the documentation
├── tests/
│   ├── lua/               the test harness
│   └── specs/             the specs
├── tools/                 the Node tooling
├── package.json
└── server.cfg.example
```

---

## Licence

GPL-3.0-or-later, see [LICENSES.md](LICENSES.md).
