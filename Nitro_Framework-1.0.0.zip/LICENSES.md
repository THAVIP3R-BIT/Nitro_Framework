# Licences and third party inventory

## The framework

Nitro_Framework is licensed under the **GNU General Public License, version 3
or (at your option) any later version**.

```
Copyright (C) 2024 The Nitro_Framework contributors

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program. If not, see <https://www.gnu.org/licenses/>.
```

The full text of the licence is available at <https://www.gnu.org/licenses/gpl-3.0.html>.

---

## Why the framework is GPL

The catalogue data of `nitro_shared` (items, weapons, vehicles, jobs,
organisations and locations) is derived from the data tables of the QBCore and
ESX projects. Both are published under the GNU General Public License v3.

A work that is derived from a GPL work has to be distributed under the GPL as
well, which is why the whole framework is GPL-3.0-or-later. The framework code
itself is original, the licence is a consequence of the data that ships with
it.

---

## Third party inventory

| Component | Origin | Licence | How it is used |
| --- | --- | --- | --- |
| Item catalogue | ESX / QBCore data tables | GPL-3.0 | Redistributed as `nitro_shared/shared/data/items.lua` |
| Weapon catalogue | ESX / QBCore data tables | GPL-3.0 | Redistributed as `nitro_shared/shared/data/weapons.lua` |
| Vehicle catalogue | ESX / QBCore data tables | GPL-3.0 | Redistributed as `nitro_shared/shared/data/vehicles.lua` |
| Location catalogue | ESX / QBCore data tables | GPL-3.0 | Redistributed as `nitro_shared/shared/data/locations.lua` |
| Job catalogue | ESX / QBCore data tables | GPL-3.0 | Redistributed as `nitro_shared/shared/data/jobs.lua` |
| Organisation catalogue | ESX / QBCore data tables | GPL-3.0 | Redistributed as `nitro_shared/shared/data/organisations.lua` |
| `oxmysql` | overextended | LGPL-3.0 | Required runtime dependency, not redistributed here |
| `luaparse` | snarf | MIT | Development dependency of the Lua syntax checker |
| `fengari` | fengari project | MIT | Development dependency of the Lua test runner |

### Required runtime dependencies

| Resource | Why |
| --- | --- |
| `oxmysql` | The only database driver that Nitro_Framework supports. |

The FiveM server itself is **not** redistributed with this framework and is
covered by its own terms.

---

## Attribution

The catalogue data is derived from the work of the following people and
projects. Their notices are kept intact in the files that redistribute the
data:

* **ESX** - Jeremie N'gadi and the ESX Legacy contributors
  <https://github.com/esx-framework/esx_core>
* **QBCore** - Joshua Eger and the QBCore contributors
  <https://github.com/qbcore-framework/qb-core>

Every file that redistributes a part of the catalogue carries the notice:

```lua
--[[
    Catalogue data ported from the QBCore data tables (GPL-3.0-or-later).
    Original authors: ESX (Jeremie N'gadi), Joshua Eger / QBCore contributors.
    The data itself is redistributed under the terms of the GNU GPL v3; the
    framework wrapper around it is original Nitro_Framework work.

    See LICENSES.md in the repository root for the full third-party inventory.
]]
```

---

## Modifications

The framework code is original work and may be modified freely under the terms
of the GPL. The catalogue data may be replaced as well, the framework does not
depend on the exact contents of the catalogues, it only depends on their
structure:

* an item has a `name`, a `label`, a `weight`, a `type`, an `image`, a
  `unique` flag and a `useable` flag
* a job has a `label`, a `type`, a `defaultDuty` flag, an `offDutyPay` flag
  and a `grades` map of level to `{ name, payment, isboss, permissions }`
* an organisation has a `label`, a `type` and a `grades` map of level to
  `{ name, isboss, permissions }`
* a vehicle has a `model`, a `name`, a `brand`, a `price`, a `category`, a
  `type` and a `shop`

A resource may also add its own entries at runtime with the `Register*`
exports of `nitro_shared`, which is the recommended way to keep the original
catalogue untouched.
